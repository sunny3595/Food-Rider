export type SosStatus = 'IDLE' | 'COUNTDOWN' | 'ACTIVATED' | 'RESOLVED';

export interface EmergencyContact {
  id: string;
  name: string;
  relationship: 'POLICE' | 'AMBULANCE' | 'FOODGO_COMMAND' | 'FAMILY';
  phone: string;
  isDefault: boolean;
}

export interface SosIncidentReport {
  incidentId: string;
  timestamp: string;
  riderId: string;
  riderName: string;
  latitude: number;
  longitude: number;
  activeOrderNumber?: string;
  dispatchedTo: string[];
  audioRecordingActive: boolean;
  status: 'ACTIVE' | 'STANDBY' | 'RESOLVED';
}

export interface StationaryCheckState {
  isStationaryAlertActive: boolean;
  idleDurationMinutes: number;
  orderNumber?: string;
}

export interface HelmetVerificationState {
  isVerifiedToday: boolean;
  verifiedAt?: string;
  photoUrl?: string;
}
