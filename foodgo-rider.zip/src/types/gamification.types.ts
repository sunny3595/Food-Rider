export type RiderTierLevel = 'BRONZE' | 'SILVER' | 'GOLD' | 'PLATINUM' | 'DIAMOND';

export interface RiderTierInfo {
  level: RiderTierLevel;
  title: string;
  minDeliveries: number;
  minRating: number;
  minAcceptanceRate: number;
  badgeColor: string;
  perks: string[];
}

export interface AchievementBadge {
  id: string;
  name: string;
  description: string;
  iconName: string;
  category: 'MILESTONE' | 'SPEED' | 'QUALITY' | 'WEATHER' | 'NIGHT';
  isUnlocked: boolean;
  unlockedAt?: string;
  progressCurrent: number;
  progressTarget: number;
}

export interface DailyMilestoneTier {
  tierNumber: number;
  targetDeliveries: number;
  bonusAmount: number;
  status: 'ACHIEVED' | 'IN_PROGRESS' | 'LOCKED';
}

export interface PeakSurgeWindow {
  id: string;
  title: string;
  timeSlot: string;
  bonusPerOrder: number;
  isActive: boolean;
  endsInMinutes?: number;
}

export interface LeaderboardEntry {
  rank: number;
  riderName: string;
  riderCode: string;
  deliveriesCount: number;
  rating: number;
  cashPrize?: number;
  isCurrentUser: boolean;
  avatarUrl?: string;
}
