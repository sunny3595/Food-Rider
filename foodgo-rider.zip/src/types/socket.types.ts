import { DeliveryOrder, DeliveryRequest, DeliveryStatus } from './delivery.types';
import { RiderLocation } from './rider.types';

export type SocketEventName =
  | 'delivery.requested'
  | 'delivery.accepted'
  | 'delivery.cancelled'
  | 'delivery.updated'
  | 'order.updated'
  | 'rider.location.updated'
  | 'customer.message'
  | 'restaurant.message'
  | 'notification.created';

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderRole: 'RIDER' | 'CUSTOMER' | 'RESTAURANT' | 'SUPPORT';
  senderName: string;
  text: string;
  timestamp: string;
  isRead: boolean;
}

export interface InAppNotification {
  id: string;
  category: 'DELIVERY' | 'EARNINGS' | 'PAYMENT' | 'DOCUMENTS' | 'SYSTEM' | 'PROMOTION' | 'SUPPORT';
  title: string;
  message: string;
  timestamp: string;
  isRead: boolean;
  deepLink?: string;
}

export interface SocketEventPayloads {
  'delivery.requested': DeliveryRequest;
  'delivery.accepted': { deliveryId: string; riderId: string };
  'delivery.cancelled': { deliveryId: string; reason: string };
  'delivery.updated': { deliveryId: string; status: DeliveryStatus };
  'order.updated': DeliveryOrder;
  'rider.location.updated': { riderId: string; location: RiderLocation };
  'customer.message': ChatMessage;
  'restaurant.message': ChatMessage;
  'notification.created': InAppNotification;
}
