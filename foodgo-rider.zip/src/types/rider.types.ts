export type RiderAccountStatus =
  | 'PENDING_VERIFICATION'
  | 'ACTIVE'
  | 'INACTIVE'
  | 'SUSPENDED'
  | 'REJECTED'
  | 'BLOCKED';

export type RiderDutyStatus = 'ONLINE' | 'OFFLINE' | 'CONNECTING' | 'LOCATION_REQUIRED';

export type VehicleType = 'MOTORCYCLE' | 'SCOOTER' | 'BICYCLE' | 'CAR' | 'ELECTRIC_VEHICLE';

export type DocumentType =
  | 'DRIVING_LICENSE'
  | 'AADHAAR_CARD'
  | 'PAN_CARD'
  | 'VEHICLE_RC'
  | 'VEHICLE_INSURANCE'
  | 'PROFILE_PHOTO'
  | 'BANK_PASSBOOK';

export type DocumentStatus = 'NOT_UPLOADED' | 'PENDING' | 'VERIFIED' | 'REJECTED' | 'EXPIRED';

export interface RiderDocument {
  id: string;
  type: DocumentType;
  title: string;
  description: string;
  status: DocumentStatus;
  fileUrl?: string;
  documentNumber?: string;
  expiryDate?: string;
  rejectionReason?: string;
  uploadedAt?: string;
  verifiedAt?: string;
}

export interface VehicleInfo {
  type: VehicleType;
  registrationNumber: string;
  makeModel: string;
  color: string;
  year?: number;
  insuranceExpiryDate?: string;
  rcNumber?: string;
}

export interface BankAccountInfo {
  accountHolderName: string;
  bankName: string;
  accountNumberMasked: string;
  ifscCode: string;
  upiId?: string;
  isVerified: boolean;
}

export interface RiderPerformance {
  acceptanceRate: number; // e.g. 96 (%)
  completionRate: number; // e.g. 98 (%)
  cancellationRate: number; // e.g. 2 (%)
  onTimeRate: number; // e.g. 94 (%)
  averageRating: number; // e.g. 4.86
  totalDeliveriesCompleted: number;
  ratingDistribution: {
    fiveStar: number;
    fourStar: number;
    threeStar: number;
    twoStar: number;
    oneStar: number;
  };
}

export interface RiderLocation {
  latitude: number;
  longitude: number;
  heading?: number;
  accuracy?: number;
  speed?: number;
  timestamp: number;
}

export interface RiderProfile {
  id: string;
  riderCode: string; // e.g. 'RDR-8821'
  fullName: string;
  email: string;
  phone: string;
  avatarUrl?: string;
  dateOfBirth?: string;
  gender?: string;
  address?: {
    street: string;
    city: string;
    state: string;
    postalCode: string;
  };
  accountStatus: RiderAccountStatus;
  dutyStatus: RiderDutyStatus;
  isDocumentsVerified: boolean;
  vehicle: VehicleInfo;
  bankAccount?: BankAccountInfo;
  performance: RiderPerformance;
  currentLocation?: RiderLocation;
  createdAt: string;
}
