export type TransactionType = 'CREDIT' | 'DEBIT';

export type TransactionCategory =
  | 'DELIVERY_PAY'
  | 'CUSTOMER_TIP'
  | 'PEAK_SURGE'
  | 'INCENTIVE_BONUS'
  | 'WAIT_COMPENSATION'
  | 'INSTANT_WITHDRAWAL'
  | 'BANK_SETTLEMENT'
  | 'COD_DEDUCTION'
  | 'TDS_DEDUCTION'
  | 'INSURANCE_PREMIUM';

export type TransactionStatus = 'SUCCESS' | 'PENDING' | 'FAILED';

export interface LedgerTransaction {
  id: string;
  referenceId: string; // e.g. 'TXN_20261005_9124'
  timestamp: string;
  type: TransactionType;
  category: TransactionCategory;
  amount: number;
  title: string;
  description: string;
  orderNumber?: string;
  bankUtr?: string;
  status: TransactionStatus;
}

export type PayoutSpeed = 'INSTANT_UPI' | 'STANDARD_FREE';
export type PayoutDestination = 'BANK_ACCOUNT' | 'UPI_ID';

export interface WithdrawalRequestPayload {
  amount: number;
  destination: PayoutDestination;
  speed: PayoutSpeed;
  accountOrVpa: string;
}

export interface WithdrawalReceipt {
  transactionId: string;
  referenceUtr: string;
  amountRequested: number;
  fee: number;
  netTransferred: number;
  destinationMasked: string;
  timestamp: string;
  status: TransactionStatus;
}

export interface FloatingCashLimit {
  currentCashInHand: number;
  maxLimit: number;
  isLimitExceeded: boolean;
  remainingAllowance: number;
}
