export interface HotspotZone {
  id: string;
  name: string;
  demandLevel: 'VERY_HIGH' | 'HIGH' | 'MODERATE' | 'LOW';
  surgeMultiplier: number; // e.g. 1.4x
  estimatedOrdersPerHour: number;
  distanceKm: number;
  latitude: number;
  longitude: number;
  recommendedTimeWindow?: string;
}

export interface ShiftSummary {
  shiftStartedAt?: number;
  totalOnlineSecondsToday: number;
  isPaused: boolean;
  totalOrdersCompletedToday: number;
  totalEarningsToday: number;
  totalDistanceCoveredKm: number;
}

export interface DeviceBatteryStatus {
  levelPercent: number; // e.g. 78%
  isCharging: boolean;
  isLowBatteryWarning: boolean; // < 20%
}
