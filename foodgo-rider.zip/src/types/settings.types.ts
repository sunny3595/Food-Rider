export type DefaultMapApp = 'GOOGLE_MAPS' | 'APPLE_MAPS' | 'WAZE' | 'IN_APP_MAP';

export type AlertSoundType = 'RADAR_CHIME' | 'LOUD_SIREN' | 'CLASSIC_BELL' | 'SUBTLE_PULSE';

export type VibrationPattern = 'SHORT' | 'LONG' | 'HEARTBEAT' | 'NONE';

export type AppTheme = 'DARK' | 'LIGHT' | 'SYSTEM';

export type SupportedLanguage = 'en' | 'hi' | 'kn' | 'ta' | 'te';

export interface RiderSettings {
  navigation: {
    defaultApp: DefaultMapApp;
    voiceGuidance: boolean;
    avoidTolls: boolean;
    avoidHighways: boolean;
  };
  orders: {
    autoAcceptPrepaid: boolean;
    maxDeliveryDistanceKm: number;
    allowCashOnDelivery: boolean;
    allowStackedDeliveries: boolean;
  };
  notifications: {
    sound: AlertSoundType;
    maxVolumeOverride: boolean;
    vibration: VibrationPattern;
    screenFlashOnOrder: boolean;
    announcements: boolean;
  };
  system: {
    theme: AppTheme;
    language: SupportedLanguage;
    batterySaverMode: boolean;
    offlineMapsCached: boolean;
  };
}
