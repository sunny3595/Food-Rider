export type PayoutStatus =
  | 'REQUESTED'
  | 'PROCESSING'
  | 'COMPLETED'
  | 'FAILED'
  | 'CANCELLED';

export interface PayoutTransaction {
  id: string;
  referenceId: string;
  amount: number;
  status: PayoutStatus;
  destinationAccountMasked: string;
  payoutMethod: 'BANK_TRANSFER' | 'UPI_INSTANT';
  requestedAt: string;
  processedAt?: string;
  failureReason?: string;
}

export interface CashSettlementSummary {
  cashCollectedToday: number;
  cashToDeposit: number;
  settledAmount: number;
  outstandingPlatformCut: number;
  limitThreshold: number; // e.g. Max ₹3000 cash before compulsory deposit
}

export interface RiderWalletSummary {
  availableBalance: number;
  pendingBalance: number;
  totalWithdrawn: number;
  cashSettlement: CashSettlementSummary;
  recentPayouts: PayoutTransaction[];
}

export interface IncentiveGoal {
  id: string;
  title: string;
  description: string;
  targetCount: number;
  currentCount: number;
  rewardAmount: number;
  expiresAt: string;
  isCompleted: boolean;
  type: 'DAILY_TARGET' | 'WEEKLY_TARGET' | 'PEAK_HOUR';
  timeWindow?: string; // e.g. "6:00 PM – 10:00 PM"
}

export interface DailyEarningsSummary {
  date: string;
  totalEarnings: number;
  orderCount: number;
  onlineHours: number;
  breakdown: {
    basePay: number;
    distancePay: number;
    peakBonus: number;
    tips: number;
    incentiveBonus: number;
    deductions: number;
  };
}

export interface EarningsDashboardData {
  today: DailyEarningsSummary;
  thisWeekTotal: number;
  thisMonthTotal: number;
  wallet: RiderWalletSummary;
  activeIncentives: IncentiveGoal[];
  recentDaysHistory: DailyEarningsSummary[];
}
