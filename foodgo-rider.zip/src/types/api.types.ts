export interface ApiResponse<T> {
  success: boolean;
  data: T;
  message?: string;
  timestamp: string;
  requestId?: string;
}

export interface ApiErrorResponse {
  success: false;
  error: {
    code: string;
    message: string;
    details?: Record<string, string[]>;
  };
  timestamp: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number; // in seconds
  tokenType: 'Bearer';
}

export interface LoginCredentials {
  email?: string;
  password?: string;
  phone?: string;
  otp?: string;
  loginMethod: 'EMAIL_PASSWORD' | 'PHONE_OTP' | 'GOOGLE' | 'APPLE';
}

export interface RegistrationStep1 {
  fullName: string;
  phone: string;
  email: string;
  password: string;
}

export interface RegistrationStep2 {
  dateOfBirth: string;
  gender: string;
  address: {
    street: string;
    city: string;
    state: string;
    postalCode: string;
  };
}

export interface RegistrationStep3 {
  vehicleType: string;
  registrationNumber: string;
  makeModel: string;
  color: string;
  drivingLicenseNumber: string;
}

export interface RegistrationPayload extends RegistrationStep1, RegistrationStep2, RegistrationStep3 {
  termsAccepted: boolean;
}
