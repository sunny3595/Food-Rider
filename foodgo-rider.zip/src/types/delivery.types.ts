export type DeliveryStatus =
  | 'ASSIGNED'
  | 'GOING_TO_RESTAURANT'
  | 'ARRIVED_AT_RESTAURANT'
  | 'ORDER_PICKED_UP'
  | 'GOING_TO_CUSTOMER'
  | 'ARRIVED_AT_CUSTOMER'
  | 'DELIVERED'
  | 'CANCELLED'
  | 'FAILED'
  | 'RETURNED';

export type PaymentMethod = 'CASH_ON_DELIVERY' | 'ONLINE_PREPAID';

export type VerificationType = 'OTP' | 'QR' | 'PHOTO' | 'SIGNATURE';

export interface LocationCoordinates {
  latitude: number;
  longitude: number;
  address: string;
  landmark?: string;
  area: string;
  city: string;
  postalCode?: string;
  googlePlaceId?: string;
}

export interface RestaurantPartner {
  id: string;
  name: string;
  phone: string;
  maskedPhone?: string;
  location: LocationCoordinates;
  instructionsForRider?: string;
  isOrderReady: boolean;
  estimatedReadyTimeMinutes?: number;
}

export interface CustomerRecipient {
  id: string;
  name: string;
  phone: string;
  maskedPhone?: string;
  location: LocationCoordinates;
  deliveryNotes?: string;
  apartmentOrFloor?: string;
}

export interface OrderItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
  specialInstructions?: string;
}

export interface DeliveryFinancials {
  basePay: number;
  distancePay: number;
  peakHourBonus: number;
  riderTip: number;
  incentiveBonus: number;
  totalEarnings: number;
  customerOrderTotal: number;
  cashToCollect: number; // >0 only if CASH_ON_DELIVERY
  isCashCollected?: boolean;
}

export interface DeliveryRequest {
  id: string;
  orderNumber: string; // e.g. '#FG-10245'
  restaurant: RestaurantPartner;
  customer: CustomerRecipient;
  distanceToPickupKm: number;
  distanceToCustomerKm: number;
  totalDistanceKm: number;
  estimatedTimeMinutes: number;
  estimatedEarnings: number;
  paymentMethod: PaymentMethod;
  itemCount: number;
  items: OrderItem[];
  expiresAt: number; // Unix timestamp
  timeoutSecondsTotal: number;

  // Batch & Stacked Deliveries (Section 15)
  isBatchOrder?: boolean;
  batchOrdersCount?: number;
  batchSecondaryOrder?: {
    orderNumber: string;
    restaurantName: string;
    customerName: string;
    customerAddress: string;
    itemsCount: number;
    distanceKm: number;
  };
  isStackedAddOn?: boolean;
  stackedAdditionalEarnings?: number;
  stackedAdditionalDistanceKm?: number;
  stackedAdditionalMinutes?: number;

  // Granular Financial Breakdown (Section 13)
  financialsBreakdown?: {
    basePay: number;
    distancePay: number;
    surgePay: number;
    tip: number;
  };
}

export interface DeliveryOrder {
  id: string;
  orderNumber: string;
  status: DeliveryStatus;
  createdAt: string;
  assignedAt: string;
  arrivedRestaurantAt?: string;
  pickedUpAt?: string;
  arrivedCustomerAt?: string;
  deliveredAt?: string;

  restaurant: RestaurantPartner;
  customer: CustomerRecipient;
  items: OrderItem[];
  paymentMethod: PaymentMethod;
  financials: DeliveryFinancials;

  verificationRequired: VerificationType;
  customerOtp?: string; // Real customer OTP (e.g. '4829') verified on backend
  pickupCode?: string; // Restaurant pickup code e.g. 'PK-82'
  proofOfDeliveryPhotoUrl?: string;

  totalDistanceKm: number;
  cancellationReason?: string;
  notes?: string[];
}
