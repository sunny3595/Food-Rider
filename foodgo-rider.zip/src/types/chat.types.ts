export type ChatChannel = 'CUSTOMER' | 'RESTAURANT' | 'SUPPORT';

export type MessageContentType = 'TEXT' | 'IMAGE' | 'VOICE_NOTE' | 'LOCATION';

export interface ChatAttachment {
  type: MessageContentType;
  url?: string;
  durationSeconds?: number; // For voice notes
  locationCoordinates?: { latitude: number; longitude: number };
}

export interface ChatMessageItem {
  id: string;
  channel: ChatChannel;
  senderRole: 'RIDER' | 'CUSTOMER' | 'RESTAURANT' | 'SUPPORT';
  senderName: string;
  text: string;
  attachment?: ChatAttachment;
  timestamp: string;
  isRead: boolean;
  translatedText?: string;
}

export type VoipCallStatus = 'IDLE' | 'DIALING' | 'CONNECTED' | 'ENDED';

export interface VoipCallSession {
  targetName: string;
  targetRole: 'CUSTOMER' | 'RESTAURANT' | 'SUPPORT';
  maskedProxyNumber: string;
  status: VoipCallStatus;
  durationSeconds: number;
  isMuted: boolean;
  isSpeakerOn: boolean;
}

export type SupportCategory =
  | 'FOOD_SPILLED'
  | 'CUSTOMER_UNREACHABLE'
  | 'ACCIDENT_EMERGENCY'
  | 'COD_PAYMENT_DISPUTE'
  | 'RESTAURANT_DELAY'
  | 'TECHNICAL_APP_ISSUE';

export interface SupportTicket {
  ticketId: string;
  category: SupportCategory;
  orderNumber?: string;
  status: 'OPEN' | 'IN_PROGRESS' | 'RESOLVED';
  assignedAgent: string;
  createdAt: string;
}
