export interface AppConfig {
  appName: string;
  version: string;
  environment: 'development' | 'preview' | 'production';
  apiBaseUrl: string;
  wsUrl: string;
  branding: {
    primaryColor: string;
    secondaryColor: string;
    logoUrl: string;
  };
  localization: {
    country: string;
    currency: string;
    currencySymbol: string;
    timezone: string;
    defaultLocale: string;
  };
  support: {
    phone: string;
    email: string;
    termsUrl: string;
    privacyUrl: string;
    emergencyNumber: string;
  };
  tracking: {
    onlineIntervalMs: number;
    activeDeliveryIntervalMs: number;
    stationaryIntervalMs: number;
    arrivalRadiusMeters: number;
  };
  features: {
    enableDevMocks: boolean;
    enableSentryLogging: boolean;
    autoAcceptOrders: boolean;
  };
}

function getEnv(key: string, defaultValue = ''): string {
  try {
    if (typeof import.meta !== 'undefined' && (import.meta as any).env) {
      const val = (import.meta as any).env[key];
      if (val !== undefined && val !== null) return val;
    }
  } catch {}

  try {
    if (typeof process !== 'undefined' && process.env) {
      const val = process.env[key];
      if (val !== undefined && val !== null) return val;
    }
  } catch {}

  return defaultValue;
}

export const APP_CONFIG: AppConfig = {
  appName: getEnv('VITE_APP_NAME', 'FoodGo Rider'),
  version: getEnv('VITE_APP_VERSION', '1.0.0'),
  environment: (getEnv('VITE_APP_ENV', 'development') as AppConfig['environment']),
  apiBaseUrl: getEnv('VITE_API_BASE_URL', 'https://api.foodgo.delivery/v1'),
  wsUrl: getEnv('VITE_WS_URL', 'wss://ws.foodgo.delivery/v1'),
  branding: {
    primaryColor: getEnv('VITE_PRIMARY_COLOR', '#FF5200'),
    secondaryColor: getEnv('VITE_SECONDARY_COLOR', '#00A389'),
    logoUrl: '/assets/images/logo.png',
  },
  localization: {
    country: getEnv('VITE_COUNTRY', 'India'),
    currency: getEnv('VITE_CURRENCY', 'INR'),
    currencySymbol: getEnv('VITE_CURRENCY_SYMBOL', '₹'),
    timezone: getEnv('VITE_TIMEZONE', 'Asia/Kolkata'),
    defaultLocale: 'en-IN',
  },
  support: {
    phone: getEnv('VITE_SUPPORT_PHONE', '+91 1800 200 8899'),
    email: getEnv('VITE_SUPPORT_EMAIL', 'rider-support@foodgo.delivery'),
    termsUrl: getEnv('VITE_TERMS_URL', 'https://foodgo.delivery/terms'),
    privacyUrl: getEnv('VITE_PRIVACY_URL', 'https://foodgo.delivery/privacy'),
    emergencyNumber: '112',
  },
  tracking: {
    onlineIntervalMs: Number(getEnv('VITE_TRACKING_INTERVAL_ONLINE', '45000')) || 45000,
    activeDeliveryIntervalMs: Number(getEnv('VITE_TRACKING_INTERVAL_ACTIVE', '10000')) || 10000,
    stationaryIntervalMs: Number(getEnv('VITE_TRACKING_INTERVAL_STATIONARY', '90000')) || 90000,
    arrivalRadiusMeters: 100,
  },
  features: {
    enableDevMocks: getEnv('VITE_ENABLE_DEV_MOCKS', 'true') !== 'false',
    enableSentryLogging: getEnv('VITE_ENABLE_SENTRY_LOGGING', 'false') === 'true',
    autoAcceptOrders: false,
  },
};
