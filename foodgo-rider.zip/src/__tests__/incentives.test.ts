import { describe, it } from 'node:test';
import assert from 'node:assert';
import { RiderTierLevel } from '../types/gamification.types.js';

describe('FoodGo Rider - Phase 8 Incentives & Gamification Tests', () => {
  describe('Daily Milestones Progression Logic', () => {
    const evaluateMilestoneStatus = (completedCount: number, target: number, previousTarget: number) => {
      if (completedCount >= target) return 'ACHIEVED';
      if (completedCount >= previousTarget) return 'IN_PROGRESS';
      return 'LOCKED';
    };

    it('evaluates Tier 1, 2, and 3 status based on completed order count', () => {
      // 11 deliveries completed today:
      assert.strictEqual(evaluateMilestoneStatus(11, 8, 0), 'ACHIEVED'); // Tier 1: 8
      assert.strictEqual(evaluateMilestoneStatus(11, 12, 8), 'IN_PROGRESS'); // Tier 2: 12
      assert.strictEqual(evaluateMilestoneStatus(11, 16, 12), 'LOCKED'); // Tier 3: 16
    });

    it('unlocks Tier 2 upon completing 12th order', () => {
      assert.strictEqual(evaluateMilestoneStatus(12, 12, 8), 'ACHIEVED');
      assert.strictEqual(evaluateMilestoneStatus(12, 16, 12), 'IN_PROGRESS');
    });
  });

  describe('Incentive Eligibility Gate', () => {
    const checkIncentiveEligibility = (acceptanceRate: number, completionRate: number) => {
      const minAcceptance = 80;
      const minCompletion = 95;
      const isEligible = acceptanceRate >= minAcceptance && completionRate >= minCompletion;
      return {
        isEligible,
        reason: !isEligible
          ? acceptanceRate < minAcceptance
            ? 'ACCEPTANCE_RATE_TOO_LOW'
            : 'COMPLETION_RATE_TOO_LOW'
          : 'ELIGIBLE',
      };
    };

    it('approves partner meeting 94% AR and 98% CR', () => {
      const res = checkIncentiveEligibility(94, 98);
      assert.strictEqual(res.isEligible, true);
      assert.strictEqual(res.reason, 'ELIGIBLE');
    });

    it('disqualifies partner with 78% acceptance rate', () => {
      const res = checkIncentiveEligibility(78, 98);
      assert.strictEqual(res.isEligible, false);
      assert.strictEqual(res.reason, 'ACCEPTANCE_RATE_TOO_LOW');
    });

    it('disqualifies partner with 92% completion rate', () => {
      const res = checkIncentiveEligibility(90, 92);
      assert.strictEqual(res.isEligible, false);
      assert.strictEqual(res.reason, 'COMPLETION_RATE_TOO_LOW');
    });
  });

  describe('Rider Tier Qualification', () => {
    const determineTier = (deliveries: number, rating: number, ar: number): RiderTierLevel => {
      if (deliveries >= 1000 && rating >= 4.9 && ar >= 95) return 'DIAMOND';
      if (deliveries >= 500 && rating >= 4.8 && ar >= 90) return 'PLATINUM';
      if (deliveries >= 200 && rating >= 4.7 && ar >= 85) return 'GOLD';
      if (deliveries >= 50 && rating >= 4.6 && ar >= 80) return 'SILVER';
      return 'BRONZE';
    };

    it('qualifies 842 deliveries, 4.88 rating, 94% AR as PLATINUM', () => {
      assert.strictEqual(determineTier(842, 4.88, 94), 'PLATINUM');
    });

    it('qualifies 1050 deliveries, 4.92 rating, 96% AR as DIAMOND', () => {
      assert.strictEqual(determineTier(1050, 4.92, 96), 'DIAMOND');
    });
  });

  describe('Hub Leaderboard Prize Structure', () => {
    const getLeaderboardPrize = (rank: number) => {
      if (rank === 1) return 3000;
      if (rank === 2) return 2000;
      if (rank === 3) return 1000;
      if (rank <= 10) return 500;
      return 0;
    };

    it('awards correct cash bonuses for top 10 positions', () => {
      assert.strictEqual(getLeaderboardPrize(1), 3000);
      assert.strictEqual(getLeaderboardPrize(2), 2000);
      assert.strictEqual(getLeaderboardPrize(3), 1000);
      assert.strictEqual(getLeaderboardPrize(7), 500); // Current user rank
      assert.strictEqual(getLeaderboardPrize(12), 0);
    });
  });
});
