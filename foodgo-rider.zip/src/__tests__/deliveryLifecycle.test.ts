import { describe, it } from 'node:test';
import assert from 'node:assert';
import { DeliveryStatus } from '../types/delivery.types.js';

describe('FoodGo Rider - Phase 6 Delivery Lifecycle & Navigation Tests', () => {
  describe('Delivery State Machine Strict Progression', () => {
    const statusProgression: Record<DeliveryStatus, DeliveryStatus> = {
      ASSIGNED: 'GOING_TO_RESTAURANT',
      GOING_TO_RESTAURANT: 'ARRIVED_AT_RESTAURANT',
      ARRIVED_AT_RESTAURANT: 'ORDER_PICKED_UP',
      ORDER_PICKED_UP: 'GOING_TO_CUSTOMER',
      GOING_TO_CUSTOMER: 'ARRIVED_AT_CUSTOMER',
      ARRIVED_AT_CUSTOMER: 'DELIVERED',
      DELIVERED: 'DELIVERED',
      CANCELLED: 'CANCELLED',
      FAILED: 'FAILED',
      RETURNED: 'RETURNED',
    };

    it('advances sequentially through standard delivery stages', () => {
      let current: DeliveryStatus = 'ASSIGNED';
      current = statusProgression[current];
      assert.strictEqual(current, 'GOING_TO_RESTAURANT');

      current = statusProgression[current];
      assert.strictEqual(current, 'ARRIVED_AT_RESTAURANT');

      current = statusProgression[current];
      assert.strictEqual(current, 'ORDER_PICKED_UP');

      current = statusProgression[current];
      assert.strictEqual(current, 'GOING_TO_CUSTOMER');

      current = statusProgression[current];
      assert.strictEqual(current, 'ARRIVED_AT_CUSTOMER');

      current = statusProgression[current];
      assert.strictEqual(current, 'DELIVERED');
    });
  });

  describe('Cash on Delivery (COD) & Change Calculation', () => {
    const calculateChange = (orderTotal: number, amountTendered: number) => {
      if (amountTendered < orderTotal) throw new Error('Insufficient payment tendered');
      return Math.max(0, amountTendered - orderTotal);
    };

    it('calculates exact change for standard currency notes', () => {
      assert.strictEqual(calculateChange(640, 640), 0);
      assert.strictEqual(calculateChange(640, 700), 60);
      assert.strictEqual(calculateChange(640, 1000), 360);
      assert.strictEqual(calculateChange(640, 2000), 1360);
    });

    it('rejects underpayment amounts', () => {
      assert.throws(() => calculateChange(640, 500), /Insufficient payment/);
    });
  });

  describe('Item Checklist Completeness', () => {
    const canCompletePickup = (
      itemsCount: number,
      checkedCount: number,
      isThermalBagVerified: boolean,
      isSealIntact: boolean
    ) => {
      return (
        itemsCount > 0 &&
        itemsCount === checkedCount &&
        isThermalBagVerified === true &&
        isSealIntact === true
      );
    };

    it('permits pickup only when all items and safety criteria are fulfilled', () => {
      assert.strictEqual(canCompletePickup(3, 3, true, true), true);
      assert.strictEqual(canCompletePickup(3, 2, true, true), false); // Missing item check
      assert.strictEqual(canCompletePickup(3, 3, false, true), false); // Bag not verified
      assert.strictEqual(canCompletePickup(3, 3, true, false), false); // Seal not intact
    });
  });

  describe('Kitchen Wait Time Compensation', () => {
    const getWaitCompensation = (waitSeconds: number) => {
      const waitThresholdSeconds = 600; // 10 minutes
      if (waitSeconds >= waitThresholdSeconds) {
        return { isCompensated: true, amount: 25, reassignAllowed: true };
      }
      return { isCompensated: false, amount: 0, reassignAllowed: false };
    };

    it('triggers ₹25 compensation and penalty-free reassign when wait exceeds 10 minutes', () => {
      assert.deepStrictEqual(getWaitCompensation(300), {
        isCompensated: false,
        amount: 0,
        reassignAllowed: false,
      });

      assert.deepStrictEqual(getWaitCompensation(600), {
        isCompensated: true,
        amount: 25,
        reassignAllowed: true,
      });

      assert.deepStrictEqual(getWaitCompensation(720), {
        isCompensated: true,
        amount: 25,
        reassignAllowed: true,
      });
    });
  });
});
