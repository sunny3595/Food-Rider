import { describe, it } from 'node:test';
import assert from 'node:assert';
import {
  phoneSchema,
  otpSchema,
  emailSchema,
  passwordSchema,
  ifscSchema,
  vehicleNumberSchema,
  registrationStep1Schema,
  registrationStep5Schema,
} from '../validation/auth.validation.js';

describe('FoodGo Rider - Phase 2 Authentication & Validation Tests', () => {
  describe('Phone & OTP Validation', () => {
    it('accepts valid 10-digit Indian phone numbers', () => {
      assert.strictEqual(phoneSchema.safeParse('9876543210').success, true);
      assert.strictEqual(phoneSchema.safeParse('8123456789').success, true);
      assert.strictEqual(phoneSchema.safeParse('7000000000').success, true);
      assert.strictEqual(phoneSchema.safeParse('6999999999').success, true);
    });

    it('rejects invalid or international phone formats', () => {
      assert.strictEqual(phoneSchema.safeParse('1234567890').success, false); // doesn't start with 6-9
      assert.strictEqual(phoneSchema.safeParse('98765').success, false); // too short
      assert.strictEqual(phoneSchema.safeParse('+919876543210').success, false); // prefix should be stripped
      assert.strictEqual(phoneSchema.safeParse('abcdefghij').success, false); // non-digits
    });

    it('validates 4-digit numeric OTP', () => {
      assert.strictEqual(otpSchema.safeParse('1234').success, true);
      assert.strictEqual(otpSchema.safeParse('4829').success, true);
      assert.strictEqual(otpSchema.safeParse('123').success, false);
      assert.strictEqual(otpSchema.safeParse('12345').success, false);
      assert.strictEqual(otpSchema.safeParse('12a4').success, false);
    });
  });

  describe('Password & Email Security Constraints', () => {
    it('enforces password requirements (min 8 chars, 1 uppercase, 1 digit)', () => {
      assert.strictEqual(passwordSchema.safeParse('SecurePass1').success, true);
      assert.strictEqual(passwordSchema.safeParse('short1A').success, false); // < 8
      assert.strictEqual(passwordSchema.safeParse('alllowercase1').success, false); // no uppercase
      assert.strictEqual(passwordSchema.safeParse('NoDigitsHere!').success, false); // no digits
    });

    it('validates email addresses', () => {
      assert.strictEqual(emailSchema.safeParse('rider@example.com').success, true);
      assert.strictEqual(emailSchema.safeParse('dhanush.k@domain.in').success, true);
      assert.strictEqual(emailSchema.safeParse('not-an-email').success, false);
      assert.strictEqual(emailSchema.safeParse('@nodomain.com').success, false);
    });
  });

  describe('Vehicle & Banking Formats', () => {
    it('validates Indian vehicle registration numbers', () => {
      assert.strictEqual(vehicleNumberSchema.safeParse('KA01EQ9812').success, true);
      assert.strictEqual(vehicleNumberSchema.safeParse('MH12AB1234').success, true);
      assert.strictEqual(vehicleNumberSchema.safeParse('DL1A1234').success, true);
      assert.strictEqual(vehicleNumberSchema.safeParse('1234KA').success, false);
    });

    it('validates Indian banking IFSC codes', () => {
      assert.strictEqual(ifscSchema.safeParse('HDFC0001244').success, true);
      assert.strictEqual(ifscSchema.safeParse('SBIN0001234').success, true);
      assert.strictEqual(ifscSchema.safeParse('ICIC0000001').success, true);
      assert.strictEqual(ifscSchema.safeParse('HDFC1234567').success, false); // 5th char must be 0
      assert.strictEqual(ifscSchema.safeParse('SHORT').success, false);
    });

    it('validates that account number and confirm account number match in step 5', () => {
      const valid = registrationStep5Schema.safeParse({
        accountHolderName: 'Dhanush Kumar',
        bankName: 'HDFC Bank',
        accountNumber: '5010022334455',
        confirmAccountNumber: '5010022334455',
        ifscCode: 'HDFC0001244',
      });
      assert.strictEqual(valid.success, true);

      const mismatched = registrationStep5Schema.safeParse({
        accountHolderName: 'Dhanush Kumar',
        bankName: 'HDFC Bank',
        accountNumber: '5010022334455',
        confirmAccountNumber: '5010022339999',
        ifscCode: 'HDFC0001244',
      });
      assert.strictEqual(mismatched.success, false);
    });
  });
});
