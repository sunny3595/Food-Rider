import { describe, it } from 'node:test';
import assert from 'node:assert';
import { MOCK_RIDER_PROFILE, MOCK_DOCUMENTS } from '../api/mockData.js';

describe('FoodGo Rider - Phase 3 Profile & Onboarding Tests', () => {
  describe('Profile & Performance Metrics', () => {
    it('contains complete rider identity and vehicle attributes', () => {
      assert.strictEqual(MOCK_RIDER_PROFILE.fullName, 'Dhanush Kumar');
      assert.strictEqual(MOCK_RIDER_PROFILE.vehicle.type, 'MOTORCYCLE');
      assert.strictEqual(MOCK_RIDER_PROFILE.accountStatus, 'ACTIVE');
      assert.ok(MOCK_RIDER_PROFILE.bankAccount);
    });

    it('validates rating distribution sum corresponds to 100%', () => {
      const dist = MOCK_RIDER_PROFILE.performance.ratingDistribution;
      const total = dist.fiveStar + dist.fourStar + dist.threeStar + dist.twoStar + dist.oneStar;
      assert.strictEqual(total, 100);
      assert.ok(MOCK_RIDER_PROFILE.performance.averageRating >= 4.5);
    });
  });

  describe('Compliance Document Management & Expiry', () => {
    it('contains all 5 mandatory compliance documents', () => {
      const types = MOCK_DOCUMENTS.map((d) => d.type);
      assert.ok(types.includes('DRIVING_LICENSE'));
      assert.ok(types.includes('AADHAAR_CARD'));
      assert.ok(types.includes('VEHICLE_RC'));
      assert.ok(types.includes('VEHICLE_INSURANCE'));
      assert.ok(types.includes('BANK_PASSBOOK'));
    });

    it('identifies future expiry dates correctly', () => {
      const dl = MOCK_DOCUMENTS.find((d) => d.type === 'DRIVING_LICENSE');
      assert.ok(dl?.expiryDate);
      const expiryYear = new Date(dl.expiryDate).getFullYear();
      assert.ok(expiryYear > 2025);
    });

    it('detects expiring documents within 30-day thresholds', () => {
      const isExpiringSoon = (expiryDateStr: string, daysThreshold = 30) => {
        const expiry = new Date(expiryDateStr).getTime();
        const now = Date.now();
        const diffDays = (expiry - now) / (1000 * 60 * 60 * 24);
        return diffDays > 0 && diffDays <= daysThreshold;
      };

      // Test with artificial dates
      const in15Days = new Date(Date.now() + 15 * 86400000).toISOString();
      const in90Days = new Date(Date.now() + 90 * 86400000).toISOString();

      assert.strictEqual(isExpiringSoon(in15Days, 30), true);
      assert.strictEqual(isExpiringSoon(in90Days, 30), false);
    });
  });

  describe('Onboarding Sequence', () => {
    it('provides exactly 8 comprehensive onboarding guidelines', () => {
      const expectedGuidelines = [
        'How Deliveries Work',
        'Accepting Delivery Requests',
        'Turn-by-Turn Navigation',
        'Transparent Earnings & Payouts',
        'Road Safety & Emergency SOS',
        'Cash on Delivery Handling',
        'Customer Interaction & Privacy',
        'Thermal Bag & Hygiene',
      ];
      assert.strictEqual(expectedGuidelines.length, 8);
    });
  });
});
