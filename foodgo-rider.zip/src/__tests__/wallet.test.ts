import { describe, it } from 'node:test';
import assert from 'node:assert';
import { PayoutSpeed } from '../types/wallet.types.js';

describe('FoodGo Rider - Phase 7 Earnings, Wallet & Payout Tests', () => {
  describe('Withdrawal Processing & Fee Mathematics', () => {
    const calculateWithdrawalDeduction = (amount: number, speed: PayoutSpeed) => {
      const fee = speed === 'INSTANT_UPI' ? 5 : 0;
      return {
        amount,
        fee,
        totalDeducted: amount + fee,
        netTransferred: amount,
      };
    };

    it('calculates ₹5 fee for Instant UPI transfers', () => {
      const res = calculateWithdrawalDeduction(2000, 'INSTANT_UPI');
      assert.strictEqual(res.fee, 5);
      assert.strictEqual(res.totalDeducted, 2005);
      assert.strictEqual(res.netTransferred, 2000);
    });

    it('charges zero fee for Standard NEFT transfers', () => {
      const res = calculateWithdrawalDeduction(2000, 'STANDARD_FREE');
      assert.strictEqual(res.fee, 0);
      assert.strictEqual(res.totalDeducted, 2000);
      assert.strictEqual(res.netTransferred, 2000);
    });
  });

  describe('Withdrawal Limits & Validation Constraints', () => {
    const validateWithdrawal = (amount: number, balance: number, speed: PayoutSpeed) => {
      const fee = speed === 'INSTANT_UPI' ? 5 : 0;
      if (amount < 100) return { valid: false, error: 'MIN_LIMIT_VIOLATION' };
      if (amount > 10000) return { valid: false, error: 'MAX_DAILY_LIMIT_EXCEEDED' };
      if (amount + fee > balance) return { valid: false, error: 'INSUFFICIENT_BALANCE' };
      return { valid: true, error: null };
    };

    it('rejects withdrawal below ₹100 minimum threshold', () => {
      const res = validateWithdrawal(50, 4000, 'INSTANT_UPI');
      assert.strictEqual(res.valid, false);
      assert.strictEqual(res.error, 'MIN_LIMIT_VIOLATION');
    });

    it('rejects withdrawal exceeding ₹10,000 daily cap', () => {
      const res = validateWithdrawal(15000, 20000, 'INSTANT_UPI');
      assert.strictEqual(res.valid, false);
      assert.strictEqual(res.error, 'MAX_DAILY_LIMIT_EXCEEDED');
    });

    it('rejects withdrawal when balance cannot cover amount + fee', () => {
      const res = validateWithdrawal(1000, 1002, 'INSTANT_UPI'); // Needs ₹1005
      assert.strictEqual(res.valid, false);
      assert.strictEqual(res.error, 'INSUFFICIENT_BALANCE');
    });

    it('accepts valid withdrawal within balance limits', () => {
      const res = validateWithdrawal(1000, 4280, 'INSTANT_UPI');
      assert.strictEqual(res.valid, true);
    });
  });

  describe('COD Floating Cash Limits', () => {
    const checkCashLimit = (cashInHand: number, maxLimit = 2500) => {
      const isExceeded = cashInHand >= maxLimit;
      const remaining = Math.max(0, maxLimit - cashInHand);
      return { isExceeded, remaining };
    };

    it('calculates remaining cash capacity correctly', () => {
      const res = checkCashLimit(1280, 2500);
      assert.strictEqual(res.isExceeded, false);
      assert.strictEqual(res.remaining, 1220);
    });

    it('flags limit exceeded when cash exceeds ₹2,500', () => {
      const res = checkCashLimit(2600, 2500);
      assert.strictEqual(res.isExceeded, true);
      assert.strictEqual(res.remaining, 0);
    });
  });
});
