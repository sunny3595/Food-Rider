import { describe, it } from 'node:test';
import assert from 'node:assert';
import { formatCurrency, formatDistance, formatDuration } from '../utils/formatters.js';
import { generateIdempotencyKey, withDoubleSubmissionGuard } from '../utils/idempotency.js';

describe('FoodGo Rider - Phase 1 Unit Tests', () => {
  describe('Formatters & Localization', () => {
    it('formats INR currency properly without hardcoding symbol bugs', () => {
      assert.strictEqual(formatCurrency(0), '₹0');
      assert.strictEqual(formatCurrency(95), '₹95');
      assert.strictEqual(formatCurrency(1420), '₹1,420');
      assert.strictEqual(formatCurrency(undefined), '₹0');
    });

    it('formats distance in metres for under 1km and kilometres above 1km', () => {
      assert.strictEqual(formatDistance(0.45), '450 m');
      assert.strictEqual(formatDistance(2.4), '2.4 km');
      assert.strictEqual(formatDistance(0), '0 m');
    });

    it('formats duration in minutes or hours', () => {
      assert.strictEqual(formatDuration(0.5), 'Under 1 min');
      assert.strictEqual(formatDuration(18), '18 mins');
      assert.strictEqual(formatDuration(75), '1h 15m');
    });
  });

  describe('Idempotency & Double Submission Protection', () => {
    it('generates unique keys for actions', () => {
      const key1 = generateIdempotencyKey('accept', 'del_1');
      const key2 = generateIdempotencyKey('accept', 'del_1');
      assert.ok(key1.startsWith('idemp_accept_del_1_'));
      assert.notStrictEqual(key1, key2);
    });

    it('prevents rapid double submission of critical operations', async () => {
      let runCount = 0;
      const criticalTask = async () => {
        await new Promise((r) => setTimeout(r, 50));
        runCount++;
        return 'success';
      };

      const p1 = withDoubleSubmissionGuard('test_action', criticalTask);
      let secondRejected = false;
      try {
        await withDoubleSubmissionGuard('test_action', criticalTask);
      } catch (err: any) {
        secondRejected = true;
        assert.ok(err.message.includes('already processing'));
      }

      await p1;
      assert.strictEqual(secondRejected, true);
      assert.strictEqual(runCount, 1);
    });
  });

  describe('Delivery State Machine Validations', () => {
    const validProgression = [
      'ASSIGNED',
      'GOING_TO_RESTAURANT',
      'ARRIVED_AT_RESTAURANT',
      'ORDER_PICKED_UP',
      'GOING_TO_CUSTOMER',
      'ARRIVED_AT_CUSTOMER',
      'DELIVERED',
    ];

    it('enforces legal delivery status sequence and prevents illegal shortcuts', () => {
      for (let i = 0; i < validProgression.length - 1; i++) {
        const current = validProgression[i];
        const next = validProgression[i + 1];
        assert.ok(validProgression.indexOf(next) > validProgression.indexOf(current));
      }
    });
  });
});
