import { describe, it } from 'node:test';
import assert from 'node:assert';
import { ChatChannel, SupportCategory } from '../types/chat.types.js';

describe('FoodGo Rider - Phase 9 Communication, Chat & Calling Tests', () => {
  describe('Privacy-First Virtual Number Masking', () => {
    const maskPhoneNumber = (rawPhone: string) => {
      // Exotel / Twilio virtual bridge format: +91 80 4719 ••••
      const cleaned = rawPhone.replace(/\D/g, '');
      const lastFour = cleaned.slice(-4);
      return `+91 80 4719 •••• (Proxy Line)`;
    };

    it('masks rider and customer phone numbers behind virtual proxy', () => {
      const masked = maskPhoneNumber('+91 98765 43210');
      assert.ok(!masked.includes('43210'));
      assert.strictEqual(masked, '+91 80 4719 •••• (Proxy Line)');
    });
  });

  describe('Multi-Channel Message Threading', () => {
    const filterChannelMessages = (
      allMessages: { id: string; channel: ChatChannel; text: string }[],
      channel: ChatChannel
    ) => {
      return allMessages.filter((m) => m.channel === channel);
    };

    it('separates Customer, Restaurant, and Support messages strictly', () => {
      const messages: { id: string; channel: ChatChannel; text: string }[] = [
        { id: '1', channel: 'CUSTOMER', text: 'On my way' },
        { id: '2', channel: 'RESTAURANT', text: 'Waiting at counter' },
        { id: '3', channel: 'SUPPORT', text: 'Ticket logged' },
        { id: '4', channel: 'CUSTOMER', text: 'At gate' },
      ];

      const customerMsgs = filterChannelMessages(messages, 'CUSTOMER');
      assert.strictEqual(customerMsgs.length, 2);
      assert.strictEqual(customerMsgs[0].text, 'On my way');
      assert.strictEqual(customerMsgs[1].text, 'At gate');

      const restaurantMsgs = filterChannelMessages(messages, 'RESTAURANT');
      assert.strictEqual(restaurantMsgs.length, 1);

      const supportMsgs = filterChannelMessages(messages, 'SUPPORT');
      assert.strictEqual(supportMsgs.length, 1);
    });
  });

  describe('Voice Note Recording Validation', () => {
    const formatVoiceNoteDuration = (seconds: number) => {
      const validSecs = Math.max(1, Math.min(60, seconds));
      return `${validSecs}s`;
    };

    it('clamps voice note durations within 1s to 60s bounds', () => {
      assert.strictEqual(formatVoiceNoteDuration(0), '1s');
      assert.strictEqual(formatVoiceNoteDuration(24), '24s');
      assert.strictEqual(formatVoiceNoteDuration(95), '60s');
    });
  });

  describe('Support Dispatch Ticket Categorization', () => {
    const validCategories: SupportCategory[] = [
      'FOOD_SPILLED',
      'CUSTOMER_UNREACHABLE',
      'ACCIDENT_EMERGENCY',
      'COD_PAYMENT_DISPUTE',
      'RESTAURANT_DELAY',
      'TECHNICAL_APP_ISSUE',
    ];

    it('validates support ticket belongs to dispatch incident categories', () => {
      const isApproved = (cat: string) => validCategories.includes(cat as SupportCategory);
      assert.strictEqual(isApproved('FOOD_SPILLED'), true);
      assert.strictEqual(isApproved('ACCIDENT_EMERGENCY'), true);
      assert.strictEqual(isApproved('INVALID_REASON'), false);
    });
  });
});
