import { z } from 'zod';

export const phoneSchema = z
  .string()
  .trim()
  .regex(/^[6-9]\d{9}$/, 'Please enter a valid 10-digit Indian mobile number');

export const otpSchema = z
  .string()
  .trim()
  .regex(/^\d{4}$/, 'OTP must be exactly 4 digits');

export const emailSchema = z
  .string()
  .trim()
  .email('Please enter a valid email address');

export const passwordSchema = z
  .string()
  .min(8, 'Password must be at least 8 characters long')
  .regex(/[A-Z]/, 'Must contain at least one uppercase letter')
  .regex(/[0-9]/, 'Must contain at least one digit');

export const ifscSchema = z
  .string()
  .trim()
  .toUpperCase()
  .regex(/^[A-Z]{4}0[A-Z0-9]{6}$/, 'Enter a valid 11-character IFSC code (e.g. HDFC0001244)');

export const vehicleNumberSchema = z
  .string()
  .trim()
  .toUpperCase()
  .regex(/^[A-Z]{2}[0-9]{1,2}[A-Z]{0,3}[0-9]{4}$/, 'Enter a valid vehicle registration (e.g. KA01EQ9812)');

// Step 1: Personal Details
export const registrationStep1Schema = z.object({
  fullName: z.string().trim().min(3, 'Full name must be at least 3 characters'),
  phone: phoneSchema,
  email: emailSchema,
  password: passwordSchema,
});

// Step 2: Address & Demographics
export const registrationStep2Schema = z.object({
  dateOfBirth: z.string().min(1, 'Date of birth is required'),
  gender: z.enum(['Male', 'Female', 'Other'] as const),
  address: z.object({
    street: z.string().trim().min(5, 'Street address is required'),
    city: z.string().trim().min(2, 'City is required'),
    state: z.string().trim().min(2, 'State is required'),
    postalCode: z.string().trim().regex(/^\d{6}$/, 'Enter a valid 6-digit PIN code'),
  }),
});

// Step 3: Vehicle Information
export const registrationStep3Schema = z.object({
  vehicleType: z.enum(['MOTORCYCLE', 'SCOOTER', 'BICYCLE', 'CAR', 'ELECTRIC_VEHICLE'] as const),
  registrationNumber: vehicleNumberSchema,
  makeModel: z.string().trim().min(2, 'Vehicle make and model required (e.g. Hero Splendor)'),
  color: z.string().trim().min(2, 'Vehicle color is required'),
  drivingLicenseNumber: z.string().trim().min(8, 'Valid driving license number required'),
});

// Step 4: Documents Upload
export const registrationStep4Schema = z.object({
  hasDrivingLicense: z.boolean().refine((val) => val === true, 'Driving License must be uploaded'),
  hasAadhaarCard: z.boolean().refine((val) => val === true, 'Aadhaar / National ID must be uploaded'),
  hasVehicleRc: z.boolean().refine((val) => val === true, 'Vehicle RC must be uploaded'),
  hasProfilePhoto: z.boolean().refine((val) => val === true, 'Profile photo must be captured'),
});

// Step 5: Bank Account & Payouts
export const registrationStep5Schema = z.object({
  accountHolderName: z.string().trim().min(3, 'Account holder name is required'),
  bankName: z.string().trim().min(2, 'Bank name is required (e.g. HDFC Bank)'),
  accountNumber: z.string().trim().min(9, 'Enter a valid bank account number').max(18),
  confirmAccountNumber: z.string().trim(),
  ifscCode: ifscSchema,
  upiId: z.string().trim().optional(),
}).refine((data) => data.accountNumber === data.confirmAccountNumber, {
  message: 'Account numbers do not match',
  path: ['confirmAccountNumber'],
});

// Step 6: Legal Consent
export const registrationStep6Schema = z.object({
  agreedToTerms: z.boolean().refine((val) => val === true, 'You must agree to the Terms of Service'),
  agreedToPrivacy: z.boolean().refine((val) => val === true, 'You must agree to the Privacy Policy'),
  consentBackgroundCheck: z.boolean().refine((val) => val === true, 'You must consent to identity verification'),
});
