import React, { useState, useEffect } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MobileShell } from './components/layout/MobileShell';
import { BottomNavigation, TabKey } from './components/layout/BottomNavigation';
import { DeliveryRequestModal } from './components/delivery/DeliveryRequestModal';
import { DevSimulatorDrawer } from './components/common/DevSimulatorDrawer';
import { ChatModal } from './components/chat/ChatModal';
import { HomeScreen } from './screens/HomeScreen';
import { DeliveriesScreen } from './screens/DeliveriesScreen';
import { EarningsScreen } from './screens/EarningsScreen';
import { WalletScreen } from './screens/WalletScreen';
import { IncentivesScreen } from './screens/IncentivesScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { AuthScreen } from './screens/AuthScreen';
import { PendingVerificationScreen } from './screens/auth/PendingVerificationScreen';
import { AccountSuspendedScreen } from './screens/auth/AccountSuspendedScreen';
import { OnboardingScreen } from './screens/onboarding/OnboardingScreen';
import { AuthStore, useAuth } from './store/authStore';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30000,
      retry: 1,
    },
  },
});

function RiderAppContent() {
  const { isAuthenticated, isLoading, rider, hasCompletedOnboarding } = useAuth();
  const [currentTab, setCurrentTab] = useState<TabKey>('home');
  const [isWalletOpen, setIsWalletOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);

  useEffect(() => {
    AuthStore.initialize();
  }, []);

  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-6 bg-slate-950 text-white">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#FF5200] to-amber-500 flex items-center justify-center font-black text-xl mb-3 animate-bounce">
          FG
        </div>
        <p className="text-xs text-slate-400 font-medium">Initializing FoodGo Rider System...</p>
      </div>
    );
  }

  // If not authenticated, show Auth flow (Welcome / Login / OTP / Register)
  if (!isAuthenticated) {
    return <AuthScreen />;
  }

  // Account Status State Machine enforcement
  // PENDING_VERIFICATION: Rider has registered but documents are under review
  if (rider?.accountStatus === 'PENDING_VERIFICATION') {
    return (
      <div className="flex-1 flex flex-col h-full bg-slate-950">
        <PendingVerificationScreen />
        <DevSimulatorDrawer />
      </div>
    );
  }

  // SUSPENDED / BLOCKED / REJECTED:
  if (rider?.accountStatus === 'SUSPENDED' || rider?.accountStatus === 'BLOCKED' || rider?.accountStatus === 'REJECTED') {
    return (
      <div className="flex-1 flex flex-col h-full bg-slate-950">
        <AccountSuspendedScreen />
        <DevSimulatorDrawer />
      </div>
    );
  }

  // First-time Onboarding flow if not completed
  if (!hasCompletedOnboarding) {
    return (
      <div className="flex-1 flex flex-col h-full bg-slate-950">
        <OnboardingScreen />
        <DevSimulatorDrawer />
      </div>
    );
  }

  // ACTIVE RIDER: Render standard operational screens
  const renderCurrentView = () => {
    if (isWalletOpen) {
      return <WalletScreen onBack={() => setIsWalletOpen(false)} />;
    }

    switch (currentTab) {
      case 'home':
        return (
          <HomeScreen
            onNavigateTab={(tab) => {
              setIsWalletOpen(false);
              setCurrentTab(tab);
            }}
            onOpenOrderDetails={() => setCurrentTab('deliveries')}
            onOpenChat={() => setIsChatOpen(true)}
          />
        );
      case 'deliveries':
        return (
          <DeliveriesScreen
            onBackToHome={() => setCurrentTab('home')}
            onOpenChat={() => setIsChatOpen(true)}
          />
        );
      case 'earnings':
        return <EarningsScreen onOpenWallet={() => setIsWalletOpen(true)} />;
      case 'incentives':
        return <IncentivesScreen />;
      case 'profile':
        return <ProfileScreen />;
      default:
        return (
          <HomeScreen
            onNavigateTab={setCurrentTab}
            onOpenOrderDetails={() => setCurrentTab('deliveries')}
            onOpenChat={() => setIsChatOpen(true)}
          />
        );
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 relative overflow-hidden">
      {/* Active Screen Body */}
      <div className="flex-1 flex flex-col overflow-y-auto">
        {renderCurrentView()}
      </div>

      {/* Global Bottom Navigation (Visible unless in sub-modal screens like Wallet) */}
      {!isWalletOpen && (
        <BottomNavigation
          currentTab={currentTab}
          onTabChange={(tab) => {
            setIsWalletOpen(false);
            setCurrentTab(tab);
          }}
        />
      )}

      {/* Persistent Delivery Request Modal when dispatched */}
      <DeliveryRequestModal />

      {/* Customer ↔ Rider In-App Chat Modal */}
      {isChatOpen && <ChatModal onClose={() => setIsChatOpen(false)} />}

      {/* Development Simulator Drawer */}
      <DevSimulatorDrawer />
    </div>
  );
}

export function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <MobileShell>
        <RiderAppContent />
      </MobileShell>
    </QueryClientProvider>
  );
}

export default App;
