import React from 'react';
import {
  X,
  Bell,
  Navigation,
  MapPin,
  CheckCircle,
  Truck,
  WifiOff,
  RotateCcw,
  IndianRupee,
  Layers,
  UserCheck,
  UserX,
  Clock,
  LogOut,
  Zap,
} from 'lucide-react';
import { useTheme } from '../../store/themeStore';
import { useDelivery } from '../../store/deliveryStore';
import { useRider } from '../../store/riderStore';
import { useConnection } from '../../store/connectionStore';
import { useAuth } from '../../store/authStore';

export const DevSimulatorDrawer: React.FC = () => {
  const { isSimulatorOpen, toggleSimulator } = useTheme();
  const {
    activeDelivery,
    triggerIncomingRequest,
    triggerBatchDeliveryOffer,
    triggerStackedDeliveryOffer,
    advanceDeliveryStatus,
    collectCodPayment,
    resetDemoDelivery,
  } = useDelivery();
  const { simulateMovement, lastLocation } = useRider();
  const { isOnline, simulateOfflineToggle } = useConnection();
  const { rider, setAccountStatusOverride, logout } = useAuth();

  if (!isSimulatorOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex justify-end animate-fadeIn">
      <div className="w-full max-w-sm h-full bg-slate-900 border-l border-slate-800 p-5 flex flex-col justify-between overflow-y-auto text-slate-200">
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping"></span>
              <h3 className="font-bold text-sm text-white">Rider Dev Simulator</h3>
            </div>
            <button
              onClick={toggleSimulator}
              className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
            >
              <X size={18} />
            </button>
          </div>

          <p className="text-xs text-slate-400 mb-4">
            Simulate real-world delivery events, account status transitions, and GPS motion without physical driving.
          </p>

          {/* Quick Actions Section */}
          <div className="space-y-4">
            {/* Account Status Switcher */}
            <div>
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                Rider Account Status: <span className="text-amber-400 font-mono">{rider?.accountStatus || 'UNAUTHENTICATED'}</span>
              </span>
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  onClick={() => setAccountStatusOverride('ACTIVE')}
                  className={`p-2 rounded-lg text-[10px] font-bold border transition text-center ${
                    rider?.accountStatus === 'ACTIVE'
                      ? 'bg-emerald-600 text-white border-emerald-400'
                      : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'
                  }`}
                >
                  <UserCheck size={12} className="mx-auto mb-0.5" />
                  <span>ACTIVE</span>
                </button>

                <button
                  onClick={() => setAccountStatusOverride('PENDING_VERIFICATION')}
                  className={`p-2 rounded-lg text-[10px] font-bold border transition text-center ${
                    rider?.accountStatus === 'PENDING_VERIFICATION'
                      ? 'bg-amber-600 text-white border-amber-400'
                      : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'
                  }`}
                >
                  <Clock size={12} className="mx-auto mb-0.5" />
                  <span>PENDING</span>
                </button>

                <button
                  onClick={() => setAccountStatusOverride('SUSPENDED')}
                  className={`p-2 rounded-lg text-[10px] font-bold border transition text-center ${
                    rider?.accountStatus === 'SUSPENDED'
                      ? 'bg-rose-600 text-white border-rose-400'
                      : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'
                  }`}
                >
                  <UserX size={12} className="mx-auto mb-0.5" />
                  <span>SUSPENDED</span>
                </button>
              </div>
            </div>

            {/* Delivery Request Dispatch */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Delivery Dispatch Events
              </span>
              <button
                onClick={() => {
                  triggerIncomingRequest();
                  toggleSimulator();
                }}
                className="w-full py-2.5 px-3 bg-gradient-to-r from-[#FF5200] to-orange-600 hover:brightness-110 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-md transition"
              >
                <Bell size={14} />
                <span>Simulate Standard Order (₹98)</span>
              </button>

              <button
                onClick={() => {
                  triggerBatchDeliveryOffer();
                  toggleSimulator();
                }}
                className="w-full py-2 px-3 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-md transition"
              >
                <Layers size={14} />
                <span>Simulate Batch 2-Order Bundle (₹185)</span>
              </button>

              <button
                onClick={() => {
                  triggerStackedDeliveryOffer();
                  toggleSimulator();
                }}
                className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border border-slate-700 transition"
              >
                <Zap size={14} />
                <span>Simulate Route Add-On (+₹65, +1.2km)</span>
              </button>
            </div>

            {/* GPS Simulation */}
            <div>
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                GPS & Movement
              </span>
              <button
                onClick={() => simulateMovement(0.0012, 0.0009)}
                className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center justify-between border border-slate-700 transition"
              >
                <span className="flex items-center gap-2">
                  <Navigation size={13} className="text-sky-400" />
                  <span>Advance Rider GPS Coordinates</span>
                </span>
                <span className="text-[10px] font-mono text-slate-400">
                  {lastLocation.latitude.toFixed(3)}, {lastLocation.longitude.toFixed(3)}
                </span>
              </button>
            </div>

            {/* Active Delivery State Machine Step */}
            {activeDelivery && (
              <div>
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                  Order State: <span className="text-amber-400 font-mono">{activeDelivery.status}</span>
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => advanceDeliveryStatus('ARRIVED_AT_RESTAURANT')}
                    className="p-2 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg border border-slate-700 text-left"
                  >
                    <MapPin size={12} className="text-indigo-400 mb-1" />
                    <span className="block font-medium text-[11px]">Arrive Rest.</span>
                  </button>
                  <button
                    onClick={() => advanceDeliveryStatus('ORDER_PICKED_UP')}
                    className="p-2 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg border border-slate-700 text-left"
                  >
                    <Truck size={12} className="text-amber-400 mb-1" />
                    <span className="block font-medium text-[11px]">Pick Up</span>
                  </button>
                  <button
                    onClick={() => advanceDeliveryStatus('ARRIVED_AT_CUSTOMER')}
                    className="p-2 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg border border-slate-700 text-left"
                  >
                    <MapPin size={12} className="text-emerald-400 mb-1" />
                    <span className="block font-medium text-[11px]">Arrive Cust.</span>
                  </button>
                  <button
                    onClick={() => advanceDeliveryStatus('DELIVERED')}
                    className="p-2 bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-300 text-xs rounded-lg text-left"
                  >
                    <CheckCircle size={12} className="text-emerald-400 mb-1" />
                    <span className="block font-medium text-[11px]">Mark Delivered</span>
                  </button>
                </div>
              </div>
            )}

            {/* Network & COD */}
            <div>
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                Connectivity & Settlement
              </span>
              <div className="space-y-2">
                <button
                  onClick={simulateOfflineToggle}
                  className={`w-full py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-between border transition ${
                    !isOnline
                      ? 'bg-rose-950 text-rose-300 border-rose-800'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <WifiOff size={13} />
                    <span>{isOnline ? 'Simulate Network Disconnect' : 'Reconnect Network'}</span>
                  </span>
                  <span className="text-[10px] font-mono uppercase">{isOnline ? 'Online' : 'Offline'}</span>
                </button>

                <button
                  onClick={collectCodPayment}
                  className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold flex items-center gap-2 border border-slate-700 transition"
                >
                  <IndianRupee size={13} className="text-emerald-400" />
                  <span>Simulate COD Cash Collection</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer: Reset State & Logout */}
        <div className="pt-4 border-t border-slate-800 space-y-2">
          <button
            onClick={() => {
              resetDemoDelivery();
              toggleSimulator();
            }}
            className="w-full py-2 px-3 bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded-xl text-xs font-medium flex items-center justify-center gap-2 transition"
          >
            <RotateCcw size={13} />
            <span>Reset Demo Delivery State</span>
          </button>

          <button
            onClick={() => {
              logout();
              toggleSimulator();
            }}
            className="w-full py-2 px-3 bg-rose-950/40 hover:bg-rose-950 text-rose-400 rounded-xl text-xs font-medium flex items-center justify-center gap-2 transition border border-rose-900/50"
          >
            <LogOut size={13} />
            <span>Sign Out to Auth Screen</span>
          </button>
        </div>
      </div>
    </div>
  );
};
