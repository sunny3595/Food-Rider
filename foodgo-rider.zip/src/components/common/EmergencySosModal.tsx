import React, { useState } from 'react';
import { ShieldAlert, PhoneCall, Headphones, X, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { APP_CONFIG } from '../../constants/config';
import { SupportApi } from '../../api/support.api';
import { useRider } from '../../store/riderStore';

interface EmergencySosModalProps {
  onClose: () => void;
}

export const EmergencySosModal: React.FC<EmergencySosModalProps> = ({ onClose }) => {
  const { lastLocation } = useRider();
  const [sosSent, setSosSent] = useState(false);
  const [isSending, setIsSending] = useState(false);

  const handleTriggerSupportSos = async () => {
    setIsSending(true);
    try {
      await SupportApi.triggerSos(lastLocation);
      setSosSent(true);
    } catch {
      setSosSent(true);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
      <div className="w-full max-w-sm bg-slate-900 border border-rose-500/40 rounded-2xl overflow-hidden shadow-2xl p-5 text-center">
        <div className="w-14 h-14 mx-auto rounded-full bg-rose-500/20 text-rose-500 flex items-center justify-center mb-3 ring-8 ring-rose-500/10">
          <ShieldAlert size={32} />
        </div>

        <h3 className="text-lg font-bold text-white mb-1">Emergency Safety Assistance</h3>
        <p className="text-xs text-slate-300 mb-5 leading-relaxed">
          Are you in immediate danger or involved in a road incident? Select an action below.
        </p>

        {sosSent ? (
          <div className="bg-emerald-950/80 border border-emerald-500/50 rounded-xl p-4 mb-4 text-left flex items-start gap-3">
            <CheckCircle2 size={20} className="text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs font-bold text-emerald-300">Safety Incident Dispatched</h4>
              <p className="text-[11px] text-emerald-200/90 mt-0.5">
                Your live GPS coordinates have been flagged to FoodGo Safety Command. An emergency agent is dialing your registered number now.
              </p>
            </div>
          </div>
        ) : null}

        <div className="space-y-2.5">
          {/* Call 112 directly */}
          <a
            href={`tel:${APP_CONFIG.support.emergencyNumber}`}
            className="w-full py-3 px-4 bg-rose-600 hover:bg-rose-500 text-white rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-rose-900/30 transition active:scale-98"
          >
            <PhoneCall size={16} />
            <span>Call National Emergency ({APP_CONFIG.support.emergencyNumber})</span>
          </a>

          {/* Contact 24/7 FoodGo Safety Support */}
          <button
            onClick={handleTriggerSupportSos}
            disabled={isSending || sosSent}
            className="w-full py-3 px-4 bg-slate-800 hover:bg-slate-700 text-amber-400 rounded-xl font-semibold text-xs flex items-center justify-center gap-2 border border-slate-700 transition"
          >
            <Headphones size={15} />
            <span>{isSending ? 'Sending Alert...' : 'Notify FoodGo Safety Team'}</span>
          </button>

          {/* Cancel */}
          <button
            onClick={onClose}
            className="w-full py-2.5 text-xs text-slate-400 hover:text-white transition"
          >
            Cancel / False Alarm
          </button>
        </div>
      </div>
    </div>
  );
};
