import React, { useState } from 'react';
import { Power, Bell, ShieldAlert, CheckCircle2, AlertCircle } from 'lucide-react';
import { useRider } from '../../store/riderStore';
import { useTheme } from '../../store/themeStore';
import { useDuty } from '../../store/dutyStore';
import { EmergencySosModal } from '../safety/EmergencySosModal';

interface HeaderBarProps {
  onOpenNotifications?: () => void;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({ onOpenNotifications }) => {
  const { dutyStatus, isConnecting, profile } = useRider();
  const { handleDutyToggleRequest, setNotificationsDrawerOpen, dutyError } = useDuty();
  const { t } = useTheme();
  const [isSosOpen, setIsSosOpen] = useState(false);

  const isOnline = dutyStatus === 'ONLINE';

  const handleOpenNotifs = () => {
    if (onOpenNotifications) {
      onOpenNotifications();
    } else {
      setNotificationsDrawerOpen(true);
    }
  };

  return (
    <>
      <header className="px-4 py-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between z-20">
        {/* Left: Avatar & Rider Identity */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <img
              src={profile.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80'}
              alt={profile.fullName}
              className="w-10 h-10 rounded-full object-cover border-2 border-slate-700"
            />
            <span
              className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-slate-900 ${
                isOnline ? 'bg-emerald-500' : 'bg-slate-500'
              }`}
            />
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-sm font-bold text-white tracking-tight truncate max-w-[120px]">
                {profile.fullName}
              </h2>
              <span className="text-[10px] bg-slate-800 text-slate-300 font-mono px-1.5 py-0.5 rounded">
                {profile.riderCode}
              </span>
            </div>
            <div className="flex items-center gap-1 text-[11px] text-slate-400">
              <span className="text-amber-400 font-semibold">★ {profile.performance.averageRating}</span>
              <span>•</span>
              <span className="text-emerald-400 font-medium">Verified Partner</span>
            </div>
          </div>
        </div>

        {/* Right: Notifications, SOS & Duty Switch */}
        <div className="flex items-center gap-1.5">
          {/* Notifications Bell */}
          <button
            onClick={handleOpenNotifs}
            className="relative w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-750 text-slate-300 flex items-center justify-center transition active:scale-95 border border-slate-700"
            title="Notifications"
          >
            <Bell size={15} />
            <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-[#FF5200] rounded-full border-2 border-slate-900 flex items-center justify-center text-[8px] font-bold text-white">
              3
            </span>
          </button>

          {/* Emergency SOS Button */}
          <button
            onClick={() => setIsSosOpen(true)}
            className="w-8 h-8 rounded-full bg-rose-950/80 text-rose-400 border border-rose-800/60 flex items-center justify-center hover:bg-rose-900 transition active:scale-95"
            title="Emergency SOS"
          >
            <ShieldAlert size={15} />
          </button>

          {/* Online / Offline Duty Switch with Confirmation & Location Gate */}
          <button
            onClick={() => handleDutyToggleRequest()}
            disabled={isConnecting}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full font-bold text-xs tracking-wide transition-all active:scale-95 shadow-md ${
              isConnecting
                ? 'bg-amber-600 text-white animate-pulse'
                : isOnline
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white ring-2 ring-emerald-400/30'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
            }`}
          >
            <Power size={12} className={isOnline ? 'text-white' : 'text-slate-400'} />
            <span>
              {isConnecting
                ? t('connecting', 'CONNECTING')
                : isOnline
                ? t('online', 'ONLINE')
                : t('offline', 'OFFLINE')}
            </span>
          </button>
        </div>
      </header>

      {dutyError && (
        <div className="bg-rose-950/90 text-rose-300 text-xs px-4 py-2 border-b border-rose-800 flex items-center gap-2">
          <AlertCircle size={14} className="shrink-0" />
          <span>{dutyError}</span>
        </div>
      )}

      {/* Emergency SOS Modal */}
      {isSosOpen && <EmergencySosModal onClose={() => setIsSosOpen(false)} />}
    </>
  );
};
