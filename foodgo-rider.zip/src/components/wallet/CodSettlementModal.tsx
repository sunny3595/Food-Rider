import React, { useState } from 'react';
import { X, IndianRupee, QrCode, ShieldCheck, CheckCircle2, AlertTriangle, ArrowDownRight } from 'lucide-react';
import { useWallet } from '../../store/walletStore';
import { formatCurrency } from '../../utils/formatters';

interface CodSettlementModalProps {
  onClose: () => void;
}

export const CodSettlementModal: React.FC<CodSettlementModalProps> = ({ onClose }) => {
  const { floatingCash, settleFloatingCash, isProcessing } = useWallet();
  const [depositAmount, setDepositAmount] = useState<number>(floatingCash.currentCashInHand);
  const [isSuccess, setIsSuccess] = useState(false);

  const presets = [
    Math.min(500, floatingCash.currentCashInHand),
    Math.min(1000, floatingCash.currentCashInHand),
    floatingCash.currentCashInHand,
  ].filter((v, i, a) => a.indexOf(v) === i && v > 0);

  const handleDeposit = async () => {
    if (depositAmount <= 0) return;
    await settleFloatingCash(depositAmount);
    setIsSuccess(true);
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <IndianRupee size={18} className="text-amber-400" />
            <h3 className="text-sm font-bold text-white">Deposit Floating Cash</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          {/* Cash Status Card */}
          <div className="bg-gradient-to-br from-amber-950/40 via-slate-950 to-slate-950 p-4 rounded-2xl border border-amber-500/30 space-y-2">
            <div className="flex items-baseline justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold text-amber-400 block tracking-wider">
                  Cash in Hand
                </span>
                <span className="text-2xl font-black text-white font-mono">
                  {formatCurrency(floatingCash.currentCashInHand)}
                </span>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-slate-400 block">Max Cash Limit</span>
                <span className="text-xs font-mono font-bold text-slate-300">
                  {formatCurrency(floatingCash.maxLimit)}
                </span>
              </div>
            </div>

            {/* Progress bar */}
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className="h-full bg-amber-400 transition-all duration-300"
                style={{
                  width: `${(floatingCash.currentCashInHand / floatingCash.maxLimit) * 100}%`,
                }}
              />
            </div>
            <p className="text-[10px] text-slate-400">
              Remaining cash capacity: <strong>{formatCurrency(floatingCash.remainingAllowance)}</strong>
            </p>
          </div>

          {/* Deposit Form */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-white uppercase tracking-wider block">
              Deposit via UPI (GPay / PhonePe / Paytm)
            </span>

            <div className="relative">
              <span className="absolute left-3.5 top-3 text-slate-400 font-bold">₹</span>
              <input
                type="number"
                max={floatingCash.currentCashInHand}
                value={depositAmount}
                onChange={(e) => setDepositAmount(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2.5 pl-8 pr-3 text-white font-mono font-black text-lg focus:outline-none focus:border-amber-500"
              />
            </div>

            {/* Chips */}
            <div className="flex gap-2">
              {presets.map((amt) => (
                <button
                  key={amt}
                  onClick={() => setDepositAmount(amt)}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-mono font-bold border transition ${
                    depositAmount === amt
                      ? 'bg-amber-600 text-white border-amber-400 shadow'
                      : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-900'
                  }`}
                >
                  {amt === floatingCash.currentCashInHand ? 'Full Deposit' : `₹${amt}`}
                </button>
              ))}
            </div>

            <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 text-xs text-slate-300 flex items-start gap-2">
              <ShieldCheck size={16} className="text-emerald-400 shrink-0 mt-0.5" />
              <span>
                Depositing cash through UPI immediately clears your floating cash balance and ensures you keep receiving Cash on Delivery orders.
              </span>
            </div>
          </div>

          {isSuccess && (
            <div className="p-3 bg-emerald-950/80 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs font-bold flex items-center justify-center gap-2 animate-fadeIn">
              <CheckCircle2 size={16} />
              <span>Cash Deposited & Floating Balance Cleared!</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex gap-2">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 bg-slate-800 text-slate-300 rounded-xl text-xs font-bold"
          >
            Cancel
          </button>
          <button
            onClick={handleDeposit}
            disabled={isProcessing || depositAmount <= 0}
            className="flex-1 py-2.5 bg-amber-600 disabled:opacity-40 hover:bg-amber-500 text-white rounded-xl text-xs font-bold shadow transition"
          >
            {isProcessing ? 'Depositing...' : `Deposit ${formatCurrency(depositAmount)}`}
          </button>
        </div>
      </div>
    </div>
  );
};
