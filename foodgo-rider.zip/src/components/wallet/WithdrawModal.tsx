import React, { useState } from 'react';
import {
  X,
  Building,
  ArrowUpRight,
  ShieldCheck,
  Zap,
  Clock,
  CheckCircle2,
  AlertCircle,
  QrCode,
  IndianRupee,
} from 'lucide-react';
import { useWallet } from '../../store/walletStore';
import { PayoutDestination, PayoutSpeed, WithdrawalReceipt } from '../../types/wallet.types';
import { formatCurrency } from '../../utils/formatters';

interface WithdrawModalProps {
  onClose: () => void;
}

export const WithdrawModal: React.FC<WithdrawModalProps> = ({ onClose }) => {
  const { availableBalance, requestWithdrawal, isProcessing } = useWallet();
  const [amount, setAmount] = useState<number>(2000);
  const [destination, setDestination] = useState<PayoutDestination>('BANK_ACCOUNT');
  const [speed, setSpeed] = useState<PayoutSpeed>('INSTANT_UPI');
  const [receipt, setReceipt] = useState<WithdrawalReceipt | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const presets = [500, 1000, 2000, availableBalance];
  const fee = speed === 'INSTANT_UPI' ? 5 : 0;
  const totalDeducted = amount + fee;

  const handleWithdraw = async () => {
    setErrorMsg(null);
    try {
      const destLabel =
        destination === 'BANK_ACCOUNT' ? 'HDFC Bank (••••4821)' : 'UPI (dhanush@okaxis)';
      const rec = await requestWithdrawal(amount, destination, speed, destLabel);
      setReceipt(rec);
    } catch (err: any) {
      setErrorMsg(err.message || 'Withdrawal failed');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm max-h-[90vh] bg-slate-900 border border-slate-700 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ArrowUpRight size={18} className="text-emerald-400" />
            <h3 className="text-sm font-bold text-white">Withdraw to Bank / UPI</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-4">
          {receipt ? (
            /* Success Receipt View */
            <div className="space-y-4 text-center py-2 animate-fadeIn">
              <div className="w-16 h-16 mx-auto rounded-3xl bg-emerald-500/10 border-2 border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <CheckCircle2 size={32} />
              </div>

              <div>
                <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-widest block">
                  PAYOUT INITIATED SUCCESSFULLY
                </span>
                <h3 className="text-2xl font-black text-white font-mono mt-1">
                  {formatCurrency(receipt.netTransferred)}
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Credited to {receipt.destinationMasked}
                </p>
              </div>

              {/* Receipt Metadata */}
              <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 text-left space-y-2 text-xs font-mono text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-400">Bank UTR Number:</span>
                  <span className="text-white font-bold">{receipt.referenceUtr}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Transaction ID:</span>
                  <span>{receipt.transactionId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Transfer Fee:</span>
                  <span>{formatCurrency(receipt.fee)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Timestamp:</span>
                  <span>Today, {receipt.timestamp}</span>
                </div>
              </div>

              <button
                onClick={onClose}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-emerald-950/40"
              >
                Done
              </button>
            </div>
          ) : (
            /* Withdrawal Input Form */
            <div className="space-y-4">
              {/* Amount Input */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                  Withdrawal Amount (Available: {formatCurrency(availableBalance)})
                </span>

                <div className="relative">
                  <span className="absolute left-3 top-3 text-slate-400 font-bold text-lg">₹</span>
                  <input
                    type="number"
                    min={100}
                    max={10000}
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl py-2.5 pl-8 pr-3 text-white font-mono font-black text-xl focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {/* Preset Chips */}
                <div className="grid grid-cols-4 gap-1.5 pt-1">
                  {presets.map((val) => (
                    <button
                      key={val}
                      onClick={() => setAmount(val)}
                      className={`py-1.5 text-xs font-mono font-bold rounded-lg border transition ${
                        amount === val
                          ? 'bg-emerald-600 text-white border-emerald-400'
                          : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-850'
                      }`}
                    >
                      {val === availableBalance ? 'All' : `₹${val}`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Destination Selector */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-white uppercase tracking-wider block">
                  Select Payout Destination
                </span>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setDestination('BANK_ACCOUNT')}
                    className={`p-3 rounded-2xl border text-left transition flex items-start gap-2.5 ${
                      destination === 'BANK_ACCOUNT'
                        ? 'bg-slate-950 border-emerald-500 ring-1 ring-emerald-500/40'
                        : 'bg-slate-950/70 border-slate-800 hover:bg-slate-950'
                    }`}
                  >
                    <Building size={16} className="text-emerald-400 mt-0.5 shrink-0" />
                    <div>
                      <span className="text-xs font-bold text-white block">HDFC Bank Ltd</span>
                      <span className="text-[10px] text-slate-400 font-mono">••••4821</span>
                    </div>
                  </button>

                  <button
                    onClick={() => setDestination('UPI_ID')}
                    className={`p-3 rounded-2xl border text-left transition flex items-start gap-2.5 ${
                      destination === 'UPI_ID'
                        ? 'bg-slate-950 border-emerald-500 ring-1 ring-emerald-500/40'
                        : 'bg-slate-950/70 border-slate-800 hover:bg-slate-950'
                    }`}
                  >
                    <QrCode size={16} className="text-sky-400 mt-0.5 shrink-0" />
                    <div>
                      <span className="text-xs font-bold text-white block">UPI VPA</span>
                      <span className="text-[10px] text-slate-400 font-mono truncate block max-w-[100px]">
                        dhanush@okaxis
                      </span>
                    </div>
                  </button>
                </div>
              </div>

              {/* Transfer Speed Switcher */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-white uppercase tracking-wider block">
                  Transfer Speed
                </span>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setSpeed('INSTANT_UPI')}
                    className={`p-3 rounded-2xl border text-left transition ${
                      speed === 'INSTANT_UPI'
                        ? 'bg-emerald-950/30 border-emerald-500 text-white'
                        : 'bg-slate-950/70 border-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold flex items-center gap-1">
                        <Zap size={12} className="text-amber-400" />
                        <span>Instant UPI</span>
                      </span>
                      <span className="text-[10px] font-mono font-bold text-amber-400">₹5 Fee</span>
                    </div>
                    <p className="text-[10px] text-slate-400">Credited in &lt; 30 seconds</p>
                  </button>

                  <button
                    onClick={() => setSpeed('STANDARD_FREE')}
                    className={`p-3 rounded-2xl border text-left transition ${
                      speed === 'STANDARD_FREE'
                        ? 'bg-emerald-950/30 border-emerald-500 text-white'
                        : 'bg-slate-950/70 border-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold flex items-center gap-1">
                        <Clock size={12} className="text-emerald-400" />
                        <span>Standard NEFT</span>
                      </span>
                      <span className="text-[10px] font-mono font-bold text-emerald-400">FREE</span>
                    </div>
                    <p className="text-[10px] text-slate-400">Settles by 6:00 AM next day</p>
                  </button>
                </div>
              </div>

              {/* Calculation Summary */}
              <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-1.5 text-xs font-mono text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-400">Withdrawal Amount:</span>
                  <span>{formatCurrency(amount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">IMPS/UPI Processing Fee:</span>
                  <span>{formatCurrency(fee)}</span>
                </div>
                <div className="flex justify-between pt-1 border-t border-slate-800 font-bold">
                  <span className="text-white">Total Wallet Deduction:</span>
                  <span className="text-emerald-400">{formatCurrency(totalDeducted)}</span>
                </div>
              </div>

              {errorMsg && (
                <div className="p-3 bg-rose-950/80 border border-rose-800 rounded-xl text-rose-300 text-xs flex items-center gap-1.5">
                  <AlertCircle size={14} className="shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* Action Button */}
              <button
                onClick={handleWithdraw}
                disabled={isProcessing || amount < 100 || totalDeducted > availableBalance}
                className="w-full py-3.5 bg-emerald-600 disabled:opacity-40 hover:bg-emerald-500 text-white rounded-2xl text-xs font-bold transition shadow-lg shadow-emerald-950/50 flex items-center justify-center gap-2"
              >
                <ArrowUpRight size={16} />
                <span>
                  {isProcessing
                    ? 'Processing Transfer...'
                    : `CONFIRM TRANSFER (${formatCurrency(amount)})`}
                </span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
