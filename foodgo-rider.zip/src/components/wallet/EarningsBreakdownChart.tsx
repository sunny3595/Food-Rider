import React from 'react';
import { Flame, TrendingUp, BarChart3 } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

interface HourlyBucket {
  slot: string;
  amount: number;
  orders: number;
  isPeak: boolean;
}

const HOURLY_BUCKETS: HourlyBucket[] = [
  { slot: '8A-11A', amount: 180, orders: 2, isPeak: false },
  { slot: '11A-3P', amount: 540, orders: 4, isPeak: true },
  { slot: '3P-7P', amount: 260, orders: 2, isPeak: false },
  { slot: '7P-11P', amount: 440, orders: 3, isPeak: true },
];

export const EarningsBreakdownChart: React.FC = () => {
  const maxAmount = Math.max(...HOURLY_BUCKETS.map((b) => b.amount));

  return (
    <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-3 shadow-lg">
      <div className="flex items-center justify-between pb-1 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <BarChart3 size={16} className="text-[#FF5200]" />
          <h3 className="text-xs font-bold text-white">Shift Earnings Timeline</h3>
        </div>
        <span className="text-[10px] text-amber-400 font-bold bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 flex items-center gap-1">
          <Flame size={10} />
          <span>Lunch & Dinner Peaks</span>
        </span>
      </div>

      {/* Bar Chart Container */}
      <div className="pt-4 pb-2 flex items-end justify-between gap-3 h-36">
        {HOURLY_BUCKETS.map((bucket) => {
          const heightPercent = Math.round((bucket.amount / maxAmount) * 100);

          return (
            <div key={bucket.slot} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end">
              <span className="text-[10px] font-mono font-bold text-slate-300">
                ₹{bucket.amount}
              </span>

              {/* Animated Bar */}
              <div className="w-full bg-slate-950 rounded-xl overflow-hidden flex flex-col justify-end h-24 p-0.5 border border-slate-800">
                <div
                  className={`w-full rounded-lg transition-all duration-700 ${
                    bucket.isPeak
                      ? 'bg-gradient-to-t from-orange-600 to-[#FF5200] shadow-md shadow-orange-950/50'
                      : 'bg-slate-700'
                  }`}
                  style={{ height: `${heightPercent}%` }}
                />
              </div>

              {/* Slot Label */}
              <span className="text-[10px] font-bold text-slate-400 font-mono">
                {bucket.slot}
              </span>
            </div>
          );
        })}
      </div>

      <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
        <span>Average Hourly Earning: <strong className="text-white">₹217 / hr</strong></span>
        <span>Average Order Value: <strong className="text-emerald-400">₹129</strong></span>
      </div>
    </div>
  );
};
