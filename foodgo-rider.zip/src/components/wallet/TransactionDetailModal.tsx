import React from 'react';
import { X, ArrowDownLeft, ArrowUpRight, CheckCircle2, Building, Hash, Calendar, FileText } from 'lucide-react';
import { LedgerTransaction } from '../../types/wallet.types';
import { formatCurrency } from '../../utils/formatters';

interface TransactionDetailModalProps {
  transaction: LedgerTransaction;
  onClose: () => void;
}

export const TransactionDetailModal: React.FC<TransactionDetailModalProps> = ({
  transaction,
  onClose,
}) => {
  const isCredit = transaction.type === 'CREDIT';

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText size={18} className="text-slate-400" />
            <h3 className="text-sm font-bold text-white">Transaction Details</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-center">
          {/* Amount Icon */}
          <div
            className={`w-16 h-16 mx-auto rounded-3xl flex items-center justify-center border-2 ${
              isCredit
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
            }`}
          >
            {isCredit ? <ArrowDownLeft size={30} /> : <ArrowUpRight size={30} />}
          </div>

          <div>
            <span
              className={`text-2xl font-black font-mono tracking-tight ${
                isCredit ? 'text-emerald-400' : 'text-white'
              }`}
            >
              {isCredit ? '+' : '-'}
              {formatCurrency(transaction.amount)}
            </span>
            <h4 className="text-sm font-bold text-white mt-1">{transaction.title}</h4>
            <p className="text-xs text-slate-400 mt-0.5">{transaction.description}</p>
          </div>

          {/* Details Table */}
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-left space-y-2.5 text-xs font-mono text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-400">Reference ID:</span>
              <span className="text-white font-bold">{transaction.referenceId}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">Timestamp:</span>
              <span>{transaction.timestamp}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">Category:</span>
              <span className="text-amber-400">{transaction.category}</span>
            </div>

            {transaction.orderNumber && (
              <div className="flex justify-between">
                <span className="text-slate-400">Associated Order:</span>
                <span className="text-sky-400 font-bold">{transaction.orderNumber}</span>
              </div>
            )}

            {transaction.bankUtr && (
              <div className="flex justify-between">
                <span className="text-slate-400">Bank UTR Ref:</span>
                <span className="text-emerald-400 font-bold">{transaction.bankUtr}</span>
              </div>
            )}

            <div className="flex justify-between pt-1 border-t border-slate-800">
              <span className="text-slate-400">Status:</span>
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 size={12} />
                <span>{transaction.status}</span>
              </span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800">
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-bold"
          >
            Close Receipt
          </button>
        </div>
      </div>
    </div>
  );
};
