import React, { useState, useEffect } from 'react';
import { Clock, AlertTriangle, ShieldCheck, Zap, RotateCcw } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

interface RestaurantWaitTimerCardProps {
  restaurantName: string;
  isOrderReady: boolean;
  onReassignPenaltyFree?: () => void;
}

export const RestaurantWaitTimerCard: React.FC<RestaurantWaitTimerCardProps> = ({
  restaurantName,
  isOrderReady,
  onReassignPenaltyFree,
}) => {
  const [waitSeconds, setWaitSeconds] = useState(4 * 60 + 15); // 4m 15s elapsed
  const [isCompensated, setIsCompensated] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setWaitSeconds((prev) => {
        const next = prev + 1;
        if (next >= 600 && !isCompensated) {
          setIsCompensated(true);
        }
        return next;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isCompensated]);

  const mins = Math.floor(waitSeconds / 60);
  const secs = waitSeconds % 60;
  const timeString = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;

  const isExceeded10Min = waitSeconds >= 600;

  return (
    <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-3 shadow-lg">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-orange-500/20 text-[#FF5200] flex items-center justify-center">
            <Clock size={16} className="animate-spin" style={{ animationDuration: '8s' }} />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
              Kitchen Wait Tracker
            </span>
            <span className="text-xs font-bold text-white font-mono">{timeString} elapsed</span>
          </div>
        </div>

        <span
          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
            isOrderReady
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
              : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
          }`}
        >
          {isOrderReady ? 'Order Ready for Pickup' : 'Kitchen Still Preparing'}
        </span>
      </div>

      {/* 10-Minute Wait Compensation Banner */}
      {isExceeded10Min ? (
        <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-2xl flex items-center justify-between text-xs animate-fadeIn">
          <div>
            <span className="text-emerald-400 font-bold block">Long Wait Compensation Applied!</span>
            <span className="text-[10px] text-slate-300">
              +{formatCurrency(25)} wait incentive credited to your shift earnings.
            </span>
          </div>
          {onReassignPenaltyFree && (
            <button
              onClick={onReassignPenaltyFree}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-rose-300 rounded-lg text-[10px] font-bold border border-slate-700 shrink-0"
            >
              Reassign Order
            </button>
          )}
        </div>
      ) : (
        <div className="flex items-center justify-between text-[11px] text-slate-400 bg-slate-950 p-2.5 rounded-xl border border-slate-800">
          <span>Wait &gt; 10 min compensation:</span>
          <span className="text-white font-bold font-mono">+{formatCurrency(25)} automatically</span>
        </div>
      )}
    </div>
  );
};
