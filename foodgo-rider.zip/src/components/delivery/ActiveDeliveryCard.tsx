import React from 'react';
import {
  Navigation,
  MapPin,
  Store,
  User,
  ArrowRight,
  Phone,
  MessageSquare,
  CheckCircle2,
  Clock,
  IndianRupee,
  ChevronRight,
} from 'lucide-react';
import { useDelivery } from '../../store/deliveryStore';
import { formatCurrency, formatDistance } from '../../utils/formatters';
import { DeliveryStatus } from '../../types/delivery.types';

interface ActiveDeliveryCardProps {
  onOpenDetails?: () => void;
  onOpenChat?: () => void;
}

export const ActiveDeliveryCard: React.FC<ActiveDeliveryCardProps> = ({
  onOpenDetails,
  onOpenChat,
}) => {
  const { activeDelivery, advanceDeliveryStatus, isProcessing } = useDelivery();

  if (!activeDelivery) return null;

  // Determine stage description and primary button label based on strict state machine
  const getStageAction = (status: DeliveryStatus) => {
    switch (status) {
      case 'ASSIGNED':
        return {
          title: 'New Order Assigned',
          badge: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
          btnText: 'START DELIVERY',
          nextStatus: 'GOING_TO_RESTAURANT' as DeliveryStatus,
          targetLabel: `Head to ${activeDelivery.restaurant.name}`,
        };
      case 'GOING_TO_RESTAURANT':
        return {
          title: 'Heading to Restaurant',
          badge: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
          btnText: 'ARRIVED AT RESTAURANT',
          nextStatus: 'ARRIVED_AT_RESTAURANT' as DeliveryStatus,
          targetLabel: activeDelivery.restaurant.location.address,
        };
      case 'ARRIVED_AT_RESTAURANT':
        return {
          title: 'At Restaurant',
          badge: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
          btnText: 'CONFIRM PICKUP (Order Ready)',
          nextStatus: 'ORDER_PICKED_UP' as DeliveryStatus,
          targetLabel: `Pickup Code: ${activeDelivery.pickupCode || 'N/A'}`,
        };
      case 'ORDER_PICKED_UP':
        return {
          title: 'Order Picked Up',
          badge: 'bg-sky-500/20 text-sky-400 border-sky-500/30',
          btnText: 'NAVIGATE TO CUSTOMER',
          nextStatus: 'GOING_TO_CUSTOMER' as DeliveryStatus,
          targetLabel: `Deliver to ${activeDelivery.customer.name}`,
        };
      case 'GOING_TO_CUSTOMER':
        return {
          title: 'Heading to Customer',
          badge: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
          btnText: 'ARRIVED AT CUSTOMER',
          nextStatus: 'ARRIVED_AT_CUSTOMER' as DeliveryStatus,
          targetLabel: activeDelivery.customer.location.address,
        };
      case 'ARRIVED_AT_CUSTOMER':
        return {
          title: 'Arrived at Customer Doorstep',
          badge: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
          btnText: 'VERIFY & COMPLETE DELIVERY',
          nextStatus: 'DELIVERED' as DeliveryStatus,
          targetLabel: `Enter Customer OTP (${activeDelivery.customerOtp || '4829'})`,
        };
      case 'DELIVERED':
        return {
          title: 'Order Delivered 🎉',
          badge: 'bg-emerald-500 text-white',
          btnText: 'DELIVERY COMPLETED',
          nextStatus: 'DELIVERED' as DeliveryStatus,
          targetLabel: 'All steps completed successfully',
        };
      default:
        return {
          title: status,
          badge: 'bg-slate-700 text-slate-300',
          btnText: 'PROCEED',
          nextStatus: 'DELIVERED' as DeliveryStatus,
          targetLabel: '',
        };
    }
  };

  const action = getStageAction(activeDelivery.status);
  const isDelivered = activeDelivery.status === 'DELIVERED';

  const openExternalMaps = (lat: number, lng: number) => {
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, '_blank');
  };

  return (
    <div className="bg-slate-900 border-2 border-[#FF5200]/40 rounded-2xl overflow-hidden shadow-xl mb-4 transition-all">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-[#FF5200]/20 via-orange-900/10 to-slate-900 px-4 py-2.5 flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-[#FF5200] animate-pulse"></span>
          <span className="text-[11px] font-extrabold uppercase tracking-wider text-[#FF5200]">
            ACTIVE DELIVERY
          </span>
          <span className="text-xs font-mono font-bold text-white bg-slate-800 px-2 py-0.5 rounded">
            {activeDelivery.orderNumber}
          </span>
        </div>

        <button
          onClick={onOpenDetails}
          className="text-xs text-orange-400 hover:text-orange-300 flex items-center gap-0.5 font-semibold"
        >
          <span>View Order</span>
          <ChevronRight size={14} />
        </button>
      </div>

      <div className="p-4 space-y-3.5">
        {/* Status Pill & Target Address */}
        <div className="flex items-center justify-between">
          <span
            className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${action.badge}`}
          >
            {action.title}
          </span>
          <span className="text-xs font-bold text-emerald-400">
            {formatCurrency(activeDelivery.financials.totalEarnings)} payout
          </span>
        </div>

        {/* Current Destination Card */}
        <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-orange-500/20 text-[#FF5200] flex items-center justify-center shrink-0 mt-0.5">
                {activeDelivery.status.includes('RESTAURANT') || activeDelivery.status === 'ASSIGNED' ? (
                  <Store size={15} />
                ) : (
                  <User size={15} />
                )}
              </div>
              <div>
                <h4 className="text-xs font-bold text-white leading-tight">
                  {activeDelivery.status.includes('RESTAURANT') || activeDelivery.status === 'ASSIGNED'
                    ? activeDelivery.restaurant.name
                    : activeDelivery.customer.name}
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                  {action.targetLabel}
                </p>
              </div>
            </div>

            {/* Quick Open Google Maps Navigation Button */}
            <button
              onClick={() => {
                const target =
                  activeDelivery.status.includes('RESTAURANT') || activeDelivery.status === 'ASSIGNED'
                    ? activeDelivery.restaurant.location
                    : activeDelivery.customer.location;
                openExternalMaps(target.latitude, target.longitude);
              }}
              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-sky-400 rounded-lg text-[10px] font-bold flex items-center gap-1 border border-slate-700 shrink-0"
              title="Open Google Maps Navigation"
            >
              <Navigation size={11} />
              <span>MAP</span>
            </button>
          </div>

          {/* Quick Contact Buttons */}
          <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-300">
            <div className="flex items-center gap-2">
              <a
                href={`tel:${
                  activeDelivery.status.includes('RESTAURANT')
                    ? activeDelivery.restaurant.phone
                    : activeDelivery.customer.phone
                }`}
                className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 rounded-lg text-[11px] font-medium text-slate-200"
              >
                <Phone size={11} className="text-emerald-400" />
                <span>Call</span>
              </a>

              <button
                onClick={onOpenChat}
                className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 rounded-lg text-[11px] font-medium text-slate-200"
              >
                <MessageSquare size={11} className="text-sky-400" />
                <span>Chat</span>
              </button>
            </div>

            {activeDelivery.paymentMethod === 'CASH_ON_DELIVERY' && (
              <span className="text-[11px] font-semibold text-amber-400 flex items-center gap-1">
                <IndianRupee size={12} />
                <span>Collect {formatCurrency(activeDelivery.financials.customerOrderTotal)}</span>
              </span>
            )}
          </div>
        </div>

        {/* Primary Stage Action Progression Button */}
        {!isDelivered ? (
          <button
            onClick={() => advanceDeliveryStatus(action.nextStatus)}
            disabled={isProcessing}
            className="w-full py-3 px-4 bg-gradient-to-r from-[#FF5200] to-orange-600 hover:brightness-110 active:scale-98 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-orange-950/40 transition disabled:opacity-50"
          >
            {isProcessing ? (
              <span className="animate-spin">●</span>
            ) : (
              <CheckCircle2 size={16} />
            )}
            <span>{isProcessing ? 'Updating Backend...' : action.btnText}</span>
          </button>
        ) : (
          <div className="bg-emerald-950/80 border border-emerald-500/40 p-3 rounded-xl text-center">
            <span className="text-xs font-bold text-emerald-400 block">
              Delivery Complete! Earned {formatCurrency(activeDelivery.financials.totalEarnings)}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
