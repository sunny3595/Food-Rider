import React, { useState } from 'react';
import { X, AlertTriangle, Car, CloudRain, Wrench, Clock, CheckCircle2 } from 'lucide-react';

interface ReportDelayModalProps {
  onClose: () => void;
  onDelaySubmitted: (reason: string, extraMinutes: number) => void;
}

const DELAY_REASONS = [
  { id: 'traffic', label: 'Heavy Traffic Congestion / Signal Jam', extraMins: 10, icon: <Car size={16} /> },
  { id: 'weather', label: 'Sudden Heavy Rain / Waterlogging', extraMins: 15, icon: <CloudRain size={16} /> },
  { id: 'puncture', label: 'Tyre Puncture / Bike Mechanical Delay', extraMins: 12, icon: <Wrench size={16} /> },
  { id: 'detour', label: 'Road Construction / Route Diversion', extraMins: 8, icon: <AlertTriangle size={16} /> },
];

export const ReportDelayModal: React.FC<ReportDelayModalProps> = ({ onClose, onDelaySubmitted }) => {
  const [selected, setSelected] = useState(DELAY_REASONS[0]);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    setSubmitted(true);
    setTimeout(() => {
      onDelaySubmitted(selected.label, selected.extraMins);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl p-5 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Clock size={18} className="text-amber-400" />
            <h3 className="text-sm font-bold text-white">Report Delivery Delay</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        <p className="text-xs text-slate-300">
          Notifying customer of transit delays protects your on-time performance rating from bad feedback.
        </p>

        {/* Reasons */}
        <div className="space-y-2">
          {DELAY_REASONS.map((reason) => (
            <div
              key={reason.id}
              onClick={() => setSelected(reason)}
              className={`p-3 rounded-2xl border cursor-pointer transition flex items-center justify-between ${
                selected.id === reason.id
                  ? 'bg-amber-950/40 border-amber-500/50 text-white'
                  : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:bg-slate-950'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <div className="text-amber-400">{reason.icon}</div>
                <span className="text-xs font-semibold">{reason.label}</span>
              </div>
              <span className="text-[10px] font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                +{reason.extraMins}m
              </span>
            </div>
          ))}
        </div>

        {submitted ? (
          <div className="p-3 bg-emerald-950/80 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs font-bold flex items-center justify-center gap-2">
            <CheckCircle2 size={16} />
            <span>Customer & Dispatch Updated (+{selected.extraMins} mins)</span>
          </div>
        ) : (
          <div className="space-y-2 pt-1">
            <button
              onClick={handleSubmit}
              className="w-full py-3 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-amber-950/40"
            >
              NOTIFY CUSTOMER & EXTEND ETA
            </button>
            <button
              onClick={onClose}
              className="w-full py-2 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
