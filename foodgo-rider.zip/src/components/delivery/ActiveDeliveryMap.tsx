import React, { useState } from 'react';
import { Navigation, MapPin, Store, Compass, ExternalLink, Zap, Shield } from 'lucide-react';
import { useDelivery } from '../../store/deliveryStore';
import { useRider } from '../../store/riderStore';
import { formatDistance, formatDuration } from '../../utils/formatters';

export const ActiveDeliveryMap: React.FC = () => {
  const { activeDelivery } = useDelivery();
  const { lastLocation } = useRider();
  const [mapHeading, setMapHeading] = useState(45);

  if (!activeDelivery) return null;

  const isGoingToRestaurant =
    activeDelivery.status === 'ASSIGNED' || activeDelivery.status === 'GOING_TO_RESTAURANT';
  const targetName = isGoingToRestaurant
    ? activeDelivery.restaurant.name
    : activeDelivery.customer.name;
  const targetType = isGoingToRestaurant ? 'Pickup Restaurant' : 'Dropoff Customer';

  const handleOpenExternalMaps = () => {
    const lat = isGoingToRestaurant
      ? activeDelivery.restaurant.location.latitude
      : activeDelivery.customer.location.latitude;
    const lng = isGoingToRestaurant
      ? activeDelivery.restaurant.location.longitude
      : activeDelivery.customer.location.longitude;
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, '_blank');
  };

  return (
    <div className="relative w-full h-56 bg-slate-900 rounded-3xl overflow-hidden border border-slate-800 shadow-xl">
      {/* Simulated Map Canvas Background Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:16px_16px] opacity-40" />

      {/* Stylized Simulated Route Path */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
        <path
          d="M 50 160 Q 150 90 280 50"
          fill="none"
          stroke="#FF5200"
          strokeWidth="4"
          strokeDasharray="6 6"
          className="animate-pulse"
        />
      </svg>

      {/* Rider Current Location Marker */}
      <div className="absolute left-10 bottom-8 flex flex-col items-center">
        <div className="relative flex items-center justify-center">
          <div className="absolute w-8 h-8 rounded-full bg-sky-500/20 animate-ping" />
          <div className="w-7 h-7 rounded-full bg-sky-500 border-2 border-white flex items-center justify-center text-white shadow-lg">
            <Navigation size={14} className="rotate-45" />
          </div>
        </div>
        <span className="text-[9px] font-bold bg-slate-950/80 px-1.5 py-0.5 rounded text-sky-400 font-mono mt-1 border border-slate-800">
          You (Rider)
        </span>
      </div>

      {/* Target Destination Marker (Store or Customer) */}
      <div className="absolute right-12 top-6 flex flex-col items-center">
        <div className="relative flex items-center justify-center">
          <div className="absolute w-10 h-10 rounded-full bg-emerald-500/20 animate-ping" />
          <div
            className={`w-8 h-8 rounded-2xl flex items-center justify-center text-white shadow-xl border-2 border-white ${
              isGoingToRestaurant ? 'bg-[#FF5200]' : 'bg-emerald-500'
            }`}
          >
            {isGoingToRestaurant ? <Store size={15} /> : <MapPin size={15} />}
          </div>
        </div>
        <span className="text-[9px] font-bold bg-slate-950/80 px-1.5 py-0.5 rounded text-white font-mono mt-1 border border-slate-800 truncate max-w-[120px]">
          {targetName}
        </span>
      </div>

      {/* Floating ETA Ribbon */}
      <div className="absolute top-3 left-3 bg-slate-950/90 backdrop-blur border border-slate-800 rounded-2xl px-3 py-1.5 flex items-center gap-2 shadow-lg">
        <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        <div>
          <span className="text-[9px] text-slate-400 block font-mono">Live Navigation to {targetType}</span>
          <span className="text-xs font-black text-white font-mono">
            {formatDuration(12)} • {formatDistance(2.4)} remaining
          </span>
        </div>
      </div>

      {/* Map Controls */}
      <div className="absolute bottom-3 right-3 flex items-center gap-1.5">
        <button
          onClick={handleOpenExternalMaps}
          className="px-2.5 py-1.5 bg-slate-950/90 hover:bg-slate-900 text-sky-400 border border-slate-800 rounded-xl text-xs font-bold flex items-center gap-1 shadow-lg transition"
        >
          <ExternalLink size={12} />
          <span>Maps</span>
        </button>

        <button
          onClick={() => setMapHeading((prev) => (prev + 90) % 360)}
          className="p-1.5 bg-slate-950/90 text-slate-300 hover:text-white border border-slate-800 rounded-xl shadow-lg transition"
          title="Recenter Compass"
        >
          <Compass size={16} />
        </button>
      </div>
    </div>
  );
};
