import React, { useState, useEffect } from 'react';
import { X, Clock, PhoneCall, MessageSquare, AlertTriangle, Camera, RotateCcw, CheckCircle2 } from 'lucide-react';

interface CustomerUnreachableModalProps {
  customerName: string;
  customerPhone: string;
  onLeaveInSafePlace: () => void;
  onReturnToRestaurant: () => void;
  onClose: () => void;
}

export const CustomerUnreachableModal: React.FC<CustomerUnreachableModalProps> = ({
  customerName,
  customerPhone,
  onLeaveInSafePlace,
  onReturnToRestaurant,
  onClose,
}) => {
  const [secondsRemaining, setSecondsRemaining] = useState(300); // 5 minutes
  const [callAttempts, setCallAttempts] = useState(1);
  const [smsSent, setSmsSent] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTimer = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleCall = () => {
    setCallAttempts((prev) => prev + 1);
    window.location.href = `tel:${customerPhone}`;
  };

  const handleSendSms = () => {
    setSmsSent(true);
  };

  const isTimerExpired = secondsRemaining === 0;

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle size={18} className="text-amber-400" />
            <h3 className="text-sm font-bold text-white">Customer Unreachable</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 space-y-4">
          {/* Waiting Timer Card */}
          <div className="bg-gradient-to-br from-amber-950/40 via-slate-950 to-slate-950 p-4 rounded-2xl border border-amber-500/30 text-center space-y-1">
            <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-widest block">
              MANDATORY DOORSTEP WAITING PERIOD
            </span>
            <div className="flex items-center justify-center gap-2">
              <Clock size={22} className="text-amber-400 animate-pulse" />
              <span className="text-3xl font-black text-white font-mono tracking-wider">
                {formatTimer(secondsRemaining)}
              </span>
            </div>
            <p className="text-[11px] text-slate-300">
              Partner safety protocols require waiting 5 minutes before resolving.
            </p>
          </div>

          {/* Contact Attempts Checklist */}
          <div className="bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800 space-y-2 text-xs">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Required Contact Protocol
            </span>

            <div className="flex items-center justify-between py-1 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <CheckCircle2 size={14} className="text-emerald-400" />
                <span className="text-slate-300">Call Customer (Attempt #{callAttempts})</span>
              </div>
              <button
                onClick={handleCall}
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-sky-400 rounded-lg font-bold flex items-center gap-1 border border-slate-700"
              >
                <PhoneCall size={12} />
                <span>Call Again</span>
              </button>
            </div>

            <div className="flex items-center justify-between py-1">
              <div className="flex items-center gap-2">
                {smsSent ? (
                  <CheckCircle2 size={14} className="text-emerald-400" />
                ) : (
                  <Clock size={14} className="text-slate-500" />
                )}
                <span className="text-slate-300">Automated Doorstep SMS</span>
              </div>
              <button
                onClick={handleSendSms}
                disabled={smsSent}
                className="px-2.5 py-1 bg-slate-800 disabled:opacity-40 hover:bg-slate-700 text-amber-400 rounded-lg font-bold flex items-center gap-1 border border-slate-700"
              >
                <MessageSquare size={12} />
                <span>{smsSent ? 'SMS Sent' : 'Send SMS'}</span>
              </button>
            </div>
          </div>

          {/* Escalation Options (Available after 5 minutes or simulated immediately for testing) */}
          <div className="space-y-2 pt-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Support Authorized Actions
              </span>
              {!isTimerExpired && (
                <button
                  onClick={() => setSecondsRemaining(0)}
                  className="text-[10px] text-amber-400 underline font-semibold"
                >
                  Skip 5m Timer (Dev)
                </button>
              )}
            </div>

            <button
              onClick={onLeaveInSafePlace}
              disabled={!isTimerExpired}
              className="w-full py-2.5 bg-slate-800 disabled:opacity-40 hover:bg-slate-700 text-sky-300 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border border-slate-700 transition"
            >
              <Camera size={14} />
              <span>Leave in Safe Place (Take Photo Proof)</span>
            </button>

            <button
              onClick={onReturnToRestaurant}
              disabled={!isTimerExpired}
              className="w-full py-2.5 bg-rose-950/80 disabled:opacity-40 hover:bg-rose-900 text-rose-300 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border border-rose-800/60 transition"
            >
              <RotateCcw size={14} />
              <span>Return to Restaurant (+₹45 Return Pay)</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800">
          <button
            onClick={onClose}
            className="w-full py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-bold"
          >
            Customer Responded / Resume Delivery
          </button>
        </div>
      </div>
    </div>
  );
};
