import React, { useState } from 'react';
import { X, CheckSquare, Square, PackageCheck, AlertCircle } from 'lucide-react';
import { OrderItem } from '../../types/delivery.types';

interface ItemChecklistModalProps {
  orderNumber: string;
  restaurantName: string;
  items: OrderItem[];
  pickupCode?: string;
  onConfirmPickup: () => void;
  onClose: () => void;
}

export const ItemChecklistModal: React.FC<ItemChecklistModalProps> = ({
  orderNumber,
  restaurantName,
  items,
  pickupCode = 'PK-82',
  onConfirmPickup,
  onClose,
}) => {
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});
  const [isBagVerified, setIsBagVerified] = useState(false);
  const [isSealIntact, setIsSealIntact] = useState(false);

  const toggleItem = (id: string) => {
    setCheckedItems((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const allItemsChecked = items.length > 0 && items.every((item) => checkedItems[item.id]);
  const canConfirm = allItemsChecked && isBagVerified && isSealIntact;

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm max-h-[90vh] bg-slate-900 border border-slate-700 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-orange-400 uppercase tracking-wider block">
              RESTAURANT PICKUP VERIFICATION
            </span>
            <h3 className="text-sm font-extrabold text-white">{restaurantName}</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 overflow-y-auto space-y-4">
          {/* Pickup Code Display */}
          <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-400 block font-mono">Counter Pickup Code</span>
              <span className="text-lg font-black text-amber-400 font-mono tracking-wider">
                {pickupCode}
              </span>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block font-mono">Order Number</span>
              <span className="text-xs font-bold text-white font-mono">{orderNumber}</span>
            </div>
          </div>

          {/* Item-by-item checklist */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Verify All Package Items ({items.length})
              </span>
              <button
                onClick={() => {
                  const allTrue: Record<string, boolean> = {};
                  items.forEach((it) => (allTrue[it.id] = true));
                  setCheckedItems(allTrue);
                }}
                className="text-[10px] font-bold text-orange-400 hover:text-orange-300"
              >
                Check All
              </button>
            </div>

            <div className="space-y-1.5">
              {items.map((item) => {
                const isChecked = !!checkedItems[item.id];
                return (
                  <div
                    key={item.id}
                    onClick={() => toggleItem(item.id)}
                    className={`p-3 rounded-xl border cursor-pointer transition flex items-start gap-2.5 ${
                      isChecked
                        ? 'bg-emerald-950/30 border-emerald-500/40 text-white'
                        : 'bg-slate-950/70 border-slate-800 text-slate-300 hover:bg-slate-950'
                    }`}
                  >
                    <div className="mt-0.5 text-emerald-400">
                      {isChecked ? <CheckSquare size={16} /> : <Square size={16} className="text-slate-500" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold truncate">{item.name}</span>
                        <span className="text-xs font-mono font-bold text-amber-400">x{item.quantity}</span>
                      </div>
                      {item.specialInstructions && (
                        <p className="text-[10px] text-orange-300 mt-0.5 italic">
                          Note: {item.specialInstructions}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Food Quality & Bag Compliance Checkboxes */}
          <div className="bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800 space-y-2.5 text-xs">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Safety & Hygiene Protocols
            </span>

            <label
              onClick={() => setIsBagVerified(!isBagVerified)}
              className="flex items-start gap-2.5 cursor-pointer text-slate-300 hover:text-white"
            >
              <div className="mt-0.5 text-orange-400">
                {isBagVerified ? <CheckSquare size={15} /> : <Square size={15} className="text-slate-500" />}
              </div>
              <span className="leading-snug">
                Food packages placed upright inside <strong>insulated thermal bag</strong> (hot/cold separated).
              </span>
            </label>

            <label
              onClick={() => setIsSealIntact(!isSealIntact)}
              className="flex items-start gap-2.5 cursor-pointer text-slate-300 hover:text-white"
            >
              <div className="mt-0.5 text-orange-400">
                {isSealIntact ? <CheckSquare size={15} /> : <Square size={15} className="text-slate-500" />}
              </div>
              <span className="leading-snug">
                Restaurant packaging is <strong>spill-proof</strong> and tamper-evident sticker is intact.
              </span>
            </label>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 space-y-2">
          {!canConfirm && (
            <p className="text-[10px] text-center text-slate-400 flex items-center justify-center gap-1">
              <AlertCircle size={11} className="text-amber-400" />
              <span>Verify all items and safety checks to unlock pickup</span>
            </p>
          )}

          <button
            onClick={onConfirmPickup}
            disabled={!canConfirm}
            className="w-full py-3 bg-emerald-600 disabled:opacity-40 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-emerald-950/40 active:scale-98 flex items-center justify-center gap-2"
          >
            <PackageCheck size={16} />
            <span>CONFIRM PICKUP & START DELIVERY</span>
          </button>
        </div>
      </div>
    </div>
  );
};
