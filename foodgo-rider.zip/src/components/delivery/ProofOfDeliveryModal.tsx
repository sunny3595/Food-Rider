import React, { useState } from 'react';
import { X, Camera, RefreshCw, CheckCircle2, ShieldCheck } from 'lucide-react';
import { useRider } from '../../store/riderStore';

interface ProofOfDeliveryModalProps {
  orderNumber: string;
  customerName: string;
  onPhotoVerified: (photoUrl: string) => void;
  onClose: () => void;
}

export const ProofOfDeliveryModal: React.FC<ProofOfDeliveryModalProps> = ({
  orderNumber,
  customerName,
  onPhotoVerified,
  onClose,
}) => {
  const { lastLocation } = useRider();
  const [photoCaptured, setPhotoCaptured] = useState<string | null>(null);
  const [isCapturing, setIsCapturing] = useState(false);

  const sampleProofImages = [
    'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=400&q=80',
    'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=400&q=80',
    'https://images.unsplash.com/photo-1529193591184-b1d58069ecdd?auto=format&fit=crop&w=400&q=80',
  ];

  const handleCapture = () => {
    setIsCapturing(true);
    setTimeout(() => {
      const randomImg = sampleProofImages[Math.floor(Math.random() * sampleProofImages.length)];
      setPhotoCaptured(randomImg);
      setIsCapturing(false);
    }, 600);
  };

  const handleConfirm = () => {
    if (photoCaptured) {
      onPhotoVerified(photoCaptured);
    }
  };

  const formattedCoords = `${lastLocation.latitude.toFixed(4)}° N, ${lastLocation.longitude.toFixed(4)}° E`;
  const formattedTime = new Date().toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-60 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Camera size={18} className="text-sky-400" />
            <h3 className="text-sm font-bold text-white">Contactless Photo Proof</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Viewfinder / Preview */}
        <div className="p-4 space-y-3">
          <div className="relative w-full h-64 bg-black rounded-2xl overflow-hidden border border-slate-800 flex items-center justify-center">
            {photoCaptured ? (
              <img
                src={photoCaptured}
                alt="Delivery Proof"
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="text-center space-y-2 p-4">
                <div className="w-14 h-14 rounded-full bg-slate-800/80 border border-slate-700 flex items-center justify-center text-slate-400 mx-auto">
                  <Camera size={26} className={isCapturing ? 'animate-spin' : ''} />
                </div>
                <p className="text-xs text-slate-300">
                  Align parcel at the customer doorstep or safe drop zone inside frame.
                </p>
              </div>
            )}

            {/* In-photo Watermark Overlay */}
            <div className="absolute bottom-2 left-2 right-2 bg-black/75 backdrop-blur-xs p-2 rounded-xl text-[10px] font-mono text-slate-300 space-y-0.5 border border-white/10">
              <div className="flex justify-between text-white font-bold">
                <span>ORDER: {orderNumber}</span>
                <span>{formattedTime}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>RECIPIENT: {customerName}</span>
                <span>{formattedCoords}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
            <ShieldCheck size={13} className="text-emerald-400 shrink-0" />
            <span>Encrypted GPS and time metadata are stamped to verify dropoff.</span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex gap-2">
          {photoCaptured ? (
            <>
              <button
                onClick={() => setPhotoCaptured(null)}
                className="flex-1 py-3 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5"
              >
                <RefreshCw size={14} />
                <span>Retake</span>
              </button>

              <button
                onClick={handleConfirm}
                className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-emerald-950/40 flex items-center justify-center gap-1.5"
              >
                <CheckCircle2 size={14} />
                <span>Submit Proof</span>
              </button>
            </>
          ) : (
            <button
              onClick={handleCapture}
              disabled={isCapturing}
              className="w-full py-3.5 bg-[#FF5200] hover:bg-orange-600 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-orange-950/40 flex items-center justify-center gap-2"
            >
              <Camera size={16} />
              <span>CAPTURE DOORSTEP PHOTO</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
