import React, { useState } from 'react';
import { X, Banknote, QrCode, CheckCircle2, IndianRupee, AlertCircle } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

interface CodChangeCalculatorModalProps {
  orderTotal: number;
  onConfirmCollection: (amount: number, method: 'CASH' | 'UPI_QR') => void;
  onClose: () => void;
}

export const CodChangeCalculatorModal: React.FC<CodChangeCalculatorModalProps> = ({
  orderTotal,
  onConfirmCollection,
  onClose,
}) => {
  const [paymentMode, setPaymentMode] = useState<'CASH' | 'UPI_QR'>('CASH');
  const [tenderAmount, setTenderAmount] = useState<number>(orderTotal);
  const [showUpiQr, setShowUpiQr] = useState(false);

  const presets = [
    orderTotal,
    Math.ceil(orderTotal / 100) * 100,
    1000,
    2000,
  ].filter((val, idx, arr) => arr.indexOf(val) === idx && val >= orderTotal);

  const changeDue = Math.max(0, tenderAmount - orderTotal);

  const handleConfirm = () => {
    onConfirmCollection(orderTotal, paymentMode);
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Banknote size={18} className="text-amber-400" />
            <h3 className="text-sm font-bold text-white">Cash on Delivery (COD)</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 space-y-4">
          {/* Invoice Hero */}
          <div className="bg-gradient-to-br from-amber-950/30 via-slate-950 to-slate-950 p-4 rounded-2xl border border-amber-500/30 text-center space-y-1">
            <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest block">
              Exact Invoice to Collect
            </span>
            <span className="text-3xl font-black text-white font-mono tracking-tight block">
              {formatCurrency(orderTotal)}
            </span>
            <span className="text-[10px] text-slate-400 block">
              Hand over order only after verifying cash receipt or UPI confirmation
            </span>
          </div>

          {/* Payment Method Switcher (Cash vs UPI QR) */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                setPaymentMode('CASH');
                setShowUpiQr(false);
              }}
              className={`p-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition ${
                paymentMode === 'CASH'
                  ? 'bg-amber-600 text-white border-amber-400 shadow-md'
                  : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-900'
              }`}
            >
              <Banknote size={15} />
              <span>Cash in Hand</span>
            </button>

            <button
              onClick={() => {
                setPaymentMode('UPI_QR');
                setShowUpiQr(true);
              }}
              className={`p-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition ${
                paymentMode === 'UPI_QR'
                  ? 'bg-emerald-600 text-white border-emerald-400 shadow-md'
                  : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-900'
              }`}
            >
              <QrCode size={15} />
              <span>Customer UPI QR</span>
            </button>
          </div>

          {paymentMode === 'CASH' ? (
            <div className="space-y-3">
              {/* Presets */}
              <div>
                <span className="text-[11px] font-bold text-slate-400 block mb-1.5">
                  How much cash did the customer tender?
                </span>
                <div className="grid grid-cols-4 gap-1.5">
                  {presets.map((amt) => (
                    <button
                      key={amt}
                      onClick={() => setTenderAmount(amt)}
                      className={`py-2 px-1 rounded-xl text-xs font-mono font-bold border transition ${
                        tenderAmount === amt
                          ? 'bg-[#FF5200] text-white border-orange-400 shadow'
                          : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-900'
                      }`}
                    >
                      {formatCurrency(amt)}
                    </button>
                  ))}
                </div>
              </div>

              {/* Change Due Box */}
              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">
                    Change to Return
                  </span>
                  <span className="text-xl font-black text-emerald-400 font-mono">
                    {formatCurrency(changeDue)}
                  </span>
                </div>
                <div className="text-right text-[11px] text-slate-400">
                  {changeDue === 0 ? 'Exact Amount' : `Return ${formatCurrency(changeDue)} in change`}
                </div>
              </div>
            </div>
          ) : (
            /* UPI Dynamic QR Simulation */
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-center space-y-2">
              <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block">
                Instant UPI Payment Gateway
              </span>
              <div className="w-32 h-32 bg-white p-2 rounded-xl mx-auto flex items-center justify-center shadow-lg">
                {/* Simulated QR Pattern */}
                <div className="w-full h-full border-2 border-slate-900 border-dashed flex flex-col items-center justify-center p-1 text-slate-900">
                  <QrCode size={48} className="text-slate-900" />
                  <span className="text-[8px] font-mono font-bold mt-1">SCAN TO PAY</span>
                  <span className="text-[9px] font-bold font-mono">₹{orderTotal}</span>
                </div>
              </div>
              <p className="text-[11px] text-slate-300">
                Ask customer to scan using GPay, PhonePe, or Paytm.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 space-y-2">
          <button
            onClick={handleConfirm}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-emerald-950/40 active:scale-98 flex items-center justify-center gap-2"
          >
            <CheckCircle2 size={16} />
            <span>CONFIRM {formatCurrency(orderTotal)} RECEIVED</span>
          </button>
        </div>
      </div>
    </div>
  );
};
