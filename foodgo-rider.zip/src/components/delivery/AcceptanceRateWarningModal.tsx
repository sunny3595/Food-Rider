import React from 'react';
import { X, AlertTriangle, ShieldAlert, Award, TrendingUp, CheckCircle } from 'lucide-react';
import { useDelivery } from '../../store/deliveryStore';

export const AcceptanceRateWarningModal: React.FC = () => {
  const { isAcceptanceRateWarningOpen, setAcceptanceRateWarningOpen, acceptanceMetrics } =
    useDelivery();

  if (!isAcceptanceRateWarningOpen) return null;

  const rate = acceptanceMetrics.ratePercentage;

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-60 flex items-center justify-center p-4 animate-fadeIn">
      <div className="w-full max-w-sm bg-slate-900 border border-amber-500/50 rounded-3xl p-5 shadow-2xl space-y-4 text-center">
        {/* Warning Icon */}
        <div className="w-14 h-14 mx-auto rounded-3xl bg-amber-500/10 border-2 border-amber-500/40 flex items-center justify-center text-amber-400">
          <AlertTriangle size={28} />
        </div>

        <div>
          <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-widest block">
            ACCEPTANCE RATE WARNING
          </span>
          <h3 className="text-base font-extrabold text-white mt-1">
            Current Acceptance Rate: {rate}%
          </h3>
          <p className="text-xs text-slate-300 mt-1 max-w-xs mx-auto leading-relaxed">
            Your order acceptance has dropped below the recommended partner threshold of 80%.
          </p>
        </div>

        {/* Policy Thresholds Grid */}
        <div className="bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800 text-left space-y-2.5 text-xs">
          <div className="flex items-start gap-2.5">
            <span className="w-2 h-2 rounded-full bg-amber-400 mt-1.5 shrink-0" />
            <div>
              <span className="font-bold text-white block">&lt; 75% Acceptance Rate:</span>
              <span className="text-[11px] text-slate-400">System alert and partner quality flag.</span>
            </div>
          </div>

          <div className="flex items-start gap-2.5">
            <span className="w-2 h-2 rounded-full bg-rose-400 mt-1.5 shrink-0" />
            <div>
              <span className="font-bold text-white block">&lt; 70% Acceptance Rate:</span>
              <span className="text-[11px] text-slate-400">
                Disqualification from daily shift bonus and dinner surges.
              </span>
            </div>
          </div>

          <div className="flex items-start gap-2.5">
            <span className="w-2 h-2 rounded-full bg-rose-600 mt-1.5 shrink-0" />
            <div>
              <span className="font-bold text-white block">&lt; 60% Acceptance Rate:</span>
              <span className="text-[11px] text-slate-400">
                Dispatch algorithm deprioritizes order matching for 24 hours.
              </span>
            </div>
          </div>
        </div>

        {/* Recovery Tip */}
        <div className="bg-emerald-950/40 border border-emerald-500/30 p-3 rounded-xl text-left flex items-start gap-2 text-xs text-emerald-300">
          <CheckCircle size={15} className="shrink-0 mt-0.5" />
          <span>
            <strong>Recovery Tip:</strong> Accepting your next 5 consecutive delivery offers will restore your rating above 80%.
          </span>
        </div>

        <button
          onClick={() => setAcceptanceRateWarningOpen(false)}
          className="w-full py-3 bg-[#FF5200] hover:bg-orange-600 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-orange-950/40"
        >
          I UNDERSTAND
        </button>
      </div>
    </div>
  );
};
