import React, { useState } from 'react';
import {
  Clock,
  Navigation,
  MapPin,
  IndianRupee,
  Store,
  User,
  X,
  Check,
  Layers,
  Zap,
  Banknote,
  ChevronDown,
  ChevronUp,
  Volume2,
} from 'lucide-react';
import { useDelivery } from '../../store/deliveryStore';
import { useTheme } from '../../store/themeStore';
import { formatCurrency, formatDistance, formatDuration } from '../../utils/formatters';
import { DeclineReasonModal } from './DeclineReasonModal';
import { AcceptanceRateWarningModal } from './AcceptanceRateWarningModal';

export const DeliveryRequestModal: React.FC = () => {
  const {
    pendingRequest,
    requestSecondsRemaining,
    acceptIncomingRequest,
    setDeclineModalOpen,
    isProcessing,
  } = useDelivery();
  const { soundEnabled } = useTheme();
  const [showEarningsBreakdown, setShowEarningsBreakdown] = useState(false);

  if (!pendingRequest) return null;

  const totalTime = pendingRequest.timeoutSecondsTotal || 25;
  const progressPercent = Math.max(0, (requestSecondsRemaining / totalTime) * 100);

  const breakdown = pendingRequest.financialsBreakdown || {
    basePay: 40,
    distancePay: 28,
    surgePay: 15,
    tip: 15,
  };

  return (
    <>
      <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-end sm:items-center justify-center p-3 animate-fadeIn">
        <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl overflow-hidden shadow-2xl animate-slideUp">
          {/* Progress Countdown Bar */}
          <div className="w-full bg-slate-800 h-2">
            <div
              className={`h-full transition-all duration-1000 ease-linear ${
                requestSecondsRemaining <= 5 ? 'bg-rose-500' : 'bg-[#FF5200]'
              }`}
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          {/* Header Card */}
          <div className="px-5 pt-3.5 pb-2.5 flex items-center justify-between border-b border-slate-800 bg-slate-950/70">
            <div className="flex items-center gap-2">
              {pendingRequest.isBatchOrder ? (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40 flex items-center gap-1">
                  <Layers size={11} />
                  <span>BATCH: 2 ORDERS</span>
                </span>
              ) : pendingRequest.isStackedAddOn ? (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1">
                  <Zap size={11} />
                  <span>ROUTE ADD-ON</span>
                </span>
              ) : (
                <span className="text-[10px] font-bold tracking-widest text-[#FF5200] uppercase">
                  NEW DELIVERY REQUEST
                </span>
              )}
              <span className="text-xs font-mono font-bold text-white">{pendingRequest.orderNumber}</span>
            </div>

            {/* Countdown Badge */}
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded-full font-mono text-xs font-bold animate-pulse">
              <Clock size={12} />
              <span>{requestSecondsRemaining}s</span>
            </div>
          </div>

          {/* Earnings & Route Hero Banner */}
          <div className="px-5 py-3.5 bg-gradient-to-br from-slate-900 via-slate-850 to-orange-950/30 border-b border-slate-800/80 flex items-center justify-between">
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] text-slate-400">Guaranteed Pay</span>
                <button
                  onClick={() => setShowEarningsBreakdown(!showEarningsBreakdown)}
                  className="text-orange-400 hover:text-orange-300"
                >
                  {showEarningsBreakdown ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
                </button>
              </div>

              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-black text-emerald-400 tracking-tight font-mono">
                  {formatCurrency(pendingRequest.estimatedEarnings)}
                </span>
                {breakdown.tip > 0 && (
                  <span className="text-[10px] text-amber-300 font-semibold">+₹{breakdown.tip} tip</span>
                )}
              </div>
            </div>

            <div className="text-right">
              <span className="text-[11px] text-slate-400 block">Total Trip</span>
              <div className="flex items-center justify-end gap-1 text-slate-200 font-semibold text-xs font-mono">
                <Navigation size={12} className="text-[#FF5200]" />
                <span>{formatDistance(pendingRequest.totalDistanceKm)}</span>
                <span className="text-slate-400 font-normal">
                  ({formatDuration(pendingRequest.estimatedTimeMinutes)})
                </span>
              </div>
            </div>
          </div>

          {/* Collapsible Earnings Breakdown */}
          {showEarningsBreakdown && (
            <div className="bg-slate-950 px-5 py-2.5 border-b border-slate-800 text-xs space-y-1 font-mono text-slate-300 animate-fadeIn">
              <div className="flex justify-between">
                <span className="text-slate-400">Base Pickup Pay:</span>
                <span>{formatCurrency(breakdown.basePay)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Distance Travel Pay:</span>
                <span>{formatCurrency(breakdown.distancePay)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Peak Hour Surge:</span>
                <span className="text-amber-400">+{formatCurrency(breakdown.surgePay)}</span>
              </div>
              {breakdown.tip > 0 && (
                <div className="flex justify-between">
                  <span className="text-slate-400">Customer Tip:</span>
                  <span className="text-emerald-400">+{formatCurrency(breakdown.tip)}</span>
                </div>
              )}
            </div>
          )}

          {/* Route & Items Body */}
          <div className="p-4 space-y-3">
            {/* Primary Order Route */}
            <div className="space-y-2">
              {/* Pickup */}
              <div className="flex items-start gap-2.5">
                <div className="w-7 h-7 rounded-full bg-orange-500/20 text-[#FF5200] flex items-center justify-center shrink-0 mt-0.5 border border-orange-500/30">
                  <Store size={13} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-bold text-slate-400">Pickup</span>
                    <span className="text-[11px] font-semibold text-orange-400">
                      {formatDistance(pendingRequest.distanceToPickupKm)}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-white truncate">{pendingRequest.restaurant.name}</h4>
                  <p className="text-[10px] text-slate-400 truncate">{pendingRequest.restaurant.location.area}</p>
                </div>
              </div>

              {/* Dotted connecting line */}
              <div className="ml-3.5 pl-0.5 border-l-2 border-dashed border-slate-700 h-2.5"></div>

              {/* Dropoff */}
              <div className="flex items-start gap-2.5">
                <div className="w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 border border-emerald-500/30">
                  <User size={13} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-bold text-slate-400">Dropoff</span>
                    <span className="text-[11px] font-semibold text-emerald-400">
                      {formatDistance(pendingRequest.distanceToCustomerKm)}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-white truncate">{pendingRequest.customer.name}</h4>
                  <p className="text-[10px] text-slate-400 truncate">{pendingRequest.customer.location.area}</p>
                </div>
              </div>
            </div>

            {/* Batch Secondary Order Preview if applicable */}
            {pendingRequest.batchSecondaryOrder && (
              <div className="p-2.5 bg-purple-950/30 border border-purple-500/30 rounded-2xl space-y-1">
                <span className="text-[10px] uppercase font-bold text-purple-300 block">
                  Stacked Order 2 Preview
                </span>
                <p className="text-xs font-bold text-white truncate">
                  {pendingRequest.batchSecondaryOrder.restaurantName} → {pendingRequest.batchSecondaryOrder.customerName}
                </p>
                <p className="text-[10px] text-slate-400">
                  {pendingRequest.batchSecondaryOrder.customerAddress}
                </p>
              </div>
            )}

            {/* Payment Collection Tag */}
            <div className="p-2 bg-slate-950 rounded-xl flex items-center justify-between text-xs border border-slate-800">
              <span className="text-slate-400 text-[11px]">Payment Mode:</span>
              {pendingRequest.paymentMethod === 'CASH_ON_DELIVERY' ? (
                <span className="font-bold text-amber-400 flex items-center gap-1">
                  <Banknote size={13} />
                  <span>Collect COD Cash: ₹640</span>
                </span>
              ) : (
                <span className="font-bold text-emerald-400 flex items-center gap-1">
                  <Check size={13} />
                  <span>Prepaid Order (No Cash)</span>
                </span>
              )}
            </div>

            {/* Actions: Accept or Decline with reasons */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={() => setDeclineModalOpen(true)}
                disabled={isProcessing}
                className="py-3 px-3 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95 border border-slate-700"
              >
                <X size={14} />
                <span>DECLINE</span>
              </button>

              <button
                onClick={acceptIncomingRequest}
                disabled={isProcessing}
                className="py-3 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-950/50 transition active:scale-95"
              >
                <Check size={15} />
                <span>{isProcessing ? 'ACCEPTING...' : 'ACCEPT DELIVERY'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Decline Reason Modal */}
      <DeclineReasonModal />

      {/* Acceptance Rate Warning Modal */}
      <AcceptanceRateWarningModal />
    </>
  );
};
