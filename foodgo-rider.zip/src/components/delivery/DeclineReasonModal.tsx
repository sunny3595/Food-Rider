import React, { useState } from 'react';
import { X, AlertTriangle, ChevronRight, ThumbsDown, ShieldAlert } from 'lucide-react';
import { useDelivery } from '../../store/deliveryStore';

const DECLINE_REASONS = [
  'Distance too far from my current location',
  'Earnings too low for travel distance',
  'Vehicle issue or low fuel level',
  'Personal emergency / urgent errand',
  'Ending shift / heading back home',
  'Restaurant known for long food prep wait times',
  'Heavy rain or poor weather conditions in drop zone',
  'Other reason',
];

export const DeclineReasonModal: React.FC = () => {
  const { isDeclineModalOpen, setDeclineModalOpen, declineIncomingRequest, acceptanceMetrics } =
    useDelivery();
  const [selectedReason, setSelectedReason] = useState<string>(DECLINE_REASONS[0]);

  if (!isDeclineModalOpen) return null;

  const currentRate = acceptanceMetrics.ratePercentage;
  const projectedRate = Math.round(
    (acceptanceMetrics.totalAccepted / (acceptanceMetrics.totalOffered + 1)) * 100
  );

  const handleSubmit = async () => {
    await declineIncomingRequest(selectedReason);
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-60 flex items-center justify-center p-4 animate-fadeIn">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl p-5 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2 text-rose-400">
            <ThumbsDown size={18} />
            <h3 className="text-sm font-bold text-white">Decline Delivery Request</h3>
          </div>
          <button
            onClick={() => setDeclineModalOpen(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-white"
          >
            <X size={18} />
          </button>
        </div>

        {/* Acceptance Rate Impact Warning Banner */}
        <div className="p-3 bg-amber-950/40 border border-amber-500/30 rounded-2xl flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <AlertTriangle size={16} className="text-amber-400 shrink-0" />
            <div>
              <span className="text-slate-300 font-semibold block">Acceptance Rate Impact</span>
              <span className="text-[10px] text-slate-400">
                Current: <strong className="text-white">{currentRate}%</strong> → Projected:{' '}
                <strong className="text-amber-400">{projectedRate}%</strong>
              </span>
            </div>
          </div>
          <span className="text-[10px] font-bold text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
            Min 80%
          </span>
        </div>

        {/* Reason Selector */}
        <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
          <span className="text-[11px] font-bold text-slate-400 block mb-1">
            Why are you declining this order?
          </span>
          {DECLINE_REASONS.map((reason) => (
            <label
              key={reason}
              className={`flex items-center justify-between p-2.5 rounded-xl border text-xs cursor-pointer transition ${
                selectedReason === reason
                  ? 'bg-rose-950/40 border-rose-500/60 text-white'
                  : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-950'
              }`}
            >
              <span className="leading-snug pr-2">{reason}</span>
              <input
                type="radio"
                name="decline_reason"
                checked={selectedReason === reason}
                onChange={() => setSelectedReason(reason)}
                className="accent-rose-500 w-4 h-4 shrink-0"
              />
            </label>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 pt-1">
          <button
            onClick={handleSubmit}
            className="w-full py-3 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-rose-950/40 active:scale-98"
          >
            CONFIRM DECLINE & REASSIGN
          </button>

          <button
            onClick={() => setDeclineModalOpen(false)}
            className="w-full py-2 text-xs text-slate-400 hover:text-white transition"
          >
            Go Back & Accept Instead
          </button>
        </div>
      </div>
    </div>
  );
};
