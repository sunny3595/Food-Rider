import React, { useState } from 'react';
import {
  Send,
  X,
  User,
  Phone,
  CheckCheck,
  Store,
  Headphones,
  Mic,
  Camera,
  Paperclip,
  Trash2,
  AlertTriangle,
  ShieldCheck,
  PlusCircle,
} from 'lucide-react';
import { useDelivery } from '../../store/deliveryStore';
import { useChat } from '../../store/chatStore';
import { ChatChannel } from '../../types/chat.types';
import { VoipCallOverlay } from './VoipCallOverlay';
import { SupportTicketModal } from './SupportTicketModal';

interface ChatModalProps {
  onClose: () => void;
}

export const ChatModal: React.FC<ChatModalProps> = ({ onClose }) => {
  const { activeDelivery } = useDelivery();
  const {
    activeChannel,
    setActiveChannel,
    messages,
    sendMessage,
    startVoiceRecording,
    stopAndSendVoiceRecording,
    cancelVoiceRecording,
    isRecordingVoice,
    recordingSeconds,
    startVoipCall,
  } = useChat();

  const [inputText, setInputText] = useState('');
  const [isTicketModalOpen, setIsTicketModalOpen] = useState(false);

  const currentMessages = messages[activeChannel] || [];

  const customerQuickReplies = [
    'On my way with your hot order!',
    'I have arrived outside your building/gate.',
    'Please come down to collect the delivery.',
    'Running slightly delayed due to traffic (+8m).',
  ];

  const restaurantQuickReplies = [
    'How long until order #10245 is packed?',
    'I am waiting outside at the pickup counter.',
    'Please verify all drinks are spill-sealed.',
  ];

  const supportQuickReplies = [
    'Customer unreachable at doorstep',
    'Food package damaged in transit',
    'Emergency roadside assistance needed',
  ];

  const activeQuickReplies =
    activeChannel === 'CUSTOMER'
      ? customerQuickReplies
      : activeChannel === 'RESTAURANT'
      ? restaurantQuickReplies
      : supportQuickReplies;

  const handleSend = (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim()) return;
    sendMessage(activeChannel, text);
    if (!textToSend) setInputText('');
  };

  const handleCall = () => {
    if (activeChannel === 'CUSTOMER') {
      startVoipCall(
        activeDelivery?.customer.name || 'Aarav Sharma',
        'CUSTOMER'
      );
    } else if (activeChannel === 'RESTAURANT') {
      startVoipCall(
        activeDelivery?.restaurant.name || 'Burger King',
        'RESTAURANT'
      );
    } else {
      startVoipCall('FoodGo Fleet Support', 'SUPPORT');
    }
  };

  const handleSendSamplePhoto = () => {
    sendMessage(
      activeChannel,
      '📷 Attached Photo: Store counter wait board',
      'IMAGE',
      'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=400&q=80'
    );
  };

  return (
    <>
      <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fadeIn">
        <div className="w-full max-w-sm h-[600px] bg-slate-900 border border-slate-700 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
          {/* Channel Tabs */}
          <div className="p-2 bg-slate-950 border-b border-slate-800 flex gap-1">
            <button
              onClick={() => setActiveChannel('CUSTOMER')}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                activeChannel === 'CUSTOMER'
                  ? 'bg-[#FF5200] text-white shadow-md'
                  : 'bg-slate-900 text-slate-400 hover:text-white'
              }`}
            >
              <User size={13} />
              <span>Customer</span>
            </button>

            <button
              onClick={() => setActiveChannel('RESTAURANT')}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                activeChannel === 'RESTAURANT'
                  ? 'bg-[#FF5200] text-white shadow-md'
                  : 'bg-slate-900 text-slate-400 hover:text-white'
              }`}
            >
              <Store size={13} />
              <span>Restaurant</span>
            </button>

            <button
              onClick={() => setActiveChannel('SUPPORT')}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                activeChannel === 'SUPPORT'
                  ? 'bg-amber-600 text-white shadow-md'
                  : 'bg-slate-900 text-slate-400 hover:text-white'
              }`}
            >
              <Headphones size={13} />
              <span>Support</span>
            </button>
          </div>

          {/* Sub Header Card */}
          <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <div>
              <h4 className="text-xs font-bold text-white">
                {activeChannel === 'CUSTOMER'
                  ? activeDelivery?.customer.name || 'Aarav Sharma'
                  : activeChannel === 'RESTAURANT'
                  ? activeDelivery?.restaurant.name || 'Burger King'
                  : 'FoodGo Fleet Help Desk (24/7)'}
              </h4>
              <span className="text-[10px] text-emerald-400 font-mono font-medium flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>Encrypted Line Active</span>
              </span>
            </div>

            <div className="flex items-center gap-2">
              {activeChannel === 'SUPPORT' ? (
                <button
                  onClick={() => setIsTicketModalOpen(true)}
                  className="px-2 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-lg text-[10px] font-bold"
                >
                  Raise Ticket
                </button>
              ) : (
                <button
                  onClick={handleCall}
                  className="p-1.5 rounded-xl bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-600/30 transition"
                  title="Make Masked Call"
                >
                  <Phone size={14} />
                </button>
              )}

              <button
                onClick={onClose}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X size={16} />
              </button>
            </div>
          </div>

          {/* Message Thread */}
          <div className="flex-1 p-3 overflow-y-auto space-y-2.5 bg-slate-950/60">
            {currentMessages.map((m) => {
              const isMe = m.senderRole === 'RIDER';

              return (
                <div
                  key={m.id}
                  className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[82%] p-3 rounded-2xl text-xs leading-relaxed ${
                      isMe
                        ? 'bg-[#FF5200] text-white rounded-tr-none'
                        : 'bg-slate-850 text-slate-100 rounded-tl-none border border-slate-700'
                    }`}
                  >
                    {!isMe && (
                      <span className="text-[9px] font-bold text-amber-300 block mb-0.5">
                        {m.senderName}
                      </span>
                    )}

                    {m.attachment?.type === 'IMAGE' && m.attachment.url && (
                      <div className="mb-1 rounded-xl overflow-hidden">
                        <img
                          src={m.attachment.url}
                          alt="Attachment"
                          className="w-full h-32 object-cover"
                        />
                      </div>
                    )}

                    <p>{m.text}</p>
                  </div>

                  <div className="flex items-center gap-1 mt-0.5 text-[10px] text-slate-400">
                    <span>{m.timestamp}</span>
                    {isMe && <CheckCheck size={11} className="text-emerald-400" />}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Replies Carousel */}
          <div className="px-3 py-1.5 bg-slate-950 border-t border-slate-800 flex gap-1.5 overflow-x-auto no-scrollbar">
            {activeQuickReplies.map((q, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(q)}
                className="whitespace-nowrap px-2.5 py-1 bg-slate-850 hover:bg-slate-800 text-slate-300 rounded-full text-[10px] font-medium border border-slate-700 shrink-0 transition"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Voice Note Recording Bar or Standard Input */}
          {isRecordingVoice ? (
            <div className="p-3 bg-rose-950/60 border-t border-rose-800 flex items-center justify-between animate-fadeIn">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                <span className="text-xs font-mono font-bold text-rose-300">
                  Recording Voice Note: {recordingSeconds}s
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={cancelVoiceRecording}
                  className="p-1.5 text-slate-400 hover:text-white"
                >
                  <Trash2 size={16} />
                </button>
                <button
                  onClick={() => stopAndSendVoiceRecording(activeChannel)}
                  className="px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold"
                >
                  Send Audio
                </button>
              </div>
            </div>
          ) : (
            <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
              <button
                onClick={handleSendSamplePhoto}
                className="p-2 text-slate-400 hover:text-white"
                title="Send Photo"
              >
                <Camera size={16} />
              </button>

              <button
                onClick={startVoiceRecording}
                className="p-2 text-slate-400 hover:text-orange-400"
                title="Record Voice Note"
              >
                <Mic size={16} />
              </button>

              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Type a message..."
                className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
              />

              <button
                onClick={() => handleSend()}
                disabled={!inputText.trim()}
                className="p-2 bg-[#FF5200] hover:bg-orange-600 disabled:opacity-50 text-white rounded-xl shadow transition"
              >
                <Send size={15} />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* VoIP Secured Calling Overlay */}
      <VoipCallOverlay />

      {/* Support Dispatch Ticket Modal */}
      {isTicketModalOpen && (
        <SupportTicketModal
          orderNumber={activeDelivery?.orderNumber || '#FG-10245'}
          onTicketCreated={(cat, note) => {
            sendMessage('SUPPORT', `🚨 Raised Ticket [${cat}]: ${note || 'Immediate help requested'}`);
          }}
          onClose={() => setIsTicketModalOpen(false)}
        />
      )}
    </>
  );
};
