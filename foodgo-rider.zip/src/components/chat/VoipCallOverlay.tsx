import React from 'react';
import { Phone, PhoneOff, Mic, MicOff, Volume2, VolumeX, ShieldCheck, User } from 'lucide-react';
import { useChat } from '../../store/chatStore';

export const VoipCallOverlay: React.FC = () => {
  const { voipCall, endVoipCall, toggleCallMute, toggleCallSpeaker } = useChat();

  if (!voipCall) return null;

  const formatTimer = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 bg-slate-950/95 backdrop-blur-md z-70 flex flex-col justify-between p-6 animate-fadeIn">
      {/* Top Privacy Number Masking Ribbon */}
      <div className="text-center pt-6 space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-bold">
          <ShieldCheck size={13} />
          <span>Number Masked via Twilio/Exotel Bridge</span>
        </div>
        <p className="text-[11px] text-slate-400 font-mono">
          Virtual Line: {voipCall.maskedProxyNumber}
        </p>
      </div>

      {/* Center Caller Avatar & Status */}
      <div className="text-center space-y-4 my-auto">
        <div className="relative w-28 h-28 mx-auto">
          <div className="absolute inset-0 bg-orange-500/20 rounded-full animate-ping" />
          <div className="relative w-full h-full rounded-full bg-slate-900 border-2 border-slate-700 flex items-center justify-center text-slate-200 shadow-2xl">
            <User size={52} className="text-[#FF5200]" />
          </div>
        </div>

        <div>
          <h2 className="text-xl font-black text-white tracking-tight">{voipCall.targetName}</h2>
          <span className="text-xs text-slate-400 uppercase tracking-widest font-bold block mt-1">
            {voipCall.targetRole}
          </span>
          <div className="mt-2 text-sm font-mono font-bold text-emerald-400">
            {voipCall.status === 'DIALING' ? (
              <span className="animate-pulse">Connecting secured line...</span>
            ) : voipCall.status === 'CONNECTED' ? (
              <span>{formatTimer(voipCall.durationSeconds)}</span>
            ) : (
              <span className="text-rose-400">Call Ended</span>
            )}
          </div>
        </div>
      </div>

      {/* Call Action Controls */}
      <div className="pb-8 space-y-6 max-w-xs mx-auto w-full">
        <div className="flex items-center justify-around">
          {/* Mute Button */}
          <button
            onClick={toggleCallMute}
            className={`w-14 h-14 rounded-full flex items-center justify-center transition border ${
              voipCall.isMuted
                ? 'bg-rose-500 text-white border-rose-400'
                : 'bg-slate-900 text-slate-300 border-slate-700 hover:bg-slate-800'
            }`}
          >
            {voipCall.isMuted ? <MicOff size={22} /> : <Mic size={22} />}
          </button>

          {/* Speaker Button */}
          <button
            onClick={toggleCallSpeaker}
            className={`w-14 h-14 rounded-full flex items-center justify-center transition border ${
              voipCall.isSpeakerOn
                ? 'bg-emerald-600 text-white border-emerald-400'
                : 'bg-slate-900 text-slate-300 border-slate-700 hover:bg-slate-800'
            }`}
          >
            {voipCall.isSpeakerOn ? <Volume2 size={22} /> : <VolumeX size={22} />}
          </button>
        </div>

        {/* End Call Button */}
        <button
          onClick={endVoipCall}
          className="w-full py-4 bg-rose-600 hover:bg-rose-500 text-white rounded-2xl font-bold text-xs flex items-center justify-center gap-2 shadow-xl shadow-rose-950/50 transition active:scale-95"
        >
          <PhoneOff size={18} />
          <span>END SECURED CALL</span>
        </button>
      </div>
    </div>
  );
};
