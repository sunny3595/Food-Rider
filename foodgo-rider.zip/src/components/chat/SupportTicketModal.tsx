import React, { useState } from 'react';
import {
  X,
  HelpCircle,
  AlertTriangle,
  Flame,
  Wrench,
  IndianRupee,
  Store,
  CheckCircle2,
  Send,
  Headphones,
} from 'lucide-react';
import { SupportCategory } from '../../types/chat.types';

interface SupportTicketModalProps {
  orderNumber?: string;
  onTicketCreated: (category: string, note: string) => void;
  onClose: () => void;
}

const CATEGORIES: { id: SupportCategory; label: string; icon: any }[] = [
  { id: 'FOOD_SPILLED', label: 'Food Spilled / Packaging Damaged', icon: AlertTriangle },
  { id: 'CUSTOMER_UNREACHABLE', label: 'Customer Unreachable at Doorstep', icon: HelpCircle },
  { id: 'ACCIDENT_EMERGENCY', label: 'Accident / Vehicle Breakdown Assistance', icon: Wrench },
  { id: 'COD_PAYMENT_DISPUTE', label: 'COD Cash Payment Dispute', icon: IndianRupee },
  { id: 'RESTAURANT_DELAY', label: 'Restaurant Closed / Extreme Prep Delay', icon: Store },
  { id: 'TECHNICAL_APP_ISSUE', label: 'App Technical Glitch / GPS Navigation Error', icon: HelpCircle },
];

export const SupportTicketModal: React.FC<SupportTicketModalProps> = ({
  orderNumber = '#FG-10245',
  onTicketCreated,
  onClose,
}) => {
  const [selectedCat, setSelectedCat] = useState<SupportCategory>('FOOD_SPILLED');
  const [note, setNote] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = () => {
    setIsSubmitted(true);
    setTimeout(() => {
      onTicketCreated(selectedCat, note);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-60 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm max-h-[90vh] bg-slate-900 border border-slate-700 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Headphones size={18} className="text-[#FF5200]" />
            <h3 className="text-sm font-bold text-white">Raise Dispatch Support Ticket</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-4">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-mono block">Order Reference</span>
            <span className="text-xs font-bold text-white font-mono">{orderNumber}</span>
          </div>

          {/* Categories */}
          <div className="space-y-1.5">
            <span className="text-xs font-bold text-slate-300 block mb-1">Select Issue Category</span>
            {CATEGORIES.map((c) => {
              const Icon = c.icon;
              return (
                <div
                  key={c.id}
                  onClick={() => setSelectedCat(c.id)}
                  className={`p-2.5 rounded-xl border text-xs cursor-pointer transition flex items-center gap-2.5 ${
                    selectedCat === c.id
                      ? 'bg-orange-950/40 border-orange-500 text-white font-bold'
                      : 'bg-slate-950/70 border-slate-800 text-slate-300 hover:bg-slate-950'
                  }`}
                >
                  <Icon size={14} className={selectedCat === c.id ? 'text-[#FF5200]' : 'text-slate-500'} />
                  <span>{c.label}</span>
                </div>
              );
            })}
          </div>

          {/* Description */}
          <div className="space-y-1">
            <span className="text-xs font-bold text-slate-300 block">Incident Details (Optional)</span>
            <textarea
              rows={3}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Provide context for the fleet dispatcher..."
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-[#FF5200] resize-none"
            />
          </div>

          {isSubmitted && (
            <div className="p-3 bg-emerald-950/80 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs font-bold flex items-center justify-center gap-2 animate-fadeIn">
              <CheckCircle2 size={16} />
              <span>Ticket #849201 Created! Connecting agent...</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex gap-2">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 bg-slate-800 text-slate-300 rounded-xl text-xs font-bold"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            className="flex-1 py-2.5 bg-[#FF5200] hover:bg-orange-600 text-white rounded-xl text-xs font-bold shadow-md transition"
          >
            Submit Ticket
          </button>
        </div>
      </div>
    </div>
  );
};
