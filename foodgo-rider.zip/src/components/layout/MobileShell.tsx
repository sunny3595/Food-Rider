import React, { useState, useEffect } from 'react';
import { Wifi, Battery, Signal, Sparkles, RefreshCw } from 'lucide-react';
import { useConnection } from '../../store/connectionStore';
import { useTheme } from '../../store/themeStore';
import { APP_CONFIG } from '../../constants/config';

interface MobileShellProps {
  children: React.ReactNode;
}

export const MobileShell: React.FC<MobileShellProps> = ({ children }) => {
  const [currentTime, setCurrentTime] = useState<string>('09:41');
  const { isOnline } = useConnection();
  const { toggleSimulator, isSimulatorOpen } = useTheme();

  useEffect(() => {
    const update = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit',
          hour12: false,
        })
      );
    };
    update();
    const interval = setInterval(update, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-0 md:p-4 select-none">
      {/* Top Desktop Helper Controls */}
      <div className="w-full max-w-[430px] hidden md:flex items-center justify-between pb-2 text-xs text-slate-400 px-2">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="font-bold text-slate-200">{APP_CONFIG.appName}</span>
          <span className="bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded font-mono text-[10px]">
            v{APP_CONFIG.version}
          </span>
        </div>
        <button
          onClick={toggleSimulator}
          className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold transition ${
            isSimulatorOpen
              ? 'bg-amber-500 text-slate-950 shadow'
              : 'bg-slate-800 text-amber-400 hover:bg-slate-750 border border-slate-700'
          }`}
          title="Open Developer Simulator"
        >
          <Sparkles size={13} />
          <span>Dev Simulator</span>
        </button>
      </div>

      {/* Mobile Device Frame */}
      <div className="w-full max-w-[430px] h-[100dvh] md:h-[880px] md:rounded-[44px] border-0 md:border-[10px] border-slate-800 bg-slate-900 shadow-2xl relative flex flex-col overflow-hidden ring-1 ring-slate-700/50">
        {/* Offline Banner alert if network drops */}
        {!isOnline && (
          <div className="bg-amber-600/90 text-white text-xs px-3 py-1.5 flex items-center justify-between z-50 animate-fadeIn">
            <div className="flex items-center gap-1.5">
              <RefreshCw size={12} className="animate-spin" />
              <span>Offline: trying to reconnect to delivery network...</span>
            </div>
            <span className="font-mono text-[10px] uppercase font-bold">Cached Mode</span>
          </div>
        )}

        {/* Mobile Device Status Bar */}
        <div className="w-full pt-3 px-6 pb-1 flex items-center justify-between text-xs text-slate-300 bg-slate-900/95 backdrop-blur z-40 select-none">
          {/* Real Time */}
          <span className="font-semibold text-[13px] tracking-tight text-white">{currentTime}</span>

          {/* Device Dynamic Island / Speaker Pill */}
          <div className="w-24 h-4 bg-slate-950 rounded-full flex items-center justify-center gap-2 shadow-inner">
            <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-800" />
            <div className="w-2 h-2 rounded-full bg-emerald-500/80 animate-pulse" />
          </div>

          {/* System Indicators */}
          <div className="flex items-center gap-1.5 text-slate-300">
            <Signal size={12} className="text-white" />
            <Wifi size={13} className={isOnline ? 'text-white' : 'text-amber-400'} />
            <div className="flex items-center gap-0.5">
              <span className="text-[10px] font-mono">92%</span>
              <Battery size={14} className="text-white" />
            </div>
          </div>
        </div>

        {/* App Content viewport */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden flex flex-col relative bg-slate-950">
          {children}
        </div>

        {/* Bottom Home Indicator Bar */}
        <div className="w-full py-1.5 bg-slate-950 flex justify-center items-center select-none">
          <div className="w-32 h-1 bg-slate-600/70 rounded-full" />
        </div>
      </div>
    </div>
  );
};
