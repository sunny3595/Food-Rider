import React from 'react';
import { Home, Navigation, IndianRupee, Flame, User } from 'lucide-react';
import { useDelivery } from '../../store/deliveryStore';
import { useTheme } from '../../store/themeStore';

export type TabKey = 'home' | 'deliveries' | 'earnings' | 'incentives' | 'profile';

interface BottomNavigationProps {
  currentTab: TabKey;
  onTabChange: (tab: TabKey) => void;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({ currentTab, onTabChange }) => {
  const { activeDelivery } = useDelivery();
  const { t } = useTheme();

  const tabs: { key: TabKey; label: string; icon: React.ReactNode; badge?: boolean }[] = [
    {
      key: 'home',
      label: t('tabHome', 'Home'),
      icon: <Home size={20} />,
    },
    {
      key: 'deliveries',
      label: t('tabDeliveries', 'Delivery'),
      icon: <Navigation size={20} />,
      badge: !!activeDelivery,
    },
    {
      key: 'earnings',
      label: t('tabEarnings', 'Earnings'),
      icon: <IndianRupee size={20} />,
    },
    {
      key: 'incentives',
      label: t('tabIncentives', 'Incentives'),
      icon: <Flame size={20} />,
    },
    {
      key: 'profile',
      label: t('tabProfile', 'Profile'),
      icon: <User size={20} />,
    },
  ];

  return (
    <nav className="w-full bg-slate-900/95 backdrop-blur border-t border-slate-800 px-2 py-1.5 flex items-center justify-around z-30 select-none">
      {tabs.map((tab) => {
        const isActive = currentTab === tab.key;
        return (
          <button
            key={tab.key}
            onClick={() => onTabChange(tab.key)}
            className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all duration-150 ${
              isActive
                ? 'text-[#FF5200] font-semibold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className="relative">
              {tab.icon}
              {tab.badge && (
                <span className="absolute -top-1 -right-1.5 w-2.5 h-2.5 bg-[#FF5200] rounded-full ring-2 ring-slate-900 animate-pulse" />
              )}
            </div>
            <span className="text-[10px] mt-1 tracking-tight">{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
