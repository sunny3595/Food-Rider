import React from 'react';
import { Clock, Battery, BatteryCharging, BatteryWarning, AlertTriangle, ShieldCheck } from 'lucide-react';
import { useDuty } from '../../store/dutyStore';
import { useRider } from '../../store/riderStore';

export const ShiftDurationBanner: React.FC = () => {
  const { shift, battery } = useDuty();
  const { dutyStatus } = useRider();

  const isOnline = dutyStatus === 'ONLINE';

  // Format total seconds into HH:MM:SS
  const formatSecondsToClock = (totalSec: number) => {
    const hrs = Math.floor(totalSec / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs
      .toString()
      .padStart(2, '0')}`;
  };

  return (
    <div className="space-y-2">
      {/* Low Battery Warning Banner */}
      {battery.isLowBatteryWarning && (
        <div className="bg-rose-950/80 border border-rose-500/50 p-3 rounded-2xl flex items-center justify-between text-xs animate-pulse">
          <div className="flex items-center gap-2 text-rose-300">
            <BatteryWarning size={18} className="shrink-0 text-rose-400" />
            <div>
              <span className="font-bold block">Low Device Battery ({battery.levelPercent}%)</span>
              <span className="text-[10px] text-rose-200">Connect mobile charger to prevent order drops.</span>
            </div>
          </div>
        </div>
      )}

      {/* Live Shift Ribbon */}
      <div className="bg-slate-900/90 border border-slate-800 px-4 py-2.5 rounded-2xl flex items-center justify-between text-xs">
        {/* Left: Shift Clock */}
        <div className="flex items-center gap-2">
          <div
            className={`w-7 h-7 rounded-xl flex items-center justify-center ${
              isOnline ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-400'
            }`}
          >
            <Clock size={14} className={isOnline ? 'animate-pulse' : ''} />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Shift Duration</span>
            <span className="font-mono font-bold text-white text-xs tracking-wider">
              {formatSecondsToClock(shift.totalOnlineSecondsToday)}
            </span>
          </div>
        </div>

        {/* Right: Battery and GPS indicator */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 text-[11px] text-slate-400 font-mono">
            {battery.isCharging ? (
              <BatteryCharging size={14} className="text-emerald-400" />
            ) : battery.isLowBatteryWarning ? (
              <BatteryWarning size={14} className="text-rose-400" />
            ) : (
              <Battery size={14} className="text-slate-300" />
            )}
            <span>{battery.levelPercent}%</span>
          </div>

          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-950 border border-slate-800 text-[10px] text-emerald-400 font-bold">
            <ShieldCheck size={11} />
            <span>GPS High</span>
          </div>
        </div>
      </div>
    </div>
  );
};
