import React, { useState } from 'react';
import { MapPin, Navigation, Shield, CheckCircle2, X, AlertTriangle } from 'lucide-react';
import { useDuty } from '../../store/dutyStore';

export const LocationPermissionModal: React.FC = () => {
  const { isPermissionModalOpen, setPermissionModalOpen, grantLocationPermission } = useDuty();
  const [showDetailedRationale, setShowDetailedRationale] = useState(false);

  if (!isPermissionModalOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl p-5 shadow-2xl space-y-4">
        {/* Map Pin Emblem */}
        <div className="w-14 h-14 mx-auto rounded-3xl bg-orange-500/10 border-2 border-orange-500/30 flex items-center justify-center text-[#FF5200]">
          <MapPin size={28} />
        </div>

        <div className="text-center space-y-1.5">
          <span className="text-[10px] font-mono font-bold text-orange-400 uppercase tracking-wider block">
            LOCATION ACCESS REQUIRED
          </span>
          <h3 className="text-base font-extrabold text-white">Enable GPS to Go Online</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            FoodGo Rider collects location data to enable delivery dispatch and live routing, <strong>even when the app is in the background or closed</strong>.
          </p>
        </div>

        {/* Why Location is Needed Checklist */}
        <div className="bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800 space-y-2 text-xs">
          <div className="flex items-start gap-2 text-slate-300">
            <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
            <span><strong className="text-white">Receive Nearby Orders:</strong> Matches you with restaurants within a 5 km radius.</span>
          </div>

          <div className="flex items-start gap-2 text-slate-300">
            <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
            <span><strong className="text-white">Turn-by-Turn Navigation:</strong> Calculates shortest routes and avoids traffic bottlenecks.</span>
          </div>

          <div className="flex items-start gap-2 text-slate-300">
            <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
            <span><strong className="text-white">Customer Live Tracking:</strong> Transmits real-time order arrival estimates.</span>
          </div>
        </div>

        {showDetailedRationale && (
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-400 leading-relaxed space-y-1">
            <p className="font-semibold text-slate-300">Privacy Guarantee:</p>
            <p>Location tracking stops immediately when you switch your duty toggle to OFFLINE. Coordinates are encrypted with TLS 1.3 in-transit.</p>
          </div>
        )}

        {/* Actions */}
        <div className="space-y-2 pt-1">
          <button
            onClick={() => grantLocationPermission()}
            className="w-full py-3.5 bg-gradient-to-r from-[#FF5200] to-orange-600 hover:brightness-110 text-white rounded-xl text-xs font-bold shadow-lg shadow-orange-950/50 transition active:scale-98"
          >
            ENABLE LOCATION PERMISSION (ALLOW ALL THE TIME)
          </button>

          <button
            onClick={() => setShowDetailedRationale(!showDetailedRationale)}
            className="w-full py-2 text-xs text-orange-400 hover:text-orange-300 font-semibold transition"
          >
            {showDetailedRationale ? 'Hide Details' : 'Why We Need Background Permission'}
          </button>

          <button
            onClick={() => setPermissionModalOpen(false)}
            className="w-full py-2 text-xs text-slate-400 hover:text-white transition"
          >
            Cancel / Stay Offline
          </button>
        </div>
      </div>
    </div>
  );
};
