import React from 'react';
import { Flame, Navigation, MapPin, Zap, ArrowUpRight, TrendingUp } from 'lucide-react';
import { useDuty } from '../../store/dutyStore';
import { formatDistance } from '../../utils/formatters';

export const HotspotDemandCard: React.FC = () => {
  const { hotspots } = useDuty();

  const handleNavigateToZone = (lat: number, lng: number) => {
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, '_blank');
  };

  return (
    <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-3 shadow-lg">
      <div className="flex items-center justify-between pb-1 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-xl bg-orange-500/20 text-[#FF5200] flex items-center justify-center">
            <Flame size={15} />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white">Live Demand & Surge Hotspots</h3>
            <span className="text-[10px] text-slate-400">Position yourself near surge zones</span>
          </div>
        </div>

        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center gap-1">
          <Zap size={10} />
          <span>Surges Active</span>
        </span>
      </div>

      <div className="space-y-2">
        {hotspots.map((zone) => {
          const isHigh = zone.demandLevel === 'VERY_HIGH' || zone.demandLevel === 'HIGH';

          return (
            <div
              key={zone.id}
              className="p-3 bg-slate-950/70 hover:bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between transition group"
            >
              <div className="flex items-start gap-2.5">
                <div
                  className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                    zone.demandLevel === 'VERY_HIGH'
                      ? 'bg-orange-500/20 text-[#FF5200]'
                      : zone.demandLevel === 'HIGH'
                      ? 'bg-amber-500/20 text-amber-400'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  <MapPin size={14} />
                </div>

                <div>
                  <div className="flex items-center gap-1.5">
                    <h4 className="text-xs font-bold text-white group-hover:text-orange-400 transition">
                      {zone.name}
                    </h4>
                    {zone.surgeMultiplier > 1 && (
                      <span className="px-1.5 py-0.2 rounded text-[10px] font-mono font-bold bg-[#FF5200] text-white">
                        {zone.surgeMultiplier}x Surge
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    {formatDistance(zone.distanceKm)} away • ~{zone.estimatedOrdersPerHour} orders/hr
                  </p>
                </div>
              </div>

              <button
                onClick={() => handleNavigateToZone(zone.latitude, zone.longitude)}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-sky-400 rounded-lg text-[10px] font-bold flex items-center gap-1 border border-slate-700 shrink-0 transition"
                title="Navigate to High Demand Zone"
              >
                <Navigation size={11} />
                <span>Go</span>
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
