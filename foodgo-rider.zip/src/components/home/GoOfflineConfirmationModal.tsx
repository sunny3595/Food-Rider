import React from 'react';
import { Power, Clock, IndianRupee, Package, AlertCircle } from 'lucide-react';
import { useDuty } from '../../store/dutyStore';
import { formatCurrency, formatDuration } from '../../utils/formatters';

export const GoOfflineConfirmationModal: React.FC = () => {
  const { isOfflineConfirmOpen, setOfflineConfirmOpen, confirmGoOffline, shift } = useDuty();

  if (!isOfflineConfirmOpen) return null;

  const hoursMinutesLogged = Math.round(shift.totalOnlineSecondsToday / 60);

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl p-5 shadow-2xl space-y-4 text-center">
        {/* Power Off Icon */}
        <div className="w-14 h-14 mx-auto rounded-full bg-slate-800 border-2 border-slate-700 flex items-center justify-center text-slate-300">
          <Power size={28} />
        </div>

        <div>
          <h3 className="text-base font-extrabold text-white">End Shift & Go Offline?</h3>
          <p className="text-xs text-slate-300 mt-1">
            You will stop receiving new delivery requests in your zone until you switch back online.
          </p>
        </div>

        {/* Shift Summary Snapshot */}
        <div className="bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800 text-left space-y-2 text-xs">
          <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
            Today's Logged Shift Stats
          </span>

          <div className="grid grid-cols-3 gap-2 text-center pt-1">
            <div className="bg-slate-900 p-2 rounded-xl">
              <span className="text-[10px] text-slate-400 block">Earnings</span>
              <span className="font-extrabold text-white font-mono text-xs">
                {formatCurrency(shift.totalEarningsToday)}
              </span>
            </div>

            <div className="bg-slate-900 p-2 rounded-xl">
              <span className="text-[10px] text-slate-400 block">Orders</span>
              <span className="font-extrabold text-white font-mono text-xs">
                {shift.totalOrdersCompletedToday}
              </span>
            </div>

            <div className="bg-slate-900 p-2 rounded-xl">
              <span className="text-[10px] text-slate-400 block">Duration</span>
              <span className="font-extrabold text-white font-mono text-xs">
                {formatDuration(hoursMinutesLogged)}
              </span>
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="space-y-2 pt-1">
          <button
            onClick={() => confirmGoOffline()}
            className="w-full py-3 bg-slate-800 hover:bg-slate-750 text-rose-400 hover:text-rose-300 border border-slate-700 rounded-xl text-xs font-bold transition active:scale-98"
          >
            GO OFFLINE
          </button>

          <button
            onClick={() => setOfflineConfirmOpen(false)}
            className="w-full py-3 bg-[#FF5200] hover:bg-orange-600 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-orange-950/40 active:scale-98"
          >
            STAY ONLINE & RECEIVE ORDERS
          </button>
        </div>
      </div>
    </div>
  );
};
