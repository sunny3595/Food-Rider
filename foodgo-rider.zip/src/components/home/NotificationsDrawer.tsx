import React, { useState } from 'react';
import { X, Bell, CheckCheck, IndianRupee, Navigation, ShieldCheck, Info } from 'lucide-react';
import { useDuty } from '../../store/dutyStore';
import { MOCK_NOTIFICATIONS } from '../../api/mockData';
import { InAppNotification } from '../../types/socket.types';
import { formatTime } from '../../utils/formatters';

interface NotificationsDrawerProps {
  onSelectNotification?: (deepLink?: string) => void;
}

export const NotificationsDrawer: React.FC<NotificationsDrawerProps> = ({ onSelectNotification }) => {
  const { isNotificationsDrawerOpen, setNotificationsDrawerOpen } = useDuty();
  const [notifications, setNotifications] = useState<InAppNotification[]>(MOCK_NOTIFICATIONS);
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'DELIVERY' | 'PAYMENT' | 'SYSTEM'>('ALL');

  if (!isNotificationsDrawerOpen) return null;

  const filtered = notifications.filter((n) => {
    if (activeFilter === 'ALL') return true;
    if (activeFilter === 'DELIVERY') return n.category === 'DELIVERY';
    if (activeFilter === 'PAYMENT') return n.category === 'PAYMENT' || n.category === 'EARNINGS';
    return n.category === 'SYSTEM' || n.category === 'SUPPORT';
  });

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'DELIVERY':
        return <Navigation size={14} className="text-[#FF5200]" />;
      case 'PAYMENT':
      case 'EARNINGS':
        return <IndianRupee size={14} className="text-emerald-400" />;
      case 'SUPPORT':
        return <ShieldCheck size={14} className="text-sky-400" />;
      default:
        return <Info size={14} className="text-amber-400" />;
    }
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-xs z-50 flex justify-end animate-fadeIn">
      <div className="w-full max-w-sm h-full bg-slate-900 border-l border-slate-800 p-4 flex flex-col justify-between overflow-y-auto text-slate-200">
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <div className="flex items-center gap-2">
              <Bell size={18} className="text-[#FF5200]" />
              <h3 className="font-bold text-sm text-white">Notifications & Alerts</h3>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={markAllAsRead}
                className="text-[10px] font-semibold text-slate-400 hover:text-white flex items-center gap-1"
                title="Mark all as read"
              >
                <CheckCheck size={12} />
                <span>Mark Read</span>
              </button>

              <button
                onClick={() => setNotificationsDrawerOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>
          </div>

          {/* Filter Pills */}
          <div className="flex gap-1.5 overflow-x-auto pb-2 text-xs">
            {['ALL', 'DELIVERY', 'PAYMENT', 'SYSTEM'].map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveFilter(cat as any)}
                className={`px-3 py-1 rounded-full text-[10px] font-bold transition whitespace-nowrap ${
                  activeFilter === cat
                    ? 'bg-[#FF5200] text-white shadow'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Notification List */}
          <div className="space-y-2 mt-2">
            {filtered.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  if (item.deepLink && onSelectNotification) {
                    onSelectNotification(item.deepLink);
                    setNotificationsDrawerOpen(false);
                  }
                }}
                className={`p-3 rounded-2xl border transition cursor-pointer ${
                  !item.isRead
                    ? 'bg-slate-950 border-orange-500/30'
                    : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-950'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center shrink-0 mt-0.5">
                    {getCategoryIcon(item.category)}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-white truncate">{item.title}</h4>
                      <span className="text-[9px] text-slate-500 font-mono shrink-0 ml-1">
                        {formatTime(item.timestamp)}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">{item.message}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800">
          <button
            onClick={() => setNotificationsDrawerOpen(false)}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-bold transition"
          >
            Close Notifications
          </button>
        </div>
      </div>
    </div>
  );
};
