import React from 'react';
import { Award, Crown, CheckCircle2, ChevronRight, Sparkles, ShieldCheck } from 'lucide-react';
import { useIncentives } from '../../store/incentivesStore';

export const RiderTierCard: React.FC = () => {
  const { currentTier } = useIncentives();

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-850 to-slate-900 p-5 rounded-3xl border border-slate-700 shadow-xl space-y-3.5">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-slate-300 via-white to-slate-400 p-0.5 shadow-lg shadow-white/10">
            <div className="w-full h-full rounded-2xl bg-slate-950 flex items-center justify-center text-slate-200">
              <Crown size={22} className="text-amber-400" />
            </div>
          </div>

          <div>
            <span className="text-[10px] uppercase font-mono font-bold text-amber-400 tracking-wider block">
              PARTNER CLUB STATUS
            </span>
            <h3 className="text-base font-black text-white tracking-tight">{currentTier.title}</h3>
            <p className="text-[11px] text-slate-400">842 deliveries • ★ 4.88 • 94% AR</p>
          </div>
        </div>

        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20">
          Tier 4 / 5
        </span>
      </div>

      {/* Progress to Diamond Legend */}
      <div className="bg-slate-950/70 p-3 rounded-2xl border border-slate-800 space-y-1.5">
        <div className="flex justify-between text-xs font-mono">
          <span className="text-slate-300">Progress to Diamond Legend</span>
          <span className="text-amber-400 font-bold">842 / 1000 Trips</span>
        </div>
        <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-amber-500 to-yellow-300 rounded-full"
            style={{ width: '84.2%' }}
          />
        </div>
        <p className="text-[10px] text-slate-400">
          Only 158 more completed deliveries to reach Diamond Legend tier!
        </p>
      </div>

      {/* Active Perks List */}
      <div className="space-y-1.5 pt-1">
        <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
          Active Platinum Privileges
        </span>

        <div className="grid grid-cols-2 gap-2 text-xs">
          {currentTier.perks.map((perk, i) => (
            <div
              key={i}
              className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800 flex items-start gap-1.5 text-slate-300"
            >
              <CheckCircle2 size={13} className="text-emerald-400 shrink-0 mt-0.5" />
              <span className="text-[11px] leading-snug">{perk}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
