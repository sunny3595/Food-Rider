import React, { useState } from 'react';
import {
  X,
  Award,
  PackageCheck,
  Star,
  Zap,
  CloudRain,
  Moon,
  ShieldCheck,
  Lock,
  CheckCircle2,
} from 'lucide-react';
import { useIncentives } from '../../store/incentivesStore';
import { AchievementBadge } from '../../types/gamification.types';

interface BadgesGridModalProps {
  onClose: () => void;
}

export const BadgesGridModal: React.FC<BadgesGridModalProps> = ({ onClose }) => {
  const { badges } = useIncentives();
  const [selectedBadge, setSelectedBadge] = useState<AchievementBadge | null>(null);

  const renderBadgeIcon = (iconName: string, isUnlocked: boolean) => {
    const props = { size: 22, className: isUnlocked ? 'text-amber-400' : 'text-slate-500' };
    switch (iconName) {
      case 'PackageCheck':
        return <PackageCheck {...props} />;
      case 'Award':
        return <Award {...props} />;
      case 'Star':
        return <Star {...props} />;
      case 'Zap':
        return <Zap {...props} />;
      case 'CloudRain':
        return <CloudRain {...props} />;
      case 'Moon':
        return <Moon {...props} />;
      case 'ShieldCheck':
        return <ShieldCheck {...props} />;
      default:
        return <Award {...props} />;
    }
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm max-h-[90vh] bg-slate-900 border border-slate-700 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award size={18} className="text-amber-400" />
            <h3 className="text-sm font-bold text-white">Partner Badges & Trophies</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-4">
          <div className="grid grid-cols-3 gap-2.5">
            {badges.map((b) => (
              <div
                key={b.id}
                onClick={() => setSelectedBadge(b)}
                className={`p-3 rounded-2xl border text-center cursor-pointer transition flex flex-col items-center justify-between h-28 ${
                  b.isUnlocked
                    ? 'bg-slate-950/80 hover:bg-slate-950 border-amber-500/30'
                    : 'bg-slate-950/40 border-slate-800/80 opacity-60'
                }`}
              >
                <div
                  className={`w-11 h-11 rounded-2xl flex items-center justify-center ${
                    b.isUnlocked ? 'bg-amber-500/10 border border-amber-500/20' : 'bg-slate-800'
                  }`}
                >
                  {renderBadgeIcon(b.iconName, b.isUnlocked)}
                </div>

                <div className="w-full truncate">
                  <span className="text-[11px] font-bold text-white block truncate">{b.name}</span>
                  <span className="text-[9px] text-slate-400 font-mono">
                    {b.isUnlocked ? 'Unlocked' : `${b.progressCurrent}/${b.progressTarget}`}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Selected Badge Details Card */}
          {selectedBadge && (
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2 text-center animate-fadeIn">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
                {renderBadgeIcon(selectedBadge.iconName, selectedBadge.isUnlocked)}
              </div>
              <h4 className="text-sm font-extrabold text-white">{selectedBadge.name}</h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                {selectedBadge.description}
              </p>

              <div className="pt-1 text-[11px] font-mono text-slate-400">
                {selectedBadge.isUnlocked ? (
                  <span className="text-emerald-400 font-bold flex items-center justify-center gap-1">
                    <CheckCircle2 size={13} />
                    <span>Achieved on {selectedBadge.unlockedAt}</span>
                  </span>
                ) : (
                  <span>
                    Current Progress: {selectedBadge.progressCurrent} / {selectedBadge.progressTarget}
                  </span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800">
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-bold"
          >
            Close Badges Showcase
          </button>
        </div>
      </div>
    </div>
  );
};
