import React from 'react';
import { Flame, Clock, CloudRain, Zap, CheckCircle2 } from 'lucide-react';
import { useIncentives } from '../../store/incentivesStore';
import { formatCurrency } from '../../utils/formatters';

export const PeakSurgeTimelineCard: React.FC = () => {
  const { peakSurges, rainSurgeEnabled, toggleRainSurge } = useIncentives();

  return (
    <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-3.5 shadow-xl">
      <div className="flex items-center justify-between pb-1 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-orange-500/20 text-[#FF5200] flex items-center justify-center">
            <Flame size={16} />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white">Peak Hours & Surge Windows</h3>
            <span className="text-[10px] text-slate-400">Guaranteed bonus pay per trip</span>
          </div>
        </div>

        <button
          onClick={toggleRainSurge}
          className={`px-2.5 py-1 rounded-full text-[10px] font-bold flex items-center gap-1 transition border ${
            rainSurgeEnabled
              ? 'bg-sky-500/20 text-sky-300 border-sky-500/40'
              : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
          }`}
          title="Simulate weather change"
        >
          <CloudRain size={11} />
          <span>{rainSurgeEnabled ? 'Rain Active (+₹30)' : 'Simulate Rain'}</span>
        </button>
      </div>

      {/* Surges List */}
      <div className="space-y-2">
        {peakSurges.map((surge) => (
          <div
            key={surge.id}
            className={`p-3 rounded-2xl border transition flex items-center justify-between ${
              surge.isActive
                ? 'bg-gradient-to-r from-orange-950/40 via-slate-900 to-slate-950 border-orange-500/50 shadow-md'
                : 'bg-slate-950/70 border-slate-800/80 text-slate-400'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                  surge.isActive
                    ? 'bg-[#FF5200] text-white shadow-lg shadow-orange-950/50'
                    : 'bg-slate-800 text-slate-500'
                }`}
              >
                {surge.id === 'surge_rain' ? (
                  <CloudRain size={16} />
                ) : (
                  <Flame size={16} className={surge.isActive ? 'animate-bounce' : ''} />
                )}
              </div>

              <div>
                <div className="flex items-center gap-1.5">
                  <h4
                    className={`text-xs font-bold ${
                      surge.isActive ? 'text-white' : 'text-slate-400'
                    }`}
                  >
                    {surge.title}
                  </h4>
                  {surge.isActive && (
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-[#FF5200] text-white animate-pulse">
                      ACTIVE NOW
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                  {surge.timeSlot} {surge.endsInMinutes ? `• Ends in ${surge.endsInMinutes}m` : ''}
                </p>
              </div>
            </div>

            <div className="text-right shrink-0">
              <span
                className={`text-xs font-black font-mono block ${
                  surge.isActive ? 'text-emerald-400' : 'text-slate-500'
                }`}
              >
                +{formatCurrency(surge.bonusPerOrder)}
              </span>
              <span className="text-[9px] text-slate-400">per delivery</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
