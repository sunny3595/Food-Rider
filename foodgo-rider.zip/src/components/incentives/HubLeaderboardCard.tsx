import React from 'react';
import { Trophy, Medal, Star, Flame, Crown } from 'lucide-react';
import { useIncentives } from '../../store/incentivesStore';
import { formatCurrency } from '../../utils/formatters';

export const HubLeaderboardCard: React.FC = () => {
  const { hubLeaderboard } = useIncentives();

  const topThree = hubLeaderboard.slice(0, 3);
  const others = hubLeaderboard.slice(3);

  return (
    <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-4 shadow-xl">
      <div className="flex items-center justify-between pb-1 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <Trophy size={16} />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white">Indiranagar Hub Leaderboard</h3>
            <span className="text-[10px] text-slate-400">Weekly Partner Challenge (Fri - Sun)</span>
          </div>
        </div>

        <span className="text-[10px] font-bold text-amber-400 bg-amber-500/10 px-2.5 py-0.5 rounded-full border border-amber-500/20">
          ₹10,000 Prize Pool
        </span>
      </div>

      {/* Top 3 Podium Visualizer */}
      <div className="grid grid-cols-3 gap-2 text-center pt-2">
        {/* 2nd Place */}
        <div className="bg-slate-950/80 p-3 rounded-2xl border border-slate-800 flex flex-col items-center justify-end h-32 relative">
          <span className="w-6 h-6 rounded-full bg-slate-700 text-white font-mono font-black text-xs flex items-center justify-center absolute -top-3">
            2
          </span>
          <span className="text-xs font-bold text-white truncate max-w-[80px]">
            {topThree[1].riderName}
          </span>
          <span className="text-[10px] text-slate-400">{topThree[1].deliveriesCount} trips</span>
          <span className="text-[11px] font-mono font-bold text-emerald-400 mt-1">
            +{formatCurrency(topThree[1].cashPrize || 2000)}
          </span>
        </div>

        {/* 1st Place */}
        <div className="bg-gradient-to-t from-slate-950 via-amber-950/30 to-amber-900/30 p-3 rounded-2xl border border-amber-500/40 flex flex-col items-center justify-end h-36 relative shadow-lg">
          <div className="w-7 h-7 rounded-full bg-amber-500 text-slate-950 font-mono font-black text-xs flex items-center justify-center absolute -top-3.5 shadow-md">
            <Crown size={15} />
          </div>
          <span className="text-xs font-extrabold text-white truncate max-w-[80px]">
            {topThree[0].riderName}
          </span>
          <span className="text-[10px] text-amber-300">{topThree[0].deliveriesCount} trips</span>
          <span className="text-xs font-mono font-black text-emerald-400 mt-1">
            +{formatCurrency(topThree[0].cashPrize || 3000)}
          </span>
        </div>

        {/* 3rd Place */}
        <div className="bg-slate-950/80 p-3 rounded-2xl border border-slate-800 flex flex-col items-center justify-end h-28 relative">
          <span className="w-6 h-6 rounded-full bg-amber-800 text-white font-mono font-black text-xs flex items-center justify-center absolute -top-3">
            3
          </span>
          <span className="text-xs font-bold text-white truncate max-w-[80px]">
            {topThree[2].riderName}
          </span>
          <span className="text-[10px] text-slate-400">{topThree[2].deliveriesCount} trips</span>
          <span className="text-[11px] font-mono font-bold text-emerald-400 mt-1">
            +{formatCurrency(topThree[2].cashPrize || 1000)}
          </span>
        </div>
      </div>

      {/* Ranks 4 to 10 List */}
      <div className="space-y-1.5 pt-1">
        {others.map((r) => (
          <div
            key={r.riderCode}
            className={`p-2.5 rounded-xl border flex items-center justify-between text-xs transition ${
              r.isCurrentUser
                ? 'bg-orange-950/40 border-orange-500/60 ring-1 ring-orange-500/30 text-white font-bold'
                : 'bg-slate-950/60 border-slate-800 text-slate-300'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <span className="w-5 text-center font-mono font-bold text-slate-400">#{r.rank}</span>
              <div className="truncate max-w-[140px]">
                <span className="block truncate">{r.riderName}</span>
                <span className="text-[9px] text-slate-400 font-mono font-normal">
                  ★ {r.rating} • {r.deliveriesCount} orders
                </span>
              </div>
            </div>

            <div className="text-right">
              <span className="font-mono font-bold text-emerald-400">
                +{formatCurrency(r.cashPrize || 500)}
              </span>
              <span className="text-[9px] text-slate-500 block">Bonus</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
