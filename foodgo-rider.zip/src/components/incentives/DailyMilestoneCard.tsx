import React from 'react';
import { Target, CheckCircle2, Lock, Sparkles, Clock, ShieldCheck, IndianRupee } from 'lucide-react';
import { useIncentives } from '../../store/incentivesStore';
import { formatCurrency } from '../../utils/formatters';

export const DailyMilestoneCard: React.FC = () => {
  const { dailyMilestones, todayCompletedCount, eligibility } = useIncentives();

  return (
    <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-3.5 shadow-xl">
      <div className="flex items-center justify-between pb-1 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-orange-500/20 text-[#FF5200] flex items-center justify-center">
            <Target size={16} />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white">Daily Target Challenge</h3>
            <span className="text-[10px] text-slate-400">Resets tonight at 11:59 PM</span>
          </div>
        </div>

        {/* Eligibility Pill */}
        <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
          <ShieldCheck size={11} />
          <span>Eligible ({eligibility.acceptanceRate}% AR)</span>
        </div>
      </div>

      {/* 3-Tier Step Visualizer */}
      <div className="space-y-2.5">
        {dailyMilestones.map((tier) => {
          const isAchieved = tier.status === 'ACHIEVED';
          const isInProgress = tier.status === 'IN_PROGRESS';
          const remainingOrders = Math.max(0, tier.targetDeliveries - todayCompletedCount);

          return (
            <div
              key={tier.tierNumber}
              className={`p-3 rounded-2xl border transition ${
                isAchieved
                  ? 'bg-emerald-950/30 border-emerald-500/40 text-white'
                  : isInProgress
                  ? 'bg-orange-950/30 border-orange-500/40 text-white shadow-lg'
                  : 'bg-slate-950/60 border-slate-800 text-slate-400'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div
                    className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-bold ${
                      isAchieved
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : isInProgress
                        ? 'bg-[#FF5200]/20 text-[#FF5200]'
                        : 'bg-slate-800 text-slate-500'
                    }`}
                  >
                    {isAchieved ? (
                      <CheckCircle2 size={16} />
                    ) : isInProgress ? (
                      <span>T{tier.tierNumber}</span>
                    ) : (
                      <Lock size={13} />
                    )}
                  </div>

                  <div>
                    <span className="text-xs font-bold block">
                      Tier {tier.tierNumber}: Complete {tier.targetDeliveries} Deliveries
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {isAchieved
                        ? 'Bonus credited to your wallet'
                        : isInProgress
                        ? `Only ${remainingOrders} more order to unlock!`
                        : `Locked (Reach Tier ${tier.tierNumber - 1} first)`}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span
                    className={`text-sm font-black font-mono block ${
                      isAchieved
                        ? 'text-emerald-400'
                        : isInProgress
                        ? 'text-[#FF5200]'
                        : 'text-slate-500'
                    }`}
                  >
                    +{formatCurrency(tier.bonusAmount)}
                  </span>
                  <span className="text-[9px] uppercase font-bold text-slate-500">
                    {isAchieved ? 'Earned' : 'Cash Bonus'}
                  </span>
                </div>
              </div>

              {/* Progress bar if currently in progress */}
              {isInProgress && (
                <div className="mt-2.5 pt-2 border-t border-orange-500/20 space-y-1">
                  <div className="flex justify-between text-[10px] font-mono">
                    <span className="text-slate-300">Progress: {todayCompletedCount}/{tier.targetDeliveries} Orders</span>
                    <span className="text-orange-400 font-bold">
                      {Math.round((todayCompletedCount / tier.targetDeliveries) * 100)}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#FF5200] to-orange-400 rounded-full transition-all duration-500"
                      style={{
                        width: `${(todayCompletedCount / tier.targetDeliveries) * 100}%`,
                      }}
                    />
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
