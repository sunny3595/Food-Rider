import React from 'react';
import {
  X,
  AlertTriangle,
  ShieldAlert,
  PhoneCall,
  Volume2,
  VolumeX,
  Mic,
  MapPin,
  CheckCircle2,
  Radio,
} from 'lucide-react';
import { useSafety } from '../../store/safetyStore';

interface EmergencySosModalProps {
  onClose: () => void;
}

export const EmergencySosModal: React.FC<EmergencySosModalProps> = ({ onClose }) => {
  const {
    sosStatus,
    countdownSeconds,
    isSirenPlaying,
    contacts,
    activeIncident,
    startSosCountdown,
    cancelSosCountdown,
    triggerSosNow,
    deactivateSos,
    toggleSiren,
  } = useSafety();

  const handleCall = (phone: string) => {
    window.location.href = `tel:${phone}`;
  };

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-70 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm max-h-[92vh] bg-slate-900 border border-rose-600/40 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-rose-950/80 border-b border-rose-800/60 flex items-center justify-between">
          <div className="flex items-center gap-2 text-rose-300">
            <ShieldAlert size={20} />
            <h3 className="text-sm font-black uppercase tracking-wider text-white">
              FoodGo Safety & SOS Hub
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-4">
          {sosStatus === 'IDLE' && (
            /* Standby State */
            <div className="space-y-4 text-center py-2">
              <div className="w-20 h-20 mx-auto rounded-full bg-rose-500/10 border-2 border-rose-500/30 flex items-center justify-center text-rose-500">
                <AlertTriangle size={36} />
              </div>

              <div>
                <h4 className="text-base font-extrabold text-white">Emergency Assistance</h4>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  Activating SOS immediately broadcasts your live GPS coordinates to Police, FoodGo Safety Command, and your emergency contacts.
                </p>
              </div>

              {/* Big Red SOS Button */}
              <button
                onClick={startSosCountdown}
                className="w-full py-5 bg-gradient-to-r from-rose-600 to-red-600 hover:brightness-110 text-white rounded-2xl font-black text-sm tracking-wider uppercase shadow-xl shadow-rose-950/60 flex items-center justify-center gap-2 active:scale-95 transition"
              >
                <ShieldAlert size={22} />
                <span>TRIGGER EMERGENCY SOS</span>
              </button>

              <p className="text-[10px] text-slate-400">
                Includes 5-second countdown to cancel accidental triggers.
              </p>
            </div>
          )}

          {sosStatus === 'COUNTDOWN' && (
            /* Countdown Confirmation State */
            <div className="space-y-4 text-center py-4 animate-fadeIn">
              <div className="relative w-24 h-24 mx-auto flex items-center justify-center">
                <div className="absolute inset-0 bg-rose-500/20 rounded-full animate-ping" />
                <div className="w-20 h-20 rounded-full bg-rose-600 text-white flex items-center justify-center text-3xl font-black font-mono shadow-2xl">
                  {countdownSeconds}
                </div>
              </div>

              <div>
                <h4 className="text-base font-black text-white">Activating Emergency Broadcast</h4>
                <p className="text-xs text-rose-300 mt-1">
                  Broadcasting live telemetry and alerting response units in {countdownSeconds}s...
                </p>
              </div>

              <div className="space-y-2 pt-2">
                <button
                  onClick={triggerSosNow}
                  className="w-full py-3 bg-rose-700 hover:bg-rose-600 text-white rounded-xl text-xs font-bold"
                >
                  Trigger Immediately (Skip Countdown)
                </button>

                <button
                  onClick={cancelSosCountdown}
                  className="w-full py-3.5 bg-slate-800 hover:bg-slate-750 text-white rounded-xl text-xs font-bold border border-slate-700 shadow"
                >
                  CANCEL (ACCIDENTAL TAP)
                </button>
              </div>
            </div>
          )}

          {sosStatus === 'ACTIVATED' && activeIncident && (
            /* Live SOS Broadcast Active State */
            <div className="space-y-3.5 animate-fadeIn">
              {/* Flashing Alert Banner */}
              <div className="p-3 bg-rose-600 text-white rounded-2xl text-center space-y-1 shadow-lg animate-pulse">
                <span className="text-[10px] font-mono font-bold tracking-widest uppercase block">
                  🚨 ACTIVE EMERGENCY DISPATCH BROADCAST
                </span>
                <span className="text-xs font-black font-mono">
                  REF: {activeIncident.incidentId}
                </span>
              </div>

              {/* Status details */}
              <div className="bg-slate-950 p-3 rounded-2xl border border-rose-900/60 text-xs space-y-2 font-mono text-slate-300">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Live Coordinates:</span>
                  <span className="text-white font-bold flex items-center gap-1">
                    <MapPin size={11} className="text-rose-400" />
                    <span>{activeIncident.latitude}° N, {activeIncident.longitude}° E</span>
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Active Order:</span>
                  <span className="text-sky-400 font-bold">{activeIncident.activeOrderNumber}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Audio Telemetry:</span>
                  <span className="text-rose-400 font-bold flex items-center gap-1 animate-pulse">
                    <Mic size={11} />
                    <span>Background Recording Active</span>
                  </span>
                </div>

                <div className="pt-1 border-t border-slate-800">
                  <span className="text-[10px] text-slate-400 block mb-1">Alert Dispatched To:</span>
                  <div className="flex flex-wrap gap-1">
                    {activeIncident.dispatchedTo.map((target, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded text-[9px] bg-rose-950/60 border border-rose-800 text-rose-300"
                      >
                        ✓ {target}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Siren Toggle */}
              <button
                onClick={toggleSiren}
                className={`w-full py-2.5 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-1.5 ${
                  isSirenPlaying
                    ? 'bg-amber-600 text-white border-amber-400 shadow'
                    : 'bg-slate-950 text-slate-300 border-slate-800'
                }`}
              >
                {isSirenPlaying ? <Volume2 size={15} /> : <VolumeX size={15} />}
                <span>{isSirenPlaying ? 'Loud Siren Playing (Tap to Mute)' : 'Play Loud Alarm Siren'}</span>
              </button>

              {/* Deactivate Button */}
              <button
                onClick={deactivateSos}
                className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl text-xs font-bold transition shadow-lg shadow-emerald-950/40 flex items-center justify-center gap-2"
              >
                <CheckCircle2 size={16} />
                <span>I AM SAFE NOW (DEACTIVATE SOS)</span>
              </button>
            </div>
          )}

          {/* Quick Emergency Speed Dials */}
          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
              Emergency Speed Dials
            </span>

            <div className="grid grid-cols-2 gap-2">
              {contacts.map((c) => (
                <button
                  key={c.id}
                  onClick={() => handleCall(c.phone)}
                  className="p-2 bg-slate-900 hover:bg-slate-850 rounded-xl border border-slate-800 text-left transition flex items-center justify-between"
                >
                  <div className="truncate">
                    <span className="text-xs font-bold text-white block truncate">{c.name}</span>
                    <span className="text-[10px] text-emerald-400 font-mono">{c.phone}</span>
                  </div>
                  <PhoneCall size={14} className="text-rose-400 shrink-0 ml-1" />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800">
          <button
            onClick={onClose}
            className="w-full py-2 bg-slate-850 text-slate-300 rounded-xl text-xs font-bold"
          >
            Close Safety Hub
          </button>
        </div>
      </div>
    </div>
  );
};
