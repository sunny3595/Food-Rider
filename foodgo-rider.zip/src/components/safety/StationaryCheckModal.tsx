import React from 'react';
import { AlertCircle, CheckCircle2, ShieldAlert, Headphones, X } from 'lucide-react';
import { useSafety } from '../../store/safetyStore';

interface StationaryCheckModalProps {
  onOpenSos: () => void;
  onOpenSupport: () => void;
}

export const StationaryCheckModal: React.FC<StationaryCheckModalProps> = ({
  onOpenSos,
  onOpenSupport,
}) => {
  const { stationaryCheck, resolveStationaryAlert } = useSafety();

  if (!stationaryCheck.isStationaryAlertActive) return null;

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-65 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm bg-slate-900 border border-amber-500/40 rounded-3xl p-5 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
            <AlertCircle size={24} />
          </div>
          <div>
            <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-widest block">
              SAFETY RIDE CHECK
            </span>
            <h3 className="text-sm font-black text-white">Are you doing okay?</h3>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          We noticed your vehicle has been stationary for <strong>{stationaryCheck.idleDurationMinutes} minutes</strong> during order <strong>{stationaryCheck.orderNumber}</strong>.
        </p>

        {/* Options */}
        <div className="space-y-2 pt-1">
          <button
            onClick={resolveStationaryAlert}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 shadow"
          >
            <CheckCircle2 size={16} />
            <span>Yes, I'm Safe (Traffic / Waiting at Counter)</span>
          </button>

          <button
            onClick={() => {
              resolveStationaryAlert();
              onOpenSupport();
            }}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-750 text-sky-400 rounded-xl text-xs font-bold border border-slate-700 flex items-center justify-center gap-2"
          >
            <Headphones size={15} />
            <span>Contact Fleet Dispatch Help</span>
          </button>

          <button
            onClick={() => {
              resolveStationaryAlert();
              onOpenSos();
            }}
            className="w-full py-2.5 bg-rose-950/80 hover:bg-rose-900 text-rose-300 rounded-xl text-xs font-bold border border-rose-800/60 flex items-center justify-center gap-2"
          >
            <ShieldAlert size={15} />
            <span>Emergency SOS Assistance Needed</span>
          </button>
        </div>
      </div>
    </div>
  );
};
