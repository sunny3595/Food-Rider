import React, { useState } from 'react';
import { X, Camera, CheckCircle2, ShieldCheck, RefreshCw } from 'lucide-react';
import { useSafety } from '../../store/safetyStore';

interface HelmetCheckModalProps {
  onClose: () => void;
}

export const HelmetCheckModal: React.FC<HelmetCheckModalProps> = ({ onClose }) => {
  const { helmetState, verifyHelmetPhoto } = useSafety();
  const [isScanning, setIsScanning] = useState(false);
  const [scanComplete, setScanComplete] = useState(false);

  const samplePhoto =
    'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=400&q=80';

  const handleCapture = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      setScanComplete(true);
      verifyHelmetPhoto(samplePhoto);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-60 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck size={18} className="text-emerald-400" />
            <h3 className="text-sm font-bold text-white">Daily Helmet Safety Check</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Viewfinder */}
        <div className="p-4 space-y-3">
          <div className="relative w-full h-64 bg-black rounded-2xl overflow-hidden border border-slate-800 flex items-center justify-center">
            <img src={samplePhoto} alt="Helmet Verification" className="w-full h-full object-cover" />

            {/* AI Scanning Visualizer */}
            {isScanning && (
              <div className="absolute inset-0 bg-emerald-500/20 flex flex-col items-center justify-center space-y-2">
                <div className="w-48 h-48 border-2 border-emerald-400 rounded-2xl animate-pulse flex items-center justify-center">
                  <span className="text-xs font-mono font-bold text-emerald-300 bg-black/60 px-2 py-1 rounded">
                    Analyzing Straps & Visor...
                  </span>
                </div>
              </div>
            )}

            {scanComplete && (
              <div className="absolute inset-0 bg-emerald-950/80 backdrop-blur-xs flex flex-col items-center justify-center space-y-1.5 animate-fadeIn">
                <div className="w-12 h-12 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-lg">
                  <CheckCircle2 size={28} />
                </div>
                <span className="text-xs font-bold text-white">Helmet & Chin Strap Verified!</span>
                <span className="text-[10px] text-emerald-400 font-mono">100% Compliance Score</span>
              </div>
            )}
          </div>

          <p className="text-xs text-slate-300 leading-relaxed text-center">
            FoodGo Safety Protocols require all partners to wear an ISI-certified helmet with secured chin strap.
          </p>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800">
          {scanComplete ? (
            <button
              onClick={onClose}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition shadow-md"
            >
              Done & Return to Duty
            </button>
          ) : (
            <button
              onClick={handleCapture}
              disabled={isScanning}
              className="w-full py-3.5 bg-[#FF5200] hover:bg-orange-600 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 shadow-lg shadow-orange-950/40"
            >
              <Camera size={16} />
              <span>{isScanning ? 'Verifying AI Camera...' : 'TAKE HELMET SELFIE'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
