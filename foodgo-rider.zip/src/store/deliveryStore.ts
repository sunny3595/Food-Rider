import { useState, useEffect } from 'react';
import { DeliveryOrder, DeliveryRequest, DeliveryStatus } from '../types/delivery.types';
import { DeliveryApi } from '../api/delivery.api';
import { MOCK_ACTIVE_DELIVERY, MOCK_DELIVERY_REQUEST } from '../api/mockData';
import { AudioAlerts } from '../utils/audioAlerts';
import { ThemeStore } from './themeStore';

interface DeliveryState {
  activeDelivery: DeliveryOrder | null;
  pendingRequest: DeliveryRequest | null;
  requestSecondsRemaining: number;
  isDeclineModalOpen: boolean;
  isAcceptanceRateWarningOpen: boolean;
  orderMissedToast: string | null;
  acceptanceMetrics: {
    totalOffered: number;
    totalAccepted: number;
    ratePercentage: number;
  };
  isProcessing: boolean;
  error: string | null;
}

let globalDeliveryState: DeliveryState = {
  activeDelivery: MOCK_ACTIVE_DELIVERY,
  pendingRequest: null,
  requestSecondsRemaining: 0,
  isDeclineModalOpen: false,
  isAcceptanceRateWarningOpen: false,
  orderMissedToast: null,
  acceptanceMetrics: {
    totalOffered: 100,
    totalAccepted: 94,
    ratePercentage: 94,
  },
  isProcessing: false,
  error: null,
};

const listeners = new Set<(state: DeliveryState) => void>();
let timerInterval: any = null;

function notify() {
  listeners.forEach((listener) => listener(globalDeliveryState));
}

export const DeliveryStore = {
  getState() {
    return globalDeliveryState;
  },

  setState(partial: Partial<DeliveryState>) {
    globalDeliveryState = { ...globalDeliveryState, ...partial };
    notify();
  },

  setDeclineModalOpen(isOpen: boolean) {
    this.setState({ isDeclineModalOpen: isOpen });
  },

  setAcceptanceRateWarningOpen(isOpen: boolean) {
    this.setState({ isAcceptanceRateWarningOpen: isOpen });
  },

  triggerIncomingRequest(request: DeliveryRequest = MOCK_DELIVERY_REQUEST) {
    if (timerInterval) clearInterval(timerInterval);

    // Audio Ringtone
    const isSoundOn = ThemeStore.getState().soundEnabled;
    AudioAlerts.playIncomingOrderRingtone(isSoundOn);

    const totalSeconds = request.timeoutSecondsTotal || 25;

    this.setState({
      pendingRequest: request,
      requestSecondsRemaining: totalSeconds,
      isDeclineModalOpen: false,
      orderMissedToast: null,
      error: null,
    });

    timerInterval = setInterval(() => {
      const remaining = globalDeliveryState.requestSecondsRemaining - 1;
      if (remaining <= 0) {
        clearInterval(timerInterval);
        timerInterval = null;
        AudioAlerts.playDeclinedChime(isSoundOn);

        // Update acceptance metrics on timeout (missed order)
        const newOffered = globalDeliveryState.acceptanceMetrics.totalOffered + 1;
        const newAccepted = globalDeliveryState.acceptanceMetrics.totalAccepted;
        const newRate = Math.round((newAccepted / newOffered) * 100);

        DeliveryStore.setState({
          pendingRequest: null,
          requestSecondsRemaining: 0,
          isDeclineModalOpen: false,
          orderMissedToast: 'Delivery request timed out and was reassigned to the next partner.',
          acceptanceMetrics: {
            totalOffered: newOffered,
            totalAccepted: newAccepted,
            ratePercentage: newRate,
          },
        });

        setTimeout(() => {
          DeliveryStore.setState({ orderMissedToast: null });
        }, 4000);
      } else {
        DeliveryStore.setState({ requestSecondsRemaining: remaining });
      }
    }, 1000);
  },

  triggerBatchDeliveryOffer() {
    const batchRequest: DeliveryRequest = {
      ...MOCK_DELIVERY_REQUEST,
      id: `req_batch_${Date.now()}`,
      orderNumber: '#FG-BATCH-201',
      isBatchOrder: true,
      batchOrdersCount: 2,
      estimatedEarnings: 185,
      totalDistanceKm: 7.2,
      estimatedTimeMinutes: 38,
      financialsBreakdown: {
        basePay: 70,
        distancePay: 55,
        surgePay: 40,
        tip: 20,
      },
      batchSecondaryOrder: {
        orderNumber: '#FG-10299',
        restaurantName: 'Truffles Burgers',
        customerName: 'Rohit Sharma',
        customerAddress: 'Flat 402, Prestige Palms, Indiranagar',
        itemsCount: 2,
        distanceKm: 1.8,
      },
    };
    this.triggerIncomingRequest(batchRequest);
  },

  triggerStackedDeliveryOffer() {
    const stackedRequest: DeliveryRequest = {
      ...MOCK_DELIVERY_REQUEST,
      id: `req_stacked_${Date.now()}`,
      orderNumber: '#FG-ADDON-402',
      isStackedAddOn: true,
      stackedAdditionalEarnings: 65,
      stackedAdditionalDistanceKm: 1.2,
      stackedAdditionalMinutes: 10,
      estimatedEarnings: 65,
      totalDistanceKm: 1.2,
      estimatedTimeMinutes: 10,
      financialsBreakdown: {
        basePay: 35,
        distancePay: 15,
        surgePay: 15,
        tip: 0,
      },
    };
    this.triggerIncomingRequest(stackedRequest);
  },

  async acceptIncomingRequest() {
    if (!globalDeliveryState.pendingRequest) return;
    if (timerInterval) clearInterval(timerInterval);

    const isSoundOn = ThemeStore.getState().soundEnabled;
    AudioAlerts.playAcceptedChime(isSoundOn);

    const req = globalDeliveryState.pendingRequest;
    this.setState({ isProcessing: true, error: null });

    try {
      const order = await DeliveryApi.acceptRequest(req.id);
      if (req.isBatchOrder) {
        order.orderNumber = req.orderNumber;
        order.financials.totalEarnings = req.estimatedEarnings;
      }

      // Update acceptance metrics
      const newOffered = globalDeliveryState.acceptanceMetrics.totalOffered + 1;
      const newAccepted = globalDeliveryState.acceptanceMetrics.totalAccepted + 1;
      const newRate = Math.round((newAccepted / newOffered) * 100);

      this.setState({
        activeDelivery: order,
        pendingRequest: null,
        requestSecondsRemaining: 0,
        isDeclineModalOpen: false,
        acceptanceMetrics: {
          totalOffered: newOffered,
          totalAccepted: newAccepted,
          ratePercentage: newRate,
        },
        isProcessing: false,
      });
    } catch (err: any) {
      this.setState({ isProcessing: false, error: err.message || 'Failed to accept delivery' });
    }
  },

  async declineIncomingRequest(reason?: string) {
    if (!globalDeliveryState.pendingRequest) return;
    if (timerInterval) clearInterval(timerInterval);

    const isSoundOn = ThemeStore.getState().soundEnabled;
    AudioAlerts.playDeclinedChime(isSoundOn);

    // Update acceptance rate on explicit decline
    const newOffered = globalDeliveryState.acceptanceMetrics.totalOffered + 1;
    const newAccepted = globalDeliveryState.acceptanceMetrics.totalAccepted;
    const newRate = Math.round((newAccepted / newOffered) * 100);

    try {
      await DeliveryApi.rejectRequest(globalDeliveryState.pendingRequest.id, reason);
    } finally {
      this.setState({
        pendingRequest: null,
        requestSecondsRemaining: 0,
        isDeclineModalOpen: false,
        acceptanceMetrics: {
          totalOffered: newOffered,
          totalAccepted: newAccepted,
          ratePercentage: newRate,
        },
      });

      // Show warning modal if rate dropped under 75%
      if (newRate < 75) {
        this.setAcceptanceRateWarningOpen(true);
      }
    }
  },

  async advanceDeliveryStatus(targetStatus?: DeliveryStatus, extraData?: any) {
    const current = globalDeliveryState.activeDelivery;
    if (!current) return;

    // Standard state machine transition ladder
    const statusProgression: Record<DeliveryStatus, DeliveryStatus> = {
      ASSIGNED: 'GOING_TO_RESTAURANT',
      GOING_TO_RESTAURANT: 'ARRIVED_AT_RESTAURANT',
      ARRIVED_AT_RESTAURANT: 'ORDER_PICKED_UP',
      ORDER_PICKED_UP: 'GOING_TO_CUSTOMER',
      GOING_TO_CUSTOMER: 'ARRIVED_AT_CUSTOMER',
      ARRIVED_AT_CUSTOMER: 'DELIVERED',
      DELIVERED: 'DELIVERED',
      CANCELLED: 'CANCELLED',
      FAILED: 'FAILED',
      RETURNED: 'RETURNED',
    };

    const nextStatus = targetStatus || statusProgression[current.status];
    if (!nextStatus || nextStatus === current.status) return;

    this.setState({ isProcessing: true, error: null });
    try {
      const updated = await DeliveryApi.updateDeliveryStatus(current.id, nextStatus, extraData);
      this.setState({
        activeDelivery: updated,
        isProcessing: false,
      });
    } catch (err: any) {
      this.setState({ isProcessing: false, error: err.message || 'Status transition failed' });
    }
  },

  async verifyOtpAndComplete(otp: string) {
    const current = globalDeliveryState.activeDelivery;
    if (!current) return;

    this.setState({ isProcessing: true, error: null });
    try {
      const updated = await DeliveryApi.verifyDeliveryOtp(current.id, otp);
      this.setState({
        activeDelivery: updated,
        isProcessing: false,
      });
    } catch (err: any) {
      this.setState({ isProcessing: false, error: err.message || 'Invalid delivery OTP' });
      throw err;
    }
  },

  async collectCodPayment() {
    const current = globalDeliveryState.activeDelivery;
    if (!current) return;

    this.setState({ isProcessing: true });
    try {
      await DeliveryApi.confirmCashCollected(current.id, current.financials.customerOrderTotal);
      const updated = {
        ...current,
        financials: {
          ...current.financials,
          isCashCollected: true,
        },
      };
      this.setState({ activeDelivery: updated, isProcessing: false });
    } catch (err: any) {
      this.setState({ isProcessing: false, error: err.message });
    }
  },

  clearActiveDelivery() {
    this.setState({ activeDelivery: null });
  },

  resetDemoDelivery() {
    this.setState({
      activeDelivery: { ...MOCK_ACTIVE_DELIVERY, status: 'GOING_TO_RESTAURANT' },
      pendingRequest: null,
      error: null,
    });
  },
};

export function useDelivery() {
  const [state, setState] = useState<DeliveryState>(DeliveryStore.getState());

  useEffect(() => {
    listeners.add(setState);
    return () => {
      listeners.delete(setState);
    };
  }, []);

  return {
    ...state,
    setDeclineModalOpen: DeliveryStore.setDeclineModalOpen.bind(DeliveryStore),
    setAcceptanceRateWarningOpen: DeliveryStore.setAcceptanceRateWarningOpen.bind(DeliveryStore),
    triggerIncomingRequest: DeliveryStore.triggerIncomingRequest.bind(DeliveryStore),
    triggerBatchDeliveryOffer: DeliveryStore.triggerBatchDeliveryOffer.bind(DeliveryStore),
    triggerStackedDeliveryOffer: DeliveryStore.triggerStackedDeliveryOffer.bind(DeliveryStore),
    acceptIncomingRequest: DeliveryStore.acceptIncomingRequest.bind(DeliveryStore),
    declineIncomingRequest: DeliveryStore.declineIncomingRequest.bind(DeliveryStore),
    advanceDeliveryStatus: DeliveryStore.advanceDeliveryStatus.bind(DeliveryStore),
    verifyOtpAndComplete: DeliveryStore.verifyOtpAndComplete.bind(DeliveryStore),
    collectCodPayment: DeliveryStore.collectCodPayment.bind(DeliveryStore),
    clearActiveDelivery: DeliveryStore.clearActiveDelivery.bind(DeliveryStore),
    resetDemoDelivery: DeliveryStore.resetDemoDelivery.bind(DeliveryStore),
  };
}
