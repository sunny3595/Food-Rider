import { useState, useEffect } from 'react';
import { RiderSettings } from '../types/settings.types';

const DEFAULT_SETTINGS: RiderSettings = {
  navigation: {
    defaultApp: 'GOOGLE_MAPS',
    voiceGuidance: true,
    avoidTolls: false,
    avoidHighways: false,
  },
  orders: {
    autoAcceptPrepaid: false,
    maxDeliveryDistanceKm: 10,
    allowCashOnDelivery: true,
    allowStackedDeliveries: true,
  },
  notifications: {
    sound: 'RADAR_CHIME',
    maxVolumeOverride: true,
    vibration: 'HEARTBEAT',
    screenFlashOnOrder: true,
    announcements: true,
  },
  system: {
    theme: 'DARK',
    language: 'en',
    batterySaverMode: false,
    offlineMapsCached: true,
  },
};

let globalSettings: RiderSettings = { ...DEFAULT_SETTINGS };
const listeners = new Set<(settings: RiderSettings) => void>();

function notify() {
  listeners.forEach((listener) => listener(globalSettings));
}

export const SettingsStore = {
  getSettings() {
    return globalSettings;
  },

  updateSettings(partial: Partial<RiderSettings>) {
    globalSettings = {
      ...globalSettings,
      ...partial,
      navigation: { ...globalSettings.navigation, ...partial.navigation },
      orders: { ...globalSettings.orders, ...partial.orders },
      notifications: { ...globalSettings.notifications, ...partial.notifications },
      system: { ...globalSettings.system, ...partial.system },
    };
    notify();
  },

  clearAppCache() {
    // Simulates clearing temporary cached map tiles and thumbnails
    return true;
  },
};

export function useSettings() {
  const [settings, setSettings] = useState<RiderSettings>(SettingsStore.getSettings());

  useEffect(() => {
    listeners.add(setSettings);
    return () => {
      listeners.delete(setSettings);
    };
  }, []);

  return {
    settings,
    updateSettings: SettingsStore.updateSettings.bind(SettingsStore),
    clearAppCache: SettingsStore.clearAppCache.bind(SettingsStore),
  };
}
