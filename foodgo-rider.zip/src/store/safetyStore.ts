import { useState, useEffect } from 'react';
import {
  SosStatus,
  EmergencyContact,
  SosIncidentReport,
  StationaryCheckState,
  HelmetVerificationState,
} from '../types/safety.types';

interface SafetyState {
  sosStatus: SosStatus;
  countdownSeconds: number;
  isSirenPlaying: boolean;
  contacts: EmergencyContact[];
  activeIncident: SosIncidentReport | null;
  stationaryCheck: StationaryCheckState;
  helmetState: HelmetVerificationState;
}

const DEFAULT_CONTACTS: EmergencyContact[] = [
  { id: 'ec_1', name: 'National Police Dispatch', relationship: 'POLICE', phone: '112', isDefault: true },
  { id: 'ec_2', name: 'Emergency Medical Ambulance', relationship: 'AMBULANCE', phone: '108', isDefault: true },
  { id: 'ec_3', name: 'FoodGo 24/7 Safety Command Center', relationship: 'FOODGO_COMMAND', phone: '+91 80 4719 0000', isDefault: true },
  { id: 'ec_4', name: 'Sunita S (Mother)', relationship: 'FAMILY', phone: '+91 98451 22910', isDefault: true },
];

let globalSafetyState: SafetyState = {
  sosStatus: 'IDLE',
  countdownSeconds: 5,
  isSirenPlaying: false,
  contacts: DEFAULT_CONTACTS,
  activeIncident: null,
  stationaryCheck: {
    isStationaryAlertActive: false,
    idleDurationMinutes: 16,
    orderNumber: '#FG-10245',
  },
  helmetState: {
    isVerifiedToday: true,
    verifiedAt: 'Today, 08:30 AM',
    photoUrl: 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=400&q=80',
  },
};

const listeners = new Set<(state: SafetyState) => void>();
let countdownInterval: any = null;

function notify() {
  listeners.forEach((listener) => listener(globalSafetyState));
}

export const SafetyStore = {
  getState() {
    return globalSafetyState;
  },

  setState(partial: Partial<SafetyState>) {
    globalSafetyState = { ...globalSafetyState, ...partial };
    notify();
  },

  startSosCountdown() {
    if (globalSafetyState.sosStatus === 'ACTIVATED') return;
    if (countdownInterval) clearInterval(countdownInterval);

    this.setState({ sosStatus: 'COUNTDOWN', countdownSeconds: 5 });

    countdownInterval = setInterval(() => {
      const current = globalSafetyState.countdownSeconds;
      if (current <= 1) {
        clearInterval(countdownInterval);
        countdownInterval = null;
        SafetyStore.triggerSosNow();
      } else {
        SafetyStore.setState({ countdownSeconds: current - 1 });
      }
    }, 1000);
  },

  cancelSosCountdown() {
    if (countdownInterval) {
      clearInterval(countdownInterval);
      countdownInterval = null;
    }
    this.setState({ sosStatus: 'IDLE', countdownSeconds: 5, isSirenPlaying: false });
  },

  triggerSosNow() {
    if (countdownInterval) {
      clearInterval(countdownInterval);
      countdownInterval = null;
    }

    const incident: SosIncidentReport = {
      incidentId: `SOS_${Date.now().toString().slice(-6)}`,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      riderId: 'RD-1024',
      riderName: 'Dhanush S',
      latitude: 12.9716,
      longitude: 77.5946,
      activeOrderNumber: '#FG-10245',
      dispatchedTo: ['Police 112', 'Ambulance 108', 'FoodGo Command', 'Emergency Contact (+91 98451 ••••)'],
      audioRecordingActive: true,
      status: 'ACTIVE',
    };

    this.setState({
      sosStatus: 'ACTIVATED',
      activeIncident: incident,
      isSirenPlaying: true,
    });
  },

  deactivateSos() {
    this.setState({
      sosStatus: 'RESOLVED',
      isSirenPlaying: false,
      activeIncident: null,
    });
    setTimeout(() => {
      SafetyStore.setState({ sosStatus: 'IDLE', countdownSeconds: 5 });
    }, 1500);
  },

  toggleSiren() {
    this.setState({ isSirenPlaying: !globalSafetyState.isSirenPlaying });
  },

  triggerStationaryAlert() {
    this.setState({
      stationaryCheck: {
        isStationaryAlertActive: true,
        idleDurationMinutes: 16,
        orderNumber: '#FG-10245',
      },
    });
  },

  resolveStationaryAlert() {
    this.setState({
      stationaryCheck: {
        ...globalSafetyState.stationaryCheck,
        isStationaryAlertActive: false,
      },
    });
  },

  verifyHelmetPhoto(photoUrl: string) {
    this.setState({
      helmetState: {
        isVerifiedToday: true,
        verifiedAt: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
        photoUrl,
      },
    });
  },
};

export function useSafety() {
  const [state, setState] = useState<SafetyState>(SafetyStore.getState());

  useEffect(() => {
    listeners.add(setState);
    return () => {
      listeners.delete(setState);
    };
  }, []);

  return {
    ...state,
    startSosCountdown: SafetyStore.startSosCountdown.bind(SafetyStore),
    cancelSosCountdown: SafetyStore.cancelSosCountdown.bind(SafetyStore),
    triggerSosNow: SafetyStore.triggerSosNow.bind(SafetyStore),
    deactivateSos: SafetyStore.deactivateSos.bind(SafetyStore),
    toggleSiren: SafetyStore.toggleSiren.bind(SafetyStore),
    triggerStationaryAlert: SafetyStore.triggerStationaryAlert.bind(SafetyStore),
    resolveStationaryAlert: SafetyStore.resolveStationaryAlert.bind(SafetyStore),
    verifyHelmetPhoto: SafetyStore.verifyHelmetPhoto.bind(SafetyStore),
  };
}
