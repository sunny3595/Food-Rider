import { useState, useEffect } from 'react';
import { RiderDutyStatus, RiderLocation, RiderProfile } from '../types/rider.types';
import { RiderApi } from '../api/rider.api';
import { MOCK_RIDER_PROFILE } from '../api/mockData';

interface RiderState {
  profile: RiderProfile;
  dutyStatus: RiderDutyStatus;
  isConnecting: boolean;
  gpsActive: boolean;
  lastLocation: RiderLocation;
  locationError: string | null;
}

let globalRiderState: RiderState = {
  profile: MOCK_RIDER_PROFILE,
  dutyStatus: 'ONLINE',
  isConnecting: false,
  gpsActive: true,
  lastLocation: MOCK_RIDER_PROFILE.currentLocation || {
    latitude: 12.9716,
    longitude: 77.5946,
    timestamp: Date.now(),
  },
  locationError: null,
};

const listeners = new Set<(state: RiderState) => void>();

function notify() {
  listeners.forEach((listener) => listener(globalRiderState));
}

export const RiderStore = {
  getState() {
    return globalRiderState;
  },

  setState(partial: Partial<RiderState>) {
    globalRiderState = { ...globalRiderState, ...partial };
    notify();
  },

  async toggleDutyStatus() {
    const nextStatus: RiderDutyStatus = globalRiderState.dutyStatus === 'ONLINE' ? 'OFFLINE' : 'ONLINE';
    this.setState({ isConnecting: true });

    try {
      if (nextStatus === 'ONLINE') {
        // In native Expo, verify location permission here. In Web preview, check navigator.geolocation
        if (typeof navigator !== 'undefined' && 'geolocation' in navigator) {
          navigator.geolocation.getCurrentPosition(
            (pos) => {
              this.updateLocation({
                latitude: pos.coords.latitude,
                longitude: pos.coords.longitude,
                accuracy: pos.coords.accuracy,
                timestamp: pos.timestamp,
              });
            },
            (err) => {
              console.warn('Geolocation error:', err.message);
            },
            { enableHighAccuracy: true, timeout: 5000 }
          );
        }
      }

      await RiderApi.updateDutyStatus(nextStatus);
      this.setState({
        dutyStatus: nextStatus,
        isConnecting: false,
        gpsActive: nextStatus === 'ONLINE',
      });
    } catch {
      this.setState({ isConnecting: false });
    }
  },

  updateLocation(loc: RiderLocation) {
    globalRiderState.lastLocation = loc;
    RiderApi.sendLocationPing(loc).catch(() => {});
    notify();
  },

  simulateMovement(stepLat = 0.0005, stepLng = 0.0005) {
    const cur = globalRiderState.lastLocation;
    const newLoc: RiderLocation = {
      latitude: cur.latitude + stepLat,
      longitude: cur.longitude + stepLng,
      heading: (cur.heading || 0) + 15,
      speed: 28,
      timestamp: Date.now(),
    };
    this.updateLocation(newLoc);
  },
};

export function useRider() {
  const [state, setState] = useState<RiderState>(RiderStore.getState());

  useEffect(() => {
    listeners.add(setState);
    return () => {
      listeners.delete(setState);
    };
  }, []);

  return {
    ...state,
    toggleDutyStatus: RiderStore.toggleDutyStatus.bind(RiderStore),
    updateLocation: RiderStore.updateLocation.bind(RiderStore),
    simulateMovement: RiderStore.simulateMovement.bind(RiderStore),
  };
}
