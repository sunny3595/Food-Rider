import { useState, useEffect } from 'react';
import { SupportedLanguage, TRANSLATIONS } from '../constants/translations';
import { SecureStorage } from '../utils/storage';

export type AppTheme = 'dark' | 'light' | 'system';

interface ThemeState {
  theme: AppTheme;
  language: SupportedLanguage;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  isSimulatorOpen: boolean;
}

let globalThemeState: ThemeState = {
  theme: 'dark',
  language: 'en',
  soundEnabled: true,
  vibrationEnabled: true,
  isSimulatorOpen: false,
};

const listeners = new Set<(state: ThemeState) => void>();

function notify() {
  listeners.forEach((listener) => listener(globalThemeState));
}

export const ThemeStore = {
  getState() {
    return globalThemeState;
  },

  setState(partial: Partial<ThemeState>) {
    globalThemeState = { ...globalThemeState, ...partial };
    notify();
  },

  async setLanguage(lang: SupportedLanguage) {
    this.setState({ language: lang });
    await SecureStorage.setItem('preferred_language', lang);
  },

  async setTheme(theme: AppTheme) {
    this.setState({ theme });
    await SecureStorage.setItem('preferred_theme', theme);
  },

  toggleSound() {
    this.setState({ soundEnabled: !globalThemeState.soundEnabled });
  },

  toggleVibration() {
    this.setState({ vibrationEnabled: !globalThemeState.vibrationEnabled });
  },

  toggleSimulator() {
    this.setState({ isSimulatorOpen: !globalThemeState.isSimulatorOpen });
  },

  t(key: string, fallback?: string): string {
    const lang = globalThemeState.language;
    return TRANSLATIONS[lang]?.[key] || TRANSLATIONS.en[key] || fallback || key;
  },
};

export function useTheme() {
  const [state, setState] = useState<ThemeState>(ThemeStore.getState());

  useEffect(() => {
    listeners.add(setState);
    return () => {
      listeners.delete(setState);
    };
  }, []);

  return {
    ...state,
    setLanguage: ThemeStore.setLanguage.bind(ThemeStore),
    setTheme: ThemeStore.setTheme.bind(ThemeStore),
    toggleSound: ThemeStore.toggleSound.bind(ThemeStore),
    toggleVibration: ThemeStore.toggleVibration.bind(ThemeStore),
    toggleSimulator: ThemeStore.toggleSimulator.bind(ThemeStore),
    t: ThemeStore.t.bind(ThemeStore),
  };
}
