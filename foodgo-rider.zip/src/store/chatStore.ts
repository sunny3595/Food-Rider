import { useState, useEffect } from 'react';
import {
  ChatChannel,
  ChatMessageItem,
  VoipCallSession,
  VoipCallStatus,
  MessageContentType,
} from '../types/chat.types';

interface ChatState {
  activeChannel: ChatChannel;
  messages: Record<ChatChannel, ChatMessageItem[]>;
  voipCall: VoipCallSession | null;
  isRecordingVoice: boolean;
  recordingSeconds: number;
}

const INITIAL_MESSAGES: Record<ChatChannel, ChatMessageItem[]> = {
  CUSTOMER: [
    {
      id: 'c_1',
      channel: 'CUSTOMER',
      senderRole: 'CUSTOMER',
      senderName: 'Aarav Sharma',
      text: 'Hi Dhanush! Please ring bell twice when you reach the 4th floor.',
      timestamp: '02:42 PM',
      isRead: true,
    },
    {
      id: 'c_2',
      channel: 'CUSTOMER',
      senderRole: 'RIDER',
      senderName: 'You',
      text: 'Sure sir, I have picked up your order and am en route.',
      timestamp: '02:43 PM',
      isRead: true,
    },
  ],
  RESTAURANT: [
    {
      id: 'r_1',
      channel: 'RESTAURANT',
      senderRole: 'RESTAURANT',
      senderName: 'Burger King Counter',
      text: 'Order #FG-10245 is currently in the kitchen fryer. Ready in ~3 minutes.',
      timestamp: '02:35 PM',
      isRead: true,
    },
    {
      id: 'r_2',
      channel: 'RESTAURANT',
      senderRole: 'RIDER',
      senderName: 'You',
      text: 'Understood, waiting at the partner collection bay.',
      timestamp: '02:36 PM',
      isRead: true,
    },
  ],
  SUPPORT: [
    {
      id: 's_1',
      channel: 'SUPPORT',
      senderRole: 'SUPPORT',
      senderName: 'Pooja (FoodGo Dispatch Support)',
      text: 'Hello Dhanush! You are connected to FoodGo Fleet Support. How can we help you on your active shift today?',
      timestamp: '02:20 PM',
      isRead: true,
    },
  ],
};

let globalChatState: ChatState = {
  activeChannel: 'CUSTOMER',
  messages: INITIAL_MESSAGES,
  voipCall: null,
  isRecordingVoice: false,
  recordingSeconds: 0,
};

const listeners = new Set<(state: ChatState) => void>();
let callTimerInterval: any = null;
let voiceRecordInterval: any = null;

function notify() {
  listeners.forEach((listener) => listener(globalChatState));
}

export const ChatStore = {
  getState() {
    return globalChatState;
  },

  setState(partial: Partial<ChatState>) {
    globalChatState = { ...globalChatState, ...partial };
    notify();
  },

  setActiveChannel(channel: ChatChannel) {
    this.setState({ activeChannel: channel });
  },

  sendMessage(channel: ChatChannel, text: string, attachmentType?: MessageContentType, attachmentUrl?: string) {
    if (!text.trim() && !attachmentType) return;

    const newMsg: ChatMessageItem = {
      id: `msg_${Date.now()}`,
      channel,
      senderRole: 'RIDER',
      senderName: 'You',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      isRead: true,
      attachment: attachmentType ? { type: attachmentType, url: attachmentUrl } : undefined,
    };

    const currentChannelMsgs = globalChatState.messages[channel] || [];
    const updatedMessages = {
      ...globalChatState.messages,
      [channel]: [...currentChannelMsgs, newMsg],
    };

    this.setState({ messages: updatedMessages });

    // Simulate smart auto-replies based on channel
    setTimeout(() => {
      this.simulateIncomingReply(channel, text);
    }, 1200);
  },

  simulateIncomingReply(channel: ChatChannel, sentText: string) {
    let replyText = 'Got it! Thank you for the update.';
    let senderRole: 'CUSTOMER' | 'RESTAURANT' | 'SUPPORT' = 'CUSTOMER';
    let senderName = 'Aarav Sharma';

    if (channel === 'CUSTOMER') {
      senderRole = 'CUSTOMER';
      senderName = 'Aarav Sharma';
      if (sentText.toLowerCase().includes('gate') || sentText.toLowerCase().includes('outside')) {
        replyText = 'Thanks! Taking the elevator and coming down to gate right away.';
      } else if (sentText.toLowerCase().includes('traffic') || sentText.toLowerCase().includes('delay')) {
        replyText = 'No problem at all, ride safe! Keep me posted.';
      } else {
        replyText = 'Thank you for the update! See you soon.';
      }
    } else if (channel === 'RESTAURANT') {
      senderRole = 'RESTAURANT';
      senderName = 'Burger King Counter';
      replyText = 'Items are sealed and packaged. You can collect from counter with code PK-82.';
    } else if (channel === 'SUPPORT') {
      senderRole = 'SUPPORT';
      senderName = 'Pooja (Dispatch Support)';
      replyText = 'Ticket #849201 updated. We have flagged this on our dispatch monitor. Please proceed safely.';
    }

    const replyMsg: ChatMessageItem = {
      id: `msg_${Date.now()}`,
      channel,
      senderRole,
      senderName,
      text: replyText,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      isRead: true,
    };

    const currentChannelMsgs = globalChatState.messages[channel] || [];
    this.setState({
      messages: {
        ...globalChatState.messages,
        [channel]: [...currentChannelMsgs, replyMsg],
      },
    });
  },

  startVoiceRecording() {
    this.setState({ isRecordingVoice: true, recordingSeconds: 0 });
    voiceRecordInterval = setInterval(() => {
      ChatStore.setState({ recordingSeconds: globalChatState.recordingSeconds + 1 });
    }, 1000);
  },

  stopAndSendVoiceRecording(channel: ChatChannel) {
    if (voiceRecordInterval) {
      clearInterval(voiceRecordInterval);
      voiceRecordInterval = null;
    }

    const duration = Math.max(1, globalChatState.recordingSeconds);
    this.setState({ isRecordingVoice: false, recordingSeconds: 0 });

    const voiceMsg: ChatMessageItem = {
      id: `msg_voice_${Date.now()}`,
      channel,
      senderRole: 'RIDER',
      senderName: 'You',
      text: `🎤 Voice note (${duration}s)`,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      isRead: true,
      attachment: {
        type: 'VOICE_NOTE',
        durationSeconds: duration,
      },
    };

    const currentChannelMsgs = globalChatState.messages[channel] || [];
    this.setState({
      messages: {
        ...globalChatState.messages,
        [channel]: [...currentChannelMsgs, voiceMsg],
      },
    });
  },

  cancelVoiceRecording() {
    if (voiceRecordInterval) {
      clearInterval(voiceRecordInterval);
      voiceRecordInterval = null;
    }
    this.setState({ isRecordingVoice: false, recordingSeconds: 0 });
  },

  startVoipCall(targetName: string, targetRole: 'CUSTOMER' | 'RESTAURANT' | 'SUPPORT') {
    if (callTimerInterval) clearInterval(callTimerInterval);

    const maskedProxyNumber = '+91 80 4719 2831'; // Exotel/Twilio Virtual Bridge
    const session: VoipCallSession = {
      targetName,
      targetRole,
      maskedProxyNumber,
      status: 'DIALING',
      durationSeconds: 0,
      isMuted: false,
      isSpeakerOn: false,
    };

    this.setState({ voipCall: session });

    // Connect after 1.5 seconds
    setTimeout(() => {
      if (!globalChatState.voipCall) return;
      ChatStore.setState({
        voipCall: {
          ...globalChatState.voipCall,
          status: 'CONNECTED',
        },
      });

      callTimerInterval = setInterval(() => {
        if (!globalChatState.voipCall) {
          clearInterval(callTimerInterval);
          return;
        }
        ChatStore.setState({
          voipCall: {
            ...globalChatState.voipCall,
            durationSeconds: globalChatState.voipCall.durationSeconds + 1,
          },
        });
      }, 1000);
    }, 1500);
  },

  endVoipCall() {
    if (callTimerInterval) {
      clearInterval(callTimerInterval);
      callTimerInterval = null;
    }

    if (globalChatState.voipCall) {
      this.setState({
        voipCall: {
          ...globalChatState.voipCall,
          status: 'ENDED',
        },
      });
      setTimeout(() => {
        ChatStore.setState({ voipCall: null });
      }, 800);
    }
  },

  toggleCallMute() {
    if (!globalChatState.voipCall) return;
    this.setState({
      voipCall: {
        ...globalChatState.voipCall,
        isMuted: !globalChatState.voipCall.isMuted,
      },
    });
  },

  toggleCallSpeaker() {
    if (!globalChatState.voipCall) return;
    this.setState({
      voipCall: {
        ...globalChatState.voipCall,
        isSpeakerOn: !globalChatState.voipCall.isSpeakerOn,
      },
    });
  },
};

export function useChat() {
  const [state, setState] = useState<ChatState>(ChatStore.getState());

  useEffect(() => {
    listeners.add(setState);
    return () => {
      listeners.delete(setState);
    };
  }, []);

  return {
    ...state,
    setActiveChannel: ChatStore.setActiveChannel.bind(ChatStore),
    sendMessage: ChatStore.sendMessage.bind(ChatStore),
    startVoiceRecording: ChatStore.startVoiceRecording.bind(ChatStore),
    stopAndSendVoiceRecording: ChatStore.stopAndSendVoiceRecording.bind(ChatStore),
    cancelVoiceRecording: ChatStore.cancelVoiceRecording.bind(ChatStore),
    startVoipCall: ChatStore.startVoipCall.bind(ChatStore),
    endVoipCall: ChatStore.endVoipCall.bind(ChatStore),
    toggleCallMute: ChatStore.toggleCallMute.bind(ChatStore),
    toggleCallSpeaker: ChatStore.toggleCallSpeaker.bind(ChatStore),
  };
}
