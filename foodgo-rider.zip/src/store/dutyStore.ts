import { useState, useEffect } from 'react';
import { HotspotZone, ShiftSummary, DeviceBatteryStatus } from '../types/dashboard.types';
import { RiderStore } from './riderStore';
import { AuthStore } from './authStore';

interface DutyState {
  isGpsPermissionGranted: boolean;
  isLocationServiceOn: boolean;
  isPermissionModalOpen: boolean;
  isOfflineConfirmOpen: boolean;
  isNotificationsDrawerOpen: boolean;
  battery: DeviceBatteryStatus;
  shift: ShiftSummary;
  hotspots: HotspotZone[];
  dutyError: string | null;
}

const INITIAL_HOTSPOTS: HotspotZone[] = [
  {
    id: 'zone_indiranagar',
    name: 'Indiranagar 100ft Rd',
    demandLevel: 'VERY_HIGH',
    surgeMultiplier: 1.4,
    estimatedOrdersPerHour: 48,
    distanceKm: 1.2,
    latitude: 12.9784,
    longitude: 77.6408,
    recommendedTimeWindow: 'Peak Rush till 11:00 PM',
  },
  {
    id: 'zone_koramangala',
    name: 'Koramangala 4th & 5th Block',
    demandLevel: 'HIGH',
    surgeMultiplier: 1.2,
    estimatedOrdersPerHour: 34,
    distanceKm: 3.4,
    latitude: 12.9344,
    longitude: 77.6101,
    recommendedTimeWindow: 'High Dinner Demand',
  },
  {
    id: 'zone_hsr',
    name: 'HSR Layout Sector 1 & 2',
    demandLevel: 'MODERATE',
    surgeMultiplier: 1.0,
    estimatedOrdersPerHour: 22,
    distanceKm: 5.1,
    latitude: 12.9116,
    longitude: 77.6474,
  },
  {
    id: 'zone_whitefield',
    name: 'Whitefield ITPL Main Rd',
    demandLevel: 'HIGH',
    surgeMultiplier: 1.2,
    estimatedOrdersPerHour: 30,
    distanceKm: 9.8,
    latitude: 12.9698,
    longitude: 77.7500,
    recommendedTimeWindow: 'Tech Park Night Shifts',
  },
];

let globalDutyState: DutyState = {
  isGpsPermissionGranted: true,
  isLocationServiceOn: true,
  isPermissionModalOpen: false,
  isOfflineConfirmOpen: false,
  isNotificationsDrawerOpen: false,
  battery: {
    levelPercent: 82,
    isCharging: false,
    isLowBatteryWarning: false,
  },
  shift: {
    shiftStartedAt: Date.now() - (6 * 3600 + 32 * 60) * 1000, // 6h 32m ago
    totalOnlineSecondsToday: 6 * 3600 + 32 * 60,
    isPaused: false,
    totalOrdersCompletedToday: 11,
    totalEarningsToday: 1420,
    totalDistanceCoveredKm: 46.8,
  },
  hotspots: INITIAL_HOTSPOTS,
  dutyError: null,
};

const listeners = new Set<(state: DutyState) => void>();

function notify() {
  listeners.forEach((listener) => listener(globalDutyState));
}

// Live Shift Timer incrementor
setInterval(() => {
  const riderState = RiderStore.getState();
  if (riderState.dutyStatus === 'ONLINE' && !globalDutyState.shift.isPaused) {
    globalDutyState.shift = {
      ...globalDutyState.shift,
      totalOnlineSecondsToday: globalDutyState.shift.totalOnlineSecondsToday + 1,
    };
    notify();
  }
}, 1000);

export const DutyStore = {
  getState() {
    return globalDutyState;
  },

  setState(partial: Partial<DutyState>) {
    globalDutyState = { ...globalDutyState, ...partial };
    notify();
  },

  setPermissionModalOpen(isOpen: boolean) {
    this.setState({ isPermissionModalOpen: isOpen });
  },

  setOfflineConfirmOpen(isOpen: boolean) {
    this.setState({ isOfflineConfirmOpen: isOpen });
  },

  setNotificationsDrawerOpen(isOpen: boolean) {
    this.setState({ isNotificationsDrawerOpen: isOpen });
  },

  grantLocationPermission() {
    this.setState({
      isGpsPermissionGranted: true,
      isLocationServiceOn: true,
      isPermissionModalOpen: false,
      dutyError: null,
    });
  },

  revokeLocationPermission() {
    this.setState({
      isGpsPermissionGranted: false,
    });
    // Force offline if GPS revoked
    if (RiderStore.getState().dutyStatus === 'ONLINE') {
      RiderStore.setState({ dutyStatus: 'LOCATION_REQUIRED' });
    }
  },

  toggleBatterySimulation(level = 15) {
    const isLow = level <= 20;
    this.setState({
      battery: {
        levelPercent: level,
        isCharging: false,
        isLowBatteryWarning: isLow,
      },
    });
  },

  restoreBattery() {
    this.setState({
      battery: {
        levelPercent: 88,
        isCharging: true,
        isLowBatteryWarning: false,
      },
    });
  },

  async handleDutyToggleRequest() {
    const riderState = RiderStore.getState();
    const authState = AuthStore.getState();

    // 1. Account Status Validation Guard
    if (authState.rider?.accountStatus === 'PENDING_VERIFICATION') {
      this.setState({ dutyError: 'Account is under verification. You cannot go online yet.' });
      return;
    }
    if (authState.rider?.accountStatus === 'SUSPENDED') {
      this.setState({ dutyError: 'Account is suspended. Please contact partner support.' });
      return;
    }

    // 2. Going from ONLINE to OFFLINE -> Show confirmation dialog
    if (riderState.dutyStatus === 'ONLINE') {
      this.setOfflineConfirmOpen(true);
      return;
    }

    // 3. Going from OFFLINE to ONLINE -> Location checks
    if (!globalDutyState.isGpsPermissionGranted || !globalDutyState.isLocationServiceOn) {
      this.setPermissionModalOpen(true);
      return;
    }

    // Allow going online
    this.setState({ dutyError: null });
    await RiderStore.toggleDutyStatus();
  },

  async confirmGoOffline() {
    this.setOfflineConfirmOpen(false);
    await RiderStore.toggleDutyStatus();
  },
};

export function useDuty() {
  const [state, setState] = useState<DutyState>(DutyStore.getState());

  useEffect(() => {
    listeners.add(setState);
    return () => {
      listeners.delete(setState);
    };
  }, []);

  return {
    ...state,
    setPermissionModalOpen: DutyStore.setPermissionModalOpen.bind(DutyStore),
    setOfflineConfirmOpen: DutyStore.setOfflineConfirmOpen.bind(DutyStore),
    setNotificationsDrawerOpen: DutyStore.setNotificationsDrawerOpen.bind(DutyStore),
    grantLocationPermission: DutyStore.grantLocationPermission.bind(DutyStore),
    revokeLocationPermission: DutyStore.revokeLocationPermission.bind(DutyStore),
    toggleBatterySimulation: DutyStore.toggleBatterySimulation.bind(DutyStore),
    restoreBattery: DutyStore.restoreBattery.bind(DutyStore),
    handleDutyToggleRequest: DutyStore.handleDutyToggleRequest.bind(DutyStore),
    confirmGoOffline: DutyStore.confirmGoOffline.bind(DutyStore),
  };
}
