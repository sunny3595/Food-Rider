import { useState, useEffect } from 'react';
import { AuthTokens, LoginCredentials } from '../types/api.types';
import { RiderAccountStatus, RiderProfile } from '../types/rider.types';
import { AuthApi } from '../api/auth.api';
import { SecureStorage } from '../utils/storage';
import { MOCK_RIDER_PROFILE } from '../api/mockData';

export type AuthScreenType =
  | 'welcome'
  | 'login'
  | 'verify-phone'
  | 'forgot-password'
  | 'reset-password'
  | 'register';

interface AuthState {
  isAuthenticated: boolean;
  isLoading: boolean;
  rider: RiderProfile | null;
  tokens: AuthTokens | null;
  hasCompletedOnboarding: boolean;
  currentAuthScreen: AuthScreenType;
  phoneForOtpVerification: string;
  error: string | null;
}

let globalAuthState: AuthState = {
  isAuthenticated: false,
  isLoading: true,
  rider: null,
  tokens: null,
  hasCompletedOnboarding: true,
  currentAuthScreen: 'welcome',
  phoneForOtpVerification: '',
  error: null,
};

const listeners = new Set<(state: AuthState) => void>();

function notify() {
  listeners.forEach((listener) => listener(globalAuthState));
}

export const AuthStore = {
  getState() {
    return globalAuthState;
  },

  setState(partial: Partial<AuthState>) {
    globalAuthState = { ...globalAuthState, ...partial };
    notify();
  },

  setAuthScreen(screen: AuthScreenType) {
    this.setState({ currentAuthScreen: screen, error: null });
  },

  setPhoneForOtp(phone: string) {
    this.setState({ phoneForOtpVerification: phone });
  },

  async initialize() {
    try {
      this.setState({ isLoading: true, error: null });
      const onboardingDone = await SecureStorage.getItem('onboarding_completed');
      const rider = await AuthApi.getCurrentSession();
      if (rider) {
        this.setState({
          isAuthenticated: true,
          rider,
          hasCompletedOnboarding: onboardingDone !== 'false',
          isLoading: false,
        });
      } else {
        this.setState({
          isAuthenticated: false,
          rider: null,
          hasCompletedOnboarding: onboardingDone !== 'false',
          isLoading: false,
        });
      }
    } catch {
      this.setState({ isAuthenticated: false, rider: null, isLoading: false });
    }
  },

  async login(credentials: LoginCredentials) {
    try {
      this.setState({ isLoading: true, error: null });
      const { tokens, rider } = await AuthApi.login(credentials);
      this.setState({
        isAuthenticated: true,
        rider,
        tokens,
        isLoading: false,
      });
      return rider;
    } catch (err: any) {
      this.setState({ isLoading: false, error: err.message || 'Login failed' });
      throw err;
    }
  },

  async loginWithGoogle() {
    try {
      this.setState({ isLoading: true, error: null });
      const { tokens, rider } = await AuthApi.loginWithGoogle();
      this.setState({
        isAuthenticated: true,
        rider,
        tokens,
        isLoading: false,
      });
      return rider;
    } catch (err: any) {
      this.setState({ isLoading: false, error: err.message || 'Google login failed' });
      throw err;
    }
  },

  async loginWithApple() {
    try {
      this.setState({ isLoading: true, error: null });
      const { tokens, rider } = await AuthApi.loginWithApple();
      this.setState({
        isAuthenticated: true,
        rider,
        tokens,
        isLoading: false,
      });
      return rider;
    } catch (err: any) {
      this.setState({ isLoading: false, error: err.message || 'Apple login failed' });
      throw err;
    }
  },

  async verifyOtp(phone: string, otp: string) {
    try {
      this.setState({ isLoading: true, error: null });
      const { tokens, rider } = await AuthApi.verifyOtp(phone, otp);
      this.setState({
        isAuthenticated: true,
        rider,
        tokens,
        isLoading: false,
      });
      return rider;
    } catch (err: any) {
      this.setState({ isLoading: false, error: err.message || 'OTP verification failed' });
      throw err;
    }
  },

  async register(data: any) {
    try {
      this.setState({ isLoading: true, error: null });
      const { rider, tokens } = await AuthApi.registerRider(data);
      this.setState({
        isAuthenticated: true,
        rider,
        tokens,
        isLoading: false,
      });
      return rider;
    } catch (err: any) {
      this.setState({ isLoading: false, error: err.message || 'Registration failed' });
      throw err;
    }
  },

  async setAccountStatusOverride(status: RiderAccountStatus) {
    await SecureStorage.setItem('dev_override_status', status);
    if (globalAuthState.rider) {
      const updated = {
        ...globalAuthState.rider,
        accountStatus: status,
        isDocumentsVerified: status === 'ACTIVE',
      };
      this.setState({ rider: updated });
    }
  },

  async completeOnboarding() {
    await SecureStorage.setItem('onboarding_completed', 'true');
    this.setState({ hasCompletedOnboarding: true });
  },

  async logout() {
    await AuthApi.logout();
    await SecureStorage.removeItem('dev_override_status');
    this.setState({
      isAuthenticated: false,
      rider: null,
      tokens: null,
      currentAuthScreen: 'welcome',
      error: null,
    });
  },
};

export function useAuth() {
  const [state, setState] = useState<AuthState>(AuthStore.getState());

  useEffect(() => {
    listeners.add(setState);
    return () => {
      listeners.delete(setState);
    };
  }, []);

  return {
    ...state,
    setAuthScreen: AuthStore.setAuthScreen.bind(AuthStore),
    setPhoneForOtp: AuthStore.setPhoneForOtp.bind(AuthStore),
    login: AuthStore.login.bind(AuthStore),
    loginWithGoogle: AuthStore.loginWithGoogle.bind(AuthStore),
    loginWithApple: AuthStore.loginWithApple.bind(AuthStore),
    verifyOtp: AuthStore.verifyOtp.bind(AuthStore),
    register: AuthStore.register.bind(AuthStore),
    setAccountStatusOverride: AuthStore.setAccountStatusOverride.bind(AuthStore),
    completeOnboarding: AuthStore.completeOnboarding.bind(AuthStore),
    logout: AuthStore.logout.bind(AuthStore),
  };
}
