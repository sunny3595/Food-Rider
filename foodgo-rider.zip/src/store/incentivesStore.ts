import { useState, useEffect } from 'react';
import {
  RiderTierLevel,
  RiderTierInfo,
  AchievementBadge,
  DailyMilestoneTier,
  PeakSurgeWindow,
  LeaderboardEntry,
} from '../types/gamification.types';

interface IncentivesState {
  currentTier: RiderTierInfo;
  dailyMilestones: DailyMilestoneTier[];
  todayCompletedCount: number;
  peakSurges: PeakSurgeWindow[];
  weekendMarathon: {
    current: number;
    target: number;
    rewardAmount: number;
  };
  monthlyMilestone: {
    current: number;
    target: number;
    rewardAmount: number;
  };
  badges: AchievementBadge[];
  hubLeaderboard: LeaderboardEntry[];
  eligibility: {
    acceptanceRate: number;
    completionRate: number;
    isEligible: boolean;
  };
  rainSurgeEnabled: boolean;
}

const TIER_CONFIG: Record<RiderTierLevel, RiderTierInfo> = {
  BRONZE: {
    level: 'BRONZE',
    title: 'Bronze Partner',
    minDeliveries: 0,
    minRating: 4.5,
    minAcceptanceRate: 75,
    badgeColor: '#CD7F32',
    perks: ['Standard order dispatch', 'Next-day automated bank settlement'],
  },
  SILVER: {
    level: 'SILVER',
    title: 'Silver Partner',
    minDeliveries: 50,
    minRating: 4.6,
    minAcceptanceRate: 80,
    badgeColor: '#C0C0C0',
    perks: ['Eligible for daily surge bonuses', 'Priority phone support callback'],
  },
  GOLD: {
    level: 'GOLD',
    title: 'Gold Partner',
    minDeliveries: 200,
    minRating: 4.7,
    minAcceptanceRate: 85,
    badgeColor: '#FFD700',
    perks: ['Discounted instant withdrawal fees', 'Weekly milestone cash prizes', 'Free raincoat & helmet kit'],
  },
  PLATINUM: {
    level: 'PLATINUM',
    title: 'Platinum Elite Partner',
    minDeliveries: 500,
    minRating: 4.8,
    minAcceptanceRate: 90,
    badgeColor: '#E5E4E2',
    perks: [
      'Priority matching on high-ticket orders',
      'Instant 30-sec bank withdrawals at ₹0 fee',
      'Dedicated partner relationship manager',
      'Exclusive weekend cash marathon access',
    ],
  },
  DIAMOND: {
    level: 'DIAMOND',
    title: 'Diamond Legend Partner',
    minDeliveries: 1000,
    minRating: 4.9,
    minAcceptanceRate: 95,
    badgeColor: '#B9F2FF',
    perks: [
      'Maximum algorithmic dispatch priority',
      'Zero commission on all customer tips',
      'Full comprehensive accident insurance',
      'VIP annual rewards gala ticket',
    ],
  },
};

const INITIAL_BADGES: AchievementBadge[] = [
  {
    id: 'badge_first',
    name: 'First Mile Hero',
    description: 'Successfully completed your very first delivery on FoodGo.',
    iconName: 'PackageCheck',
    category: 'MILESTONE',
    isUnlocked: true,
    unlockedAt: '12 Jan 2026',
    progressCurrent: 1,
    progressTarget: 1,
  },
  {
    id: 'badge_century',
    name: 'Century Club',
    description: 'Completed 100 verified customer deliveries.',
    iconName: 'Award',
    category: 'MILESTONE',
    isUnlocked: true,
    unlockedAt: '18 Feb 2026',
    progressCurrent: 100,
    progressTarget: 100,
  },
  {
    id: 'badge_fivestar',
    name: 'Five Star Champion',
    description: 'Maintained 20 consecutive 5-star customer ratings.',
    iconName: 'Star',
    category: 'QUALITY',
    isUnlocked: true,
    unlockedAt: '02 Mar 2026',
    progressCurrent: 20,
    progressTarget: 20,
  },
  {
    id: 'badge_speed',
    name: 'Speed Demon',
    description: '50 on-time arrivals at restaurant and customer.',
    iconName: 'Zap',
    category: 'SPEED',
    isUnlocked: true,
    unlockedAt: '15 Mar 2026',
    progressCurrent: 50,
    progressTarget: 50,
  },
  {
    id: 'badge_rain',
    name: 'Monsoon Warrior',
    description: 'Complete 10 deliveries during monsoon rain surges.',
    iconName: 'CloudRain',
    category: 'WEATHER',
    isUnlocked: false,
    progressCurrent: 7,
    progressTarget: 10,
  },
  {
    id: 'badge_night',
    name: 'Night Owl Rider',
    description: 'Complete 25 deliveries between 11 PM and 3 AM.',
    iconName: 'Moon',
    category: 'NIGHT',
    isUnlocked: false,
    progressCurrent: 18,
    progressTarget: 25,
  },
  {
    id: 'badge_zerocancel',
    name: 'Zero Cancel Legend',
    description: '100 completed trips without a single partner cancellation.',
    iconName: 'ShieldCheck',
    category: 'QUALITY',
    isUnlocked: true,
    unlockedAt: '28 Sep 2026',
    progressCurrent: 100,
    progressTarget: 100,
  },
];

const INITIAL_LEADERBOARD: LeaderboardEntry[] = [
  { rank: 1, riderName: 'Ramesh Gowda', riderCode: 'RD-1002', deliveriesCount: 94, rating: 4.96, cashPrize: 3000, isCurrentUser: false },
  { rank: 2, riderName: 'Sunil Kumar', riderCode: 'RD-1044', deliveriesCount: 88, rating: 4.94, cashPrize: 2000, isCurrentUser: false },
  { rank: 3, riderName: 'Imran Khan', riderCode: 'RD-1089', deliveriesCount: 82, rating: 4.92, cashPrize: 1000, isCurrentUser: false },
  { rank: 4, riderName: 'Pradeep Shenoy', riderCode: 'RD-1120', deliveriesCount: 76, rating: 4.90, cashPrize: 500, isCurrentUser: false },
  { rank: 5, riderName: 'Vijay Varma', riderCode: 'RD-1134', deliveriesCount: 73, rating: 4.89, cashPrize: 500, isCurrentUser: false },
  { rank: 6, riderName: 'Anil Deshmukh', riderCode: 'RD-1142', deliveriesCount: 70, rating: 4.89, cashPrize: 500, isCurrentUser: false },
  { rank: 7, riderName: 'Dhanush S (You)', riderCode: 'RD-1024', deliveriesCount: 68, rating: 4.88, cashPrize: 500, isCurrentUser: true },
  { rank: 8, riderName: 'Manoj Patel', riderCode: 'RD-1188', deliveriesCount: 65, rating: 4.86, cashPrize: 500, isCurrentUser: false },
  { rank: 9, riderName: 'Chethan Prasad', riderCode: 'RD-1201', deliveriesCount: 61, rating: 4.85, cashPrize: 500, isCurrentUser: false },
  { rank: 10, riderName: 'Girish Murthy', riderCode: 'RD-1215', deliveriesCount: 58, rating: 4.84, cashPrize: 500, isCurrentUser: false },
];

let globalIncentivesState: IncentivesState = {
  currentTier: TIER_CONFIG.PLATINUM,
  dailyMilestones: [
    { tierNumber: 1, targetDeliveries: 8, bonusAmount: 100, status: 'ACHIEVED' },
    { tierNumber: 2, targetDeliveries: 12, bonusAmount: 200, status: 'IN_PROGRESS' },
    { tierNumber: 3, targetDeliveries: 16, bonusAmount: 350, status: 'LOCKED' },
  ],
  todayCompletedCount: 11,
  peakSurges: [
    { id: 'surge_lunch', title: 'Lunch Rush Surge', timeSlot: '12:00 PM - 03:00 PM', bonusPerOrder: 20, isActive: false },
    { id: 'surge_dinner', title: 'Dinner Peak Rush', timeSlot: '07:00 PM - 11:00 PM', bonusPerOrder: 25, isActive: true, endsInMinutes: 42 },
    { id: 'surge_night', title: 'Late Night Shift', timeSlot: '11:00 PM - 03:00 AM', bonusPerOrder: 35, isActive: false },
    { id: 'surge_rain', title: 'Monsoon Rain Surge', timeSlot: 'Active During Rainfall', bonusPerOrder: 30, isActive: false },
  ],
  weekendMarathon: {
    current: 28,
    target: 40,
    rewardAmount: 1200,
  },
  monthlyMilestone: {
    current: 248,
    target: 300,
    rewardAmount: 5000,
  },
  badges: INITIAL_BADGES,
  hubLeaderboard: INITIAL_LEADERBOARD,
  eligibility: {
    acceptanceRate: 94,
    completionRate: 98,
    isEligible: true,
  },
  rainSurgeEnabled: false,
};

const listeners = new Set<(state: IncentivesState) => void>();

function notify() {
  listeners.forEach((listener) => listener(globalIncentivesState));
}

export const IncentivesStore = {
  getState() {
    return globalIncentivesState;
  },

  setState(partial: Partial<IncentivesState>) {
    globalIncentivesState = { ...globalIncentivesState, ...partial };
    notify();
  },

  toggleRainSurge() {
    const nextState = !globalIncentivesState.rainSurgeEnabled;
    const updatedSurges = globalIncentivesState.peakSurges.map((s) => {
      if (s.id === 'surge_rain') return { ...s, isActive: nextState };
      return s;
    });

    this.setState({
      rainSurgeEnabled: nextState,
      peakSurges: updatedSurges,
    });
  },

  incrementCompletedDelivery() {
    const nextCount = globalIncentivesState.todayCompletedCount + 1;
    const updatedMilestones: DailyMilestoneTier[] = globalIncentivesState.dailyMilestones.map((m) => {
      if (nextCount >= m.targetDeliveries) {
        return { ...m, status: 'ACHIEVED' };
      }
      if (nextCount >= m.targetDeliveries - 4) {
        return { ...m, status: 'IN_PROGRESS' };
      }
      return m;
    });

    this.setState({
      todayCompletedCount: nextCount,
      dailyMilestones: updatedMilestones,
      weekendMarathon: {
        ...globalIncentivesState.weekendMarathon,
        current: globalIncentivesState.weekendMarathon.current + 1,
      },
    });
  },
};

export function useIncentives() {
  const [state, setState] = useState<IncentivesState>(IncentivesStore.getState());

  useEffect(() => {
    listeners.add(setState);
    return () => {
      listeners.delete(setState);
    };
  }, []);

  return {
    ...state,
    toggleRainSurge: IncentivesStore.toggleRainSurge.bind(IncentivesStore),
    incrementCompletedDelivery: IncentivesStore.incrementCompletedDelivery.bind(IncentivesStore),
  };
}
