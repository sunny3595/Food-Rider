import { useState, useEffect } from 'react';
import {
  LedgerTransaction,
  PayoutDestination,
  PayoutSpeed,
  WithdrawalReceipt,
  FloatingCashLimit,
} from '../types/wallet.types';

interface WalletState {
  availableBalance: number;
  floatingCash: FloatingCashLimit;
  transactions: LedgerTransaction[];
  isProcessing: boolean;
  error: string | null;
  lastReceipt: WithdrawalReceipt | null;
}

const INITIAL_TRANSACTIONS: LedgerTransaction[] = [
  {
    id: 'tx_01',
    referenceId: 'TXN_20261005_9841',
    timestamp: 'Today, 02:45 PM',
    type: 'CREDIT',
    category: 'DELIVERY_PAY',
    amount: 98,
    title: 'Trip Pay: Burger King',
    description: 'Order #FG-10245 (Base ₹40 + Dist ₹28 + Surge ₹15 + Tip ₹15)',
    orderNumber: '#FG-10245',
    bankUtr: 'UTR98321049281',
    status: 'SUCCESS',
  },
  {
    id: 'tx_02',
    referenceId: 'TXN_20261005_8712',
    timestamp: 'Today, 01:10 PM',
    type: 'CREDIT',
    category: 'CUSTOMER_TIP',
    amount: 50,
    title: 'Customer Tip Received',
    description: '100% direct tip credited for exceptional fast delivery',
    orderNumber: '#FG-10238',
    status: 'SUCCESS',
  },
  {
    id: 'tx_03',
    referenceId: 'TXN_20261005_7109',
    timestamp: 'Today, 12:20 PM',
    type: 'CREDIT',
    category: 'WAIT_COMPENSATION',
    amount: 25,
    title: 'Kitchen Wait Compensation',
    description: 'Automatic wait pay credited (>10 mins at restaurant counter)',
    orderNumber: '#FG-10231',
    status: 'SUCCESS',
  },
  {
    id: 'tx_04',
    referenceId: 'TXN_20261004_4192',
    timestamp: 'Yesterday, 06:15 PM',
    type: 'DEBIT',
    category: 'INSTANT_WITHDRAWAL',
    amount: 1500,
    title: 'Instant Payout to HDFC Bank',
    description: 'Transferred to A/C ••••4821 via IMPS/UPI (Fee ₹5)',
    bankUtr: 'UTR81923019284',
    status: 'SUCCESS',
  },
  {
    id: 'tx_05',
    referenceId: 'TXN_20261004_1120',
    timestamp: 'Yesterday, 02:30 PM',
    type: 'CREDIT',
    category: 'INCENTIVE_BONUS',
    amount: 200,
    title: 'Daily 12-Orders Milestone Achieved',
    description: 'Performance incentive bonus achieved for completed shift',
    status: 'SUCCESS',
  },
  {
    id: 'tx_06',
    referenceId: 'TXN_20261003_6502',
    timestamp: '03 Oct, 09:00 PM',
    type: 'DEBIT',
    category: 'COD_DEDUCTION',
    amount: 640,
    title: 'Cash on Delivery Settlement',
    description: 'Customer cash collected adjusted against wallet balance',
    orderNumber: '#FG-10190',
    status: 'SUCCESS',
  },
];

let globalWalletState: WalletState = {
  availableBalance: 4280,
  floatingCash: {
    currentCashInHand: 1280,
    maxLimit: 2500,
    isLimitExceeded: false,
    remainingAllowance: 1220,
  },
  transactions: INITIAL_TRANSACTIONS,
  isProcessing: false,
  error: null,
  lastReceipt: null,
};

const listeners = new Set<(state: WalletState) => void>();

function notify() {
  listeners.forEach((listener) => listener(globalWalletState));
}

export const WalletStore = {
  getState() {
    return globalWalletState;
  },

  setState(partial: Partial<WalletState>) {
    globalWalletState = { ...globalWalletState, ...partial };
    notify();
  },

  async requestWithdrawal(
    amount: number,
    destination: PayoutDestination,
    speed: PayoutSpeed,
    destinationLabel: string
  ): Promise<WithdrawalReceipt> {
    const fee = speed === 'INSTANT_UPI' ? 5 : 0;
    const totalDeduction = amount + fee;

    if (amount < 100) {
      throw new Error('Minimum withdrawal amount is ₹100');
    }
    if (amount > 10000) {
      throw new Error('Maximum daily withdrawal limit is ₹10,000');
    }
    if (totalDeduction > globalWalletState.availableBalance) {
      throw new Error(`Insufficient wallet balance. Total needed: ₹${totalDeduction}`);
    }

    this.setState({ isProcessing: true, error: null });

    // Simulate bank transfer latency
    await new Promise((resolve) => setTimeout(resolve, 1000));

    const referenceUtr = `UTR${Date.now().toString().slice(-9)}`;
    const newTx: LedgerTransaction = {
      id: `tx_${Date.now()}`,
      referenceId: `TXN_${Date.now().toString().slice(-8)}`,
      timestamp: 'Just now',
      type: 'DEBIT',
      category: 'INSTANT_WITHDRAWAL',
      amount: totalDeduction,
      title: `${speed === 'INSTANT_UPI' ? 'Instant' : 'Standard'} Payout to ${destinationLabel}`,
      description: `Transferred to ${destinationLabel} (Net: ₹${amount}, Fee: ₹${fee})`,
      bankUtr: referenceUtr,
      status: 'SUCCESS',
    };

    const receipt: WithdrawalReceipt = {
      transactionId: newTx.referenceId,
      referenceUtr,
      amountRequested: amount,
      fee,
      netTransferred: amount,
      destinationMasked: destinationLabel,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      status: 'SUCCESS',
    };

    this.setState({
      availableBalance: globalWalletState.availableBalance - totalDeduction,
      transactions: [newTx, ...globalWalletState.transactions],
      isProcessing: false,
      lastReceipt: receipt,
    });

    return receipt;
  },

  async settleFloatingCash(depositAmount: number) {
    this.setState({ isProcessing: true });
    await new Promise((resolve) => setTimeout(resolve, 800));

    const newCash = Math.max(0, globalWalletState.floatingCash.currentCashInHand - depositAmount);
    const newAllowance = globalWalletState.floatingCash.maxLimit - newCash;

    const newTx: LedgerTransaction = {
      id: `tx_${Date.now()}`,
      referenceId: `TXN_${Date.now().toString().slice(-8)}`,
      timestamp: 'Just now',
      type: 'CREDIT',
      category: 'BANK_SETTLEMENT',
      amount: depositAmount,
      title: 'Floating COD Cash Deposited via UPI',
      description: `Settled ₹${depositAmount} cash in hand through partner UPI gateway`,
      bankUtr: `UTR${Date.now().toString().slice(-8)}`,
      status: 'SUCCESS',
    };

    this.setState({
      floatingCash: {
        currentCashInHand: newCash,
        maxLimit: 2500,
        isLimitExceeded: false,
        remainingAllowance: newAllowance,
      },
      transactions: [newTx, ...globalWalletState.transactions],
      isProcessing: false,
    });
  },

  addDeliveryEarnings(amount: number, orderNumber: string) {
    const newTx: LedgerTransaction = {
      id: `tx_${Date.now()}`,
      referenceId: `TXN_${Date.now().toString().slice(-8)}`,
      timestamp: 'Just now',
      type: 'CREDIT',
      category: 'DELIVERY_PAY',
      amount,
      title: `Trip Pay: ${orderNumber}`,
      description: `Delivery trip earnings credited directly to wallet`,
      orderNumber,
      status: 'SUCCESS',
    };

    this.setState({
      availableBalance: globalWalletState.availableBalance + amount,
      transactions: [newTx, ...globalWalletState.transactions],
    });
  },
};

export function useWallet() {
  const [state, setState] = useState<WalletState>(WalletStore.getState());

  useEffect(() => {
    listeners.add(setState);
    return () => {
      listeners.delete(setState);
    };
  }, []);

  return {
    ...state,
    requestWithdrawal: WalletStore.requestWithdrawal.bind(WalletStore),
    settleFloatingCash: WalletStore.settleFloatingCash.bind(WalletStore),
    addDeliveryEarnings: WalletStore.addDeliveryEarnings.bind(WalletStore),
  };
}
