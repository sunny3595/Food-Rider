import { useState, useEffect } from 'react';

export type NetworkStatus = 'CONNECTED' | 'RECONNECTING' | 'OFFLINE';

interface ConnectionState {
  status: NetworkStatus;
  isOnline: boolean;
  latencyMs: number;
  lastSyncAt: number;
}

let globalConnectionState: ConnectionState = {
  status: 'CONNECTED',
  isOnline: true,
  latencyMs: 38,
  lastSyncAt: Date.now(),
};

const listeners = new Set<(state: ConnectionState) => void>();

function notify() {
  listeners.forEach((listener) => listener(globalConnectionState));
}

export const ConnectionStore = {
  getState() {
    return globalConnectionState;
  },

  setStatus(status: NetworkStatus) {
    globalConnectionState.status = status;
    globalConnectionState.isOnline = status === 'CONNECTED';
    if (status === 'CONNECTED') {
      globalConnectionState.lastSyncAt = Date.now();
    }
    notify();
  },

  setLatency(ms: number) {
    globalConnectionState.latencyMs = ms;
    notify();
  },

  simulateOfflineToggle() {
    const next = globalConnectionState.status === 'CONNECTED' ? 'OFFLINE' : 'CONNECTED';
    this.setStatus(next);
  },
};

if (typeof window !== 'undefined') {
  window.addEventListener('online', () => ConnectionStore.setStatus('CONNECTED'));
  window.addEventListener('offline', () => ConnectionStore.setStatus('OFFLINE'));
}

export function useConnection() {
  const [state, setState] = useState<ConnectionState>(ConnectionStore.getState());

  useEffect(() => {
    listeners.add(setState);
    return () => {
      listeners.delete(setState);
    };
  }, []);

  return {
    ...state,
    simulateOfflineToggle: ConnectionStore.simulateOfflineToggle.bind(ConnectionStore),
  };
}
