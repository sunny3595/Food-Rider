import { APP_CONFIG } from '../constants/config';

/**
 * Format monetary amounts according to configured currency (Default ₹ INR).
 * Never hardcode the currency symbol directly in UI.
 */
export function formatCurrency(amount: number | undefined | null): string {
  if (amount === undefined || amount === null || isNaN(amount)) {
    return `${APP_CONFIG.localization.currencySymbol}0`;
  }
  const formatted = new Intl.NumberFormat(APP_CONFIG.localization.defaultLocale, {
    maximumFractionDigits: 0,
    minimumFractionDigits: 0,
  }).format(amount);

  return `${APP_CONFIG.localization.currencySymbol}${formatted}`;
}

/**
 * Formats distance with unit (e.g. 2.4 km or 450 m).
 */
export function formatDistance(distanceKm: number): string {
  if (!distanceKm || distanceKm <= 0) return '0 m';
  if (distanceKm < 1) {
    return `${Math.round(distanceKm * 1000)} m`;
  }
  return `${distanceKm.toFixed(1)} km`;
}

/**
 * Formats duration in minutes into a readable string (e.g. 18 mins).
 */
export function formatDuration(minutes: number): string {
  if (minutes < 1) return 'Under 1 min';
  if (minutes >= 60) {
    const hrs = Math.floor(minutes / 60);
    const remainingMins = Math.round(minutes % 60);
    return `${hrs}h ${remainingMins}m`;
  }
  return `${Math.round(minutes)} mins`;
}

/**
 * Formats standard ISO timestamp into short 12-hour time (e.g. "08:45 PM").
 */
export function formatTime(timestampOrIso: string | number | Date): string {
  try {
    const date = new Date(timestampOrIso);
    return date.toLocaleTimeString('en-IN', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  } catch {
    return '--:--';
  }
}

/**
 * Formats standard ISO timestamp into readable date (e.g. "05 Oct 2026").
 */
export function formatDate(timestampOrIso: string | number | Date): string {
  try {
    const date = new Date(timestampOrIso);
    return date.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return '---';
  }
}

/**
 * Mask sensitive customer or account numbers.
 */
export function maskSensitive(text: string, visibleEndCount = 4): string {
  if (!text) return '';
  if (text.length <= visibleEndCount) return text;
  const maskedSection = '•'.repeat(text.length - visibleEndCount);
  return `${maskedSection}${text.slice(-visibleEndCount)}`;
}
