/**
 * Secure token and preference storage abstraction.
 * In a native Expo environment, this bridges to `expo-secure-store`.
 * In browser/preview runtimes, this uses isolated sessionStorage/localStorage with key prefixes.
 */

const STORAGE_PREFIX = '@foodgo_rider_';

export const SecureStorage = {
  async setItem(key: string, value: string): Promise<void> {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(`${STORAGE_PREFIX}${key}`, value);
      }
    } catch (e) {
      console.warn('Storage setItem failed:', e);
    }
  },

  async getItem(key: string): Promise<string | null> {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        return window.localStorage.getItem(`${STORAGE_PREFIX}${key}`);
      }
      return null;
    } catch (e) {
      console.warn('Storage getItem failed:', e);
      return null;
    }
  },

  async removeItem(key: string): Promise<void> {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.removeItem(`${STORAGE_PREFIX}${key}`);
      }
    } catch (e) {
      console.warn('Storage removeItem failed:', e);
    }
  },

  async clearTokens(): Promise<void> {
    await this.removeItem('access_token');
    await this.removeItem('refresh_token');
    await this.removeItem('rider_id');
  },
};
