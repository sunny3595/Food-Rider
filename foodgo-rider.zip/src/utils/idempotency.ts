/**
 * Generates client-side idempotency keys to protect critical rider operations
 * (e.g. Accept Delivery, Pickup Verification, Complete Delivery, Cash Collected, Payouts)
 * from accidental double clicks or network retry duplicates.
 */

export function generateIdempotencyKey(actionName: string, entityId?: string): string {
  const timestamp = Date.now();
  const randomPart = Math.random().toString(36).substring(2, 10);
  const targetId = entityId ? `_${entityId}` : '';
  return `idemp_${actionName}${targetId}_${timestamp}_${randomPart}`;
}

const inFlightOperations = new Set<string>();

/**
 * Executes an asynchronous action with mutex protection to prevent duplicate rapid requests.
 */
export async function withDoubleSubmissionGuard<T>(
  operationKey: string,
  asyncFn: () => Promise<T>
): Promise<T> {
  if (inFlightOperations.has(operationKey)) {
    throw new Error('This action is already processing. Please wait.');
  }

  inFlightOperations.add(operationKey);
  try {
    return await asyncFn();
  } finally {
    setTimeout(() => {
      inFlightOperations.delete(operationKey);
    }, 400); // 400ms debounce guard
  }
}
