import React, { useState } from 'react';
import {
  Navigation,
  Clock,
  MapPin,
  IndianRupee,
  Shield,
  Banknote,
  Smile,
  PackageCheck,
  ArrowRight,
  ArrowLeft,
  Check,
  Sparkles,
  X,
} from 'lucide-react';
import { useAuth } from '../../store/authStore';

interface OnboardingScreenProps {
  onFinish?: () => void;
  isModalView?: boolean;
}

export const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ onFinish, isModalView }) => {
  const { completeOnboarding } = useAuth();
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      title: 'How Deliveries Work',
      subtitle: 'The Complete Partner Journey',
      description:
        'When you go online, our intelligent dispatch algorithm matches you with orders from top restaurants near you. Simply accept the request, pick up the hot food, and navigate to the customer.',
      icon: <PackageCheck size={36} className="text-[#FF5200]" />,
      accentBg: 'bg-orange-500/10 border-orange-500/30',
      badge: 'Step 1 of 8',
      tips: ['Stay in high demand clusters for more orders', 'Keep your duty switch online to stay matched'],
    },
    {
      title: 'Accepting Delivery Requests',
      subtitle: 'Review & Decide Fast',
      description:
        'Each request shows estimated earnings, restaurant distance, customer location, and total trip distance. You have a 25-second countdown timer to accept or decline without penalty.',
      icon: <Clock size={36} className="text-amber-400" />,
      accentBg: 'bg-amber-500/10 border-amber-500/30',
      badge: 'Step 2 of 8',
      tips: ['Check if the order is Cash on Delivery (COD)', 'Orders automatically reassign after timer expires'],
    },
    {
      title: 'Turn-by-Turn Navigation',
      subtitle: 'Built-in GPS & Deep Links',
      description:
        'FoodGo Rider integrates direct Google Maps & Apple Maps routing. Tap "MAP" on any order to instantly open turn-by-turn navigation with real-time traffic avoidance.',
      icon: <Navigation size={36} className="text-sky-400" />,
      accentBg: 'bg-sky-500/10 border-sky-500/30',
      badge: 'Step 3 of 8',
      tips: ['Rider location updates every 5-15s during active delivery', 'Audio directions keep your eyes on the road'],
    },
    {
      title: 'Transparent Earnings & Payouts',
      subtitle: 'Earn Base Pay + Distance + Tips',
      description:
        'Every order includes base pay, per-kilometre fuel pay, peak hour surge, and 100% of customer tips. Request instant bank transfers or UPI payouts straight to your account.',
      icon: <IndianRupee size={36} className="text-emerald-400" />,
      accentBg: 'bg-emerald-500/10 border-emerald-500/30',
      badge: 'Step 4 of 8',
      tips: ['Instant UPI payouts clear in under 2 minutes', 'Dinner peak hours (7-11 PM) offer extra bonus surges'],
    },
    {
      title: 'Road Safety & Emergency SOS',
      subtitle: 'Your Life is Priority #1',
      description:
        'Always wear an ISI-certified helmet and secure your phone mount. In case of any roadside incident or hazard, tap the red SOS button to instantly alert our 24/7 Safety Command and dial 112.',
      icon: <Shield size={36} className="text-rose-500" />,
      accentBg: 'bg-rose-500/10 border-rose-500/30',
      badge: 'Step 5 of 8',
      tips: ['₹5 Lakh accidental medical insurance provided', 'Never speed or break signals to meet estimated times'],
    },
    {
      title: 'Cash on Delivery Handling',
      subtitle: 'Accurate COD Collection',
      description:
        'For COD orders, collect the exact invoice amount displayed on the app. Cash collected is securely credited against your platform balance and settled automatically during weekly payouts.',
      icon: <Banknote size={36} className="text-amber-300" />,
      accentBg: 'bg-amber-400/10 border-amber-400/30',
      badge: 'Step 6 of 8',
      tips: ['Carry sufficient loose change (₹10, ₹20, ₹50)', 'Never accept less than the stated invoice amount'],
    },
    {
      title: 'Customer Interaction & Privacy',
      subtitle: 'Professional 5-Star Service',
      description:
        'Greet customers with a smile and handle food bags with care. All phone calls are privacy-masked through our proxy gateway to safeguard both your personal number and the customer’s.',
      icon: <Smile size={36} className="text-indigo-400" />,
      accentBg: 'bg-indigo-500/10 border-indigo-500/30',
      badge: 'Step 7 of 8',
      tips: ['Use built-in quick chat for doorstep updates', 'Verify customer OTP before completing handover'],
    },
    {
      title: 'Thermal Bag & Hygiene',
      subtitle: 'Keep Hot Food Hot & Cold Drinks Cold',
      description:
        'Always keep food packages upright inside the FoodGo insulated bag. Separate hot items from cold drinks, keep zip fully closed during transit, and sanitize your bag daily.',
      icon: <Sparkles size={36} className="text-emerald-400" />,
      accentBg: 'bg-emerald-500/10 border-emerald-500/30',
      badge: 'Step 8 of 8',
      tips: ['Check all spill-proof containers at restaurant counter', 'Maintain 4.8+ rating for priority Platinum orders'],
    },
  ];

  const current = slides[currentSlide];
  const isLast = currentSlide === slides.length - 1;

  const handleFinish = async () => {
    await completeOnboarding();
    if (onFinish) onFinish();
  };

  const handleNext = () => {
    if (isLast) {
      handleFinish();
    } else {
      setCurrentSlide((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentSlide > 0) {
      setCurrentSlide((prev) => prev - 1);
    }
  };

  return (
    <div className="flex-1 flex flex-col justify-between p-5 bg-slate-950 overflow-y-auto">
      {/* Header bar */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-2">
          {currentSlide > 0 && (
            <button
              onClick={handlePrev}
              className="p-1 rounded-lg text-slate-400 hover:text-white"
            >
              <ArrowLeft size={16} />
            </button>
          )}
          <span className="text-xs font-mono font-bold text-orange-400">
            {current.badge}
          </span>
        </div>

        {isModalView ? (
          <button
            onClick={onFinish}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white"
          >
            <X size={18} />
          </button>
        ) : (
          <button
            onClick={handleFinish}
            className="text-xs text-slate-400 hover:text-white font-medium"
          >
            Skip Guide
          </button>
        )}
      </div>

      {/* Slide Body */}
      <div className="my-auto py-4 max-w-sm w-full mx-auto space-y-5 text-center">
        {/* Slide Illustrated Icon */}
        <div className="relative w-24 h-24 mx-auto">
          <div className="absolute inset-0 bg-[#FF5200]/20 rounded-full blur-xl animate-pulse" />
          <div
            className={`relative w-full h-full rounded-3xl border-2 flex items-center justify-center shadow-2xl transition-all duration-300 ${current.accentBg}`}
          >
            {current.icon}
          </div>
        </div>

        <div className="space-y-1.5">
          <h2 className="text-xl font-black text-white tracking-tight leading-snug">
            {current.title}
          </h2>
          <span className="text-xs font-semibold text-orange-400 block">
            {current.subtitle}
          </span>
          <p className="text-xs text-slate-300 leading-relaxed max-w-xs mx-auto pt-1">
            {current.description}
          </p>
        </div>

        {/* Operational Pro Tips Box */}
        <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 text-left space-y-2 shadow-lg">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1">
            <Sparkles size={11} className="text-amber-400" />
            <span>Best Practice Pro Tips</span>
          </span>
          <ul className="space-y-1.5 text-xs text-slate-300">
            {current.tips.map((tip, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <Check size={13} className="text-emerald-400 shrink-0 mt-0.5" />
                <span className="leading-tight">{tip}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Bottom Navigation & Indicator Dots */}
      <div className="space-y-4 pt-2">
        {/* Dots */}
        <div className="flex justify-center items-center gap-1.5">
          {slides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentSlide(idx)}
              className={`h-1.5 rounded-full transition-all duration-200 ${
                idx === currentSlide ? 'w-6 bg-[#FF5200]' : 'w-2 bg-slate-800 hover:bg-slate-700'
              }`}
            />
          ))}
        </div>

        {/* Next / Finish Button */}
        <button
          onClick={handleNext}
          className="w-full py-3.5 px-4 bg-gradient-to-r from-[#FF5200] to-orange-600 hover:brightness-110 text-white rounded-2xl font-bold text-xs flex items-center justify-center gap-2 shadow-xl shadow-orange-950/50 transition active:scale-98"
        >
          <span>{isLast ? 'START DELIVERING NOW' : 'NEXT GUIDELINE'}</span>
          <ArrowRight size={15} />
        </button>
      </div>
    </div>
  );
};
