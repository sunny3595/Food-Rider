import React, { useState } from 'react';
import {
  CheckCircle2,
  IndianRupee,
  Star,
  Clock,
  Navigation,
  ThumbsUp,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { DeliveryOrder } from '../../types/delivery.types';
import { formatCurrency, formatDistance } from '../../utils/formatters';

interface OrderCompletionSummaryModalProps {
  order: DeliveryOrder;
  onFinishAndFindNext: () => void;
}

export const OrderCompletionSummaryModal: React.FC<OrderCompletionSummaryModalProps> = ({
  order,
  onFinishAndFindNext,
}) => {
  const [restaurantRating, setRestaurantRating] = useState(5);
  const [customerRating, setCustomerRating] = useState(5);

  const fin = order.financials;

  return (
    <div className="fixed inset-0 bg-slate-950 z-60 flex flex-col justify-between p-5 overflow-y-auto animate-fadeIn">
      {/* Top Celebration Emblem */}
      <div className="text-center pt-4 space-y-2">
        <div className="relative w-20 h-20 mx-auto">
          <div className="absolute inset-0 bg-emerald-500/20 rounded-full blur-xl animate-pulse" />
          <div className="relative w-full h-full rounded-3xl bg-emerald-500/10 border-2 border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-2xl">
            <CheckCircle2 size={40} />
          </div>
        </div>

        <div>
          <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-widest block">
            DELIVERY COMPLETED
          </span>
          <h2 className="text-xl font-black text-white tracking-tight">Great Job, Partner!</h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">{order.orderNumber}</p>
        </div>
      </div>

      {/* Main Earnings Breakdown Card */}
      <div className="max-w-sm w-full mx-auto space-y-3.5 my-auto py-3">
        <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/30 p-5 rounded-3xl border border-emerald-500/30 shadow-xl space-y-3">
          <div className="flex items-baseline justify-between border-b border-slate-800 pb-2">
            <div>
              <span className="text-[11px] text-slate-400 block font-medium">Earnings for this Trip</span>
              <span className="text-3xl font-black text-emerald-400 font-mono tracking-tight">
                {formatCurrency(fin.totalEarnings)}
              </span>
            </div>
            <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
              <Sparkles size={11} />
              <span>Credited to Wallet</span>
            </span>
          </div>

          {/* Granular Breakdown */}
          <div className="space-y-1.5 text-xs font-mono text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-400">Base Pickup Pay</span>
              <span>{formatCurrency(fin.basePay)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Distance Pay</span>
              <span>{formatCurrency(fin.distancePay)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Peak Surge Bonus</span>
              <span className="text-amber-400">+{formatCurrency(fin.peakHourBonus)}</span>
            </div>
            {fin.riderTip > 0 && (
              <div className="flex justify-between">
                <span className="text-slate-400">Customer Tip</span>
                <span className="text-emerald-400">+{formatCurrency(fin.riderTip)}</span>
              </div>
            )}
          </div>
        </div>

        {/* Operational Highlights */}
        <div className="grid grid-cols-2 gap-2.5">
          <div className="bg-slate-900 p-3 rounded-2xl border border-slate-800 text-center">
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Delivery Time</span>
            <span className="text-sm font-black text-white font-mono">22 mins</span>
            <span className="text-[10px] text-emerald-400 block font-medium">On-Time Arrival</span>
          </div>

          <div className="bg-slate-900 p-3 rounded-2xl border border-slate-800 text-center">
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Distance Covered</span>
            <span className="text-sm font-black text-white font-mono">
              {formatDistance(order.totalDistanceKm)}
            </span>
            <span className="text-[10px] text-slate-400 block">Fuel compensated</span>
          </div>
        </div>

        {/* Two-Way Rating Feedback */}
        <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 space-y-3">
          <span className="text-xs font-bold text-white uppercase tracking-wider block">
            Partner Feedback
          </span>

          {/* Rate Restaurant */}
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-300">Rate Restaurant Food Packing</span>
            <div className="flex gap-1 text-amber-400">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRestaurantRating(star)}
                  className="p-1 hover:scale-110 transition"
                >
                  <Star
                    size={16}
                    fill={star <= restaurantRating ? 'currentColor' : 'none'}
                    className={star <= restaurantRating ? 'text-amber-400' : 'text-slate-600'}
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Rate Customer */}
          <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800">
            <span className="text-slate-300">Rate Customer Interaction</span>
            <div className="flex gap-1 text-amber-400">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setCustomerRating(star)}
                  className="p-1 hover:scale-110 transition"
                >
                  <Star
                    size={16}
                    fill={star <= customerRating ? 'currentColor' : 'none'}
                    className={star <= customerRating ? 'text-amber-400' : 'text-slate-600'}
                  />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom CTA */}
      <div className="pt-2">
        <button
          onClick={onFinishAndFindNext}
          className="w-full py-4 bg-gradient-to-r from-[#FF5200] to-orange-600 hover:brightness-110 text-white rounded-2xl font-bold text-xs flex items-center justify-center gap-2 shadow-xl shadow-orange-950/50 transition active:scale-98"
        >
          <span>FIND NEXT DELIVERY ORDER</span>
          <ArrowRight size={16} />
        </button>
      </div>
    </div>
  );
};
