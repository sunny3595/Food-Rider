import React, { useState } from 'react';
import {
  User,
  Bike,
  FileCheck2,
  Globe2,
  Volume2,
  VolumeX,
  ShieldAlert,
  LogOut,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  Building,
  Award,
  BookOpen,
  Lock,
  Edit3,
  Sliders,
  Shield,
} from 'lucide-react';
import { useRider } from '../store/riderStore';
import { useTheme } from '../store/themeStore';
import { useAuth } from '../store/authStore';
import { SUPPORTED_LANGUAGES, SupportedLanguage } from '../constants/translations';
import { MOCK_DOCUMENTS } from '../api/mockData';
import { EmergencySosModal } from '../components/safety/EmergencySosModal';
import { HelmetCheckModal } from '../components/safety/HelmetCheckModal';
import { SettingsScreen } from './SettingsScreen';
import { EditProfileModal } from './profile/EditProfileModal';
import { VehicleManagementModal } from './profile/VehicleManagementModal';
import { DocumentManagementModal } from './profile/DocumentManagementModal';
import { PerformanceRatingModal } from './profile/PerformanceRatingModal';
import { BankDetailsModal } from './profile/BankDetailsModal';
import { PrivacySafetyModal } from './profile/PrivacySafetyModal';
import { OnboardingScreen } from './onboarding/OnboardingScreen';

export const ProfileScreen: React.FC = () => {
  const { profile } = useRider();
  const { language, setLanguage, soundEnabled, toggleSound, toggleSimulator } = useTheme();
  const { logout } = useAuth();

  // Modals state
  const [activeModal, setActiveModal] = useState<
    | 'edit-profile'
    | 'vehicle'
    | 'documents'
    | 'performance'
    | 'bank'
    | 'privacy'
    | 'guide'
    | 'sos'
    | 'settings'
    | 'helmet'
    | null
  >(null);

  return (
    <div className="flex-1 flex flex-col bg-slate-950 overflow-y-auto pb-10">
      {/* Top Header */}
      <div className="px-5 pt-4 pb-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
        <div>
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
            Account & Operations
          </span>
          <h1 className="text-base font-extrabold text-white">Partner Profile</h1>
        </div>

        <button
          onClick={() => setActiveModal('edit-profile')}
          className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold"
        >
          <Edit3 size={12} />
          <span>Edit</span>
        </button>
      </div>

      <div className="p-4 space-y-4">
        {/* Main Identity Hero Card */}
        <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-slate-850 p-4 rounded-3xl border border-slate-800 shadow-xl flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <div className="relative">
              <img
                src={profile.avatarUrl}
                alt={profile.fullName}
                className="w-16 h-16 rounded-2xl object-cover border-2 border-[#FF5200] shadow-md"
              />
              <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-slate-900 flex items-center justify-center">
                <CheckCircle2 size={10} className="text-white" />
              </span>
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-base font-extrabold text-white">{profile.fullName}</h3>
                <span className="bg-emerald-500/10 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
                  ACTIVE
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono mt-0.5">ID: {profile.riderCode}</p>
              <p className="text-xs text-slate-400">{profile.phone}</p>
            </div>
          </div>
        </div>

        {/* Quick Performance & Rating Ribbon */}
        <button
          onClick={() => setActiveModal('performance')}
          className="w-full bg-slate-900 hover:bg-slate-850 p-3.5 rounded-2xl border border-slate-800 text-left transition flex items-center justify-between group"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center">
              <Award size={20} />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-white group-hover:text-amber-400 transition">
                  Performance & Star Rating
                </span>
                <span className="text-[10px] font-bold bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded">
                  ★ {profile.performance.averageRating}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                {profile.performance.completionRate}% completion • {profile.performance.totalDeliveriesCompleted} deliveries
              </p>
            </div>
          </div>
          <ChevronRight size={16} className="text-slate-400 group-hover:text-white" />
        </button>

        {/* Core Profile Management Links */}
        <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden divide-y divide-slate-800/80">
          {/* Registered Vehicle */}
          <button
            onClick={() => setActiveModal('vehicle')}
            className="w-full p-3.5 hover:bg-slate-850 text-left transition flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-orange-500/10 text-[#FF5200] flex items-center justify-center">
                <Bike size={18} />
              </div>
              <div>
                <span className="text-xs font-bold text-white group-hover:text-[#FF5200] transition block">
                  Registered Vehicle
                </span>
                <span className="text-[11px] text-slate-400">
                  {profile.vehicle.makeModel} ({profile.vehicle.registrationNumber})
                </span>
              </div>
            </div>
            <ChevronRight size={16} className="text-slate-400 group-hover:text-white" />
          </button>

          {/* Compliance Documents */}
          <button
            onClick={() => setActiveModal('documents')}
            className="w-full p-3.5 hover:bg-slate-850 text-left transition flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                <FileCheck2 size={18} />
              </div>
              <div>
                <span className="text-xs font-bold text-white group-hover:text-emerald-400 transition block">
                  Compliance Documents
                </span>
                <span className="text-[11px] text-slate-400">
                  Driving License, Aadhaar, RC, Insurance (All Verified)
                </span>
              </div>
            </div>
            <ChevronRight size={16} className="text-slate-400 group-hover:text-white" />
          </button>

          {/* Bank Account & Payouts */}
          <button
            onClick={() => setActiveModal('bank')}
            className="w-full p-3.5 hover:bg-slate-850 text-left transition flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-sky-500/10 text-sky-400 flex items-center justify-center">
                <Building size={18} />
              </div>
              <div>
                <span className="text-xs font-bold text-white group-hover:text-sky-400 transition block">
                  Bank Account & UPI Payouts
                </span>
                <span className="text-[11px] text-slate-400">
                  {profile.bankAccount?.bankName} ({profile.bankAccount?.accountNumberMasked})
                </span>
              </div>
            </div>
            <ChevronRight size={16} className="text-slate-400 group-hover:text-white" />
          </button>

          {/* Partner Training & Safety Guide (Interactive Onboarding Re-run) */}
          <button
            onClick={() => setActiveModal('guide')}
            className="w-full p-3.5 hover:bg-slate-850 text-left transition flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center">
                <BookOpen size={18} />
              </div>
              <div>
                <span className="text-xs font-bold text-white group-hover:text-purple-400 transition block">
                  Delivery Guidelines & Safety Training
                </span>
                <span className="text-[11px] text-slate-400">
                  Review the 8 partner operating guidelines
                </span>
              </div>
            </div>
            <ChevronRight size={16} className="text-slate-400 group-hover:text-white" />
          </button>

          {/* Privacy & Legal */}
          <button
            onClick={() => setActiveModal('privacy')}
            className="w-full p-3.5 hover:bg-slate-850 text-left transition flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-slate-800 text-slate-300 flex items-center justify-center">
                <Lock size={17} />
              </div>
              <div>
                <span className="text-xs font-bold text-white group-hover:text-slate-200 transition block">
                  Location Privacy & Legal Disclosures
                </span>
                <span className="text-[11px] text-slate-400">
                  GPS handling policies and account settings
                </span>
              </div>
            </div>
            <ChevronRight size={16} className="text-slate-400 group-hover:text-white" />
          </button>

          {/* Helmet Safety Check */}
          <button
            onClick={() => setActiveModal('helmet')}
            className="w-full p-3.5 hover:bg-slate-850 text-left transition flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                <Shield size={18} />
              </div>
              <div>
                <span className="text-xs font-bold text-white group-hover:text-emerald-400 transition block">
                  Daily Helmet Safety AI Verification
                </span>
                <span className="text-[11px] text-slate-400">
                  Verify helmet compliance before heading on road
                </span>
              </div>
            </div>
            <ChevronRight size={16} className="text-slate-400 group-hover:text-white" />
          </button>

          {/* App Settings */}
          <button
            onClick={() => setActiveModal('settings')}
            className="w-full p-3.5 hover:bg-slate-850 text-left transition flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-orange-500/10 text-[#FF5200] flex items-center justify-center">
                <Sliders size={18} />
              </div>
              <div>
                <span className="text-xs font-bold text-white group-hover:text-[#FF5200] transition block">
                  App Settings & Dispatch Preferences
                </span>
                <span className="text-[11px] text-slate-400">
                  Maps, alert sounds, battery saver, max distance radius
                </span>
              </div>
            </div>
            <ChevronRight size={16} className="text-slate-400 group-hover:text-white" />
          </button>
        </div>

        {/* App Preferences */}
        <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 space-y-3">
          <span className="text-xs font-bold text-white uppercase tracking-wider block">
            Preferences & Language
          </span>

          {/* Language Switcher */}
          <div>
            <label className="text-xs text-slate-400 flex items-center gap-1.5 mb-1.5 font-medium">
              <Globe2 size={13} className="text-sky-400" />
              <span>Language ({SUPPORTED_LANGUAGES.length} Indian Languages)</span>
            </label>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as SupportedLanguage)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs font-bold text-white focus:outline-none focus:border-[#FF5200]"
            >
              {SUPPORTED_LANGUAGES.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.name} ({lang.nativeName})
                </option>
              ))}
            </select>
          </div>

          {/* Audio Notifications Toggle */}
          <div className="flex items-center justify-between py-2 border-t border-slate-800 text-xs">
            <span className="text-slate-300">Order Alert Sound</span>
            <button
              onClick={toggleSound}
              className={`p-2 rounded-xl transition ${
                soundEnabled ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
            </button>
          </div>

          {/* Developer Mock Tool */}
          <div className="flex items-center justify-between py-2 border-t border-slate-800 text-xs">
            <span className="text-slate-300">Developer Simulation Panel</span>
            <button
              onClick={toggleSimulator}
              className="px-3 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-xl font-bold flex items-center gap-1.5"
            >
              <Sparkles size={13} />
              <span>Open Dev Drawer</span>
            </button>
          </div>
        </div>

        {/* SOS Emergency & Log Out */}
        <div className="space-y-2 pt-2">
          <button
            onClick={() => setActiveModal('sos')}
            className="w-full py-3 bg-rose-950/80 hover:bg-rose-900 border border-rose-800/60 text-rose-300 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition"
          >
            <ShieldAlert size={15} />
            <span>Emergency Safety Support (SOS)</span>
          </button>

          <button
            onClick={logout}
            className="w-full py-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-rose-400 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition"
          >
            <LogOut size={15} />
            <span>Log Out of FoodGo Partner</span>
          </button>
        </div>
      </div>

      {/* Dynamic Modals */}
      {activeModal === 'edit-profile' && (
        <EditProfileModal onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'vehicle' && (
        <VehicleManagementModal onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'documents' && (
        <DocumentManagementModal onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'performance' && (
        <PerformanceRatingModal onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'bank' && (
        <BankDetailsModal onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'privacy' && (
        <PrivacySafetyModal onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'guide' && (
        <div className="fixed inset-0 bg-slate-950 z-50 flex flex-col">
          <OnboardingScreen onFinish={() => setActiveModal(null)} isModalView />
        </div>
      )}
      {activeModal === 'sos' && (
        <EmergencySosModal onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'helmet' && (
        <HelmetCheckModal onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'settings' && (
        <div className="fixed inset-0 bg-slate-950 z-50 flex flex-col">
          <SettingsScreen onBack={() => setActiveModal(null)} />
        </div>
      )}
    </div>
  );
};
