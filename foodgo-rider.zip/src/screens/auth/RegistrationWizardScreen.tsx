import React, { useState } from 'react';
import {
  ChevronLeft,
  ArrowRight,
  User,
  MapPin,
  Bike,
  FileCheck,
  Building,
  ShieldCheck,
  CheckCircle2,
  Camera,
  Upload,
  AlertCircle,
} from 'lucide-react';
import { useAuth } from '../../store/authStore';
import {
  registrationStep1Schema,
  registrationStep2Schema,
  registrationStep3Schema,
  registrationStep4Schema,
  registrationStep5Schema,
  registrationStep6Schema,
} from '../../validation/auth.validation';

export const RegistrationWizardScreen: React.FC = () => {
  const { setAuthScreen, register, isLoading } = useAuth();
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    // Step 1
    fullName: '',
    phone: '',
    email: '',
    password: '',
    // Step 2
    dateOfBirth: '2000-01-01',
    gender: 'Male',
    street: '',
    city: 'Bengaluru',
    state: 'Karnataka',
    postalCode: '560038',
    // Step 3
    vehicleType: 'MOTORCYCLE',
    registrationNumber: 'KA01EQ9812',
    makeModel: 'Hero Splendor Plus',
    color: 'Black',
    drivingLicenseNumber: 'KA0120200088992',
    // Step 4
    hasDrivingLicense: true,
    hasAadhaarCard: true,
    hasVehicleRc: true,
    hasProfilePhoto: true,
    // Step 5
    accountHolderName: '',
    bankName: 'HDFC Bank',
    accountNumber: '5010022334455',
    confirmAccountNumber: '5010022334455',
    ifscCode: 'HDFC0001244',
    upiId: '',
    // Step 6
    agreedToTerms: true,
    agreedToPrivacy: true,
    consentBackgroundCheck: true,
  });

  const updateField = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setErrorMsg(null);
  };

  const handleNextStep = async () => {
    setErrorMsg(null);

    // Validate current step
    try {
      if (currentStep === 1) {
        registrationStep1Schema.parse({
          fullName: formData.fullName,
          phone: formData.phone,
          email: formData.email,
          password: formData.password,
        });
      } else if (currentStep === 2) {
        registrationStep2Schema.parse({
          dateOfBirth: formData.dateOfBirth,
          gender: formData.gender,
          address: {
            street: formData.street,
            city: formData.city,
            state: formData.state,
            postalCode: formData.postalCode,
          },
        });
      } else if (currentStep === 3) {
        registrationStep3Schema.parse({
          vehicleType: formData.vehicleType,
          registrationNumber: formData.registrationNumber,
          makeModel: formData.makeModel,
          color: formData.color,
          drivingLicenseNumber: formData.drivingLicenseNumber,
        });
      } else if (currentStep === 4) {
        registrationStep4Schema.parse({
          hasDrivingLicense: formData.hasDrivingLicense,
          hasAadhaarCard: formData.hasAadhaarCard,
          hasVehicleRc: formData.hasVehicleRc,
          hasProfilePhoto: formData.hasProfilePhoto,
        });
      } else if (currentStep === 5) {
        registrationStep5Schema.parse({
          accountHolderName: formData.accountHolderName || formData.fullName,
          bankName: formData.bankName,
          accountNumber: formData.accountNumber,
          confirmAccountNumber: formData.confirmAccountNumber,
          ifscCode: formData.ifscCode,
          upiId: formData.upiId,
        });
      } else if (currentStep === 6) {
        registrationStep6Schema.parse({
          agreedToTerms: formData.agreedToTerms,
          agreedToPrivacy: formData.agreedToPrivacy,
          consentBackgroundCheck: formData.consentBackgroundCheck,
        });

        // Final submission
        await register(formData);
        return;
      }

      setCurrentStep((prev) => prev + 1);
    } catch (err: any) {
      if (err.errors && err.errors[0]) {
        setErrorMsg(err.errors[0].message);
      } else {
        setErrorMsg(err.message || 'Validation error');
      }
    }
  };

  const handlePrevStep = () => {
    if (currentStep > 1) {
      setCurrentStep((prev) => prev - 1);
      setErrorMsg(null);
    } else {
      setAuthScreen('welcome');
    }
  };

  const stepsMeta = [
    { num: 1, title: 'Identity', icon: <User size={14} /> },
    { num: 2, title: 'Address', icon: <MapPin size={14} /> },
    { num: 3, title: 'Vehicle', icon: <Bike size={14} /> },
    { num: 4, title: 'Docs', icon: <FileCheck size={14} /> },
    { num: 5, title: 'Bank', icon: <Building size={14} /> },
    { num: 6, title: 'Consent', icon: <ShieldCheck size={14} /> },
  ];

  return (
    <div className="flex-1 flex flex-col justify-between p-5 bg-slate-950 overflow-y-auto">
      {/* Top Header */}
      <div>
        <div className="flex items-center justify-between pb-3">
          <button
            onClick={handlePrevStep}
            className="flex items-center gap-1 text-xs text-slate-400 hover:text-white"
          >
            <ChevronLeft size={16} />
            <span>{currentStep === 1 ? 'Cancel' : 'Back'}</span>
          </button>

          <span className="text-xs font-mono font-bold text-orange-400">
            STEP {currentStep} OF 6
          </span>

          <button
            onClick={() => {
              // Quick demo pre-fill helper
              setFormData({
                fullName: 'Kiran Reddy',
                phone: '9876543299',
                email: 'kiran.reddy@example.com',
                password: 'Password123!',
                dateOfBirth: '1999-04-12',
                gender: 'Male',
                street: '45, 1st Cross, HSR Sector 2',
                city: 'Bengaluru',
                state: 'Karnataka',
                postalCode: '560102',
                vehicleType: 'MOTORCYCLE',
                registrationNumber: 'KA03EQ4512',
                makeModel: 'Honda Shine 125',
                color: 'Matte Grey',
                drivingLicenseNumber: 'KA0320210091244',
                hasDrivingLicense: true,
                hasAadhaarCard: true,
                hasVehicleRc: true,
                hasProfilePhoto: true,
                accountHolderName: 'Kiran Reddy',
                bankName: 'HDFC Bank',
                accountNumber: '5010099887766',
                confirmAccountNumber: '5010099887766',
                ifscCode: 'HDFC0001244',
                upiId: 'kiran@okaxis',
                agreedToTerms: true,
                agreedToPrivacy: true,
                consentBackgroundCheck: true,
              });
            }}
            className="text-[11px] text-amber-400 font-bold hover:underline"
          >
            Auto Fill
          </button>
        </div>

        {/* Progress Bar & Icons */}
        <div className="flex items-center justify-between gap-1 mb-4">
          {stepsMeta.map((s) => (
            <div
              key={s.num}
              className={`flex-1 h-1.5 rounded-full transition-all ${
                s.num <= currentStep ? 'bg-[#FF5200]' : 'bg-slate-800'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Step Content */}
      <div className="my-auto py-2 max-w-sm w-full mx-auto space-y-4">
        {/* Step 1: Personal Credentials */}
        {currentStep === 1 && (
          <div className="space-y-3.5 animate-fadeIn">
            <div>
              <h2 className="text-lg font-extrabold text-white">Create Partner Account</h2>
              <p className="text-xs text-slate-400">Step 1: Your name and contact details</p>
            </div>

            <div className="bg-slate-900 p-5 rounded-3xl border border-slate-800 space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Full Name (as on ID)</label>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => updateField('fullName', e.target.value)}
                  placeholder="e.g. Kiran Reddy"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Mobile Number (India)</label>
                <div className="flex gap-2">
                  <span className="px-2.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-400 text-xs font-mono flex items-center">
                    +91
                  </span>
                  <input
                    type="tel"
                    maxLength={10}
                    value={formData.phone}
                    onChange={(e) => updateField('phone', e.target.value.replace(/\D/g, ''))}
                    placeholder="9876543299"
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#FF5200]"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Email Address</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => updateField('email', e.target.value)}
                  placeholder="kiran.reddy@example.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Create Password (min 8 chars)</label>
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => updateField('password', e.target.value)}
                  placeholder="At least 1 uppercase & 1 number"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Demographics & Address */}
        {currentStep === 2 && (
          <div className="space-y-3.5 animate-fadeIn">
            <div>
              <h2 className="text-lg font-extrabold text-white">Residential Address</h2>
              <p className="text-xs text-slate-400">Step 2: Operating city and local residence</p>
            </div>

            <div className="bg-slate-900 p-5 rounded-3xl border border-slate-800 space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Date of Birth</label>
                  <input
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={(e) => updateField('dateOfBirth', e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Gender</label>
                  <select
                    value={formData.gender}
                    onChange={(e) => updateField('gender', e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Street Address</label>
                <input
                  type="text"
                  value={formData.street}
                  onChange={(e) => updateField('street', e.target.value)}
                  placeholder="Flat/House number, Street name"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">City</label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => updateField('city', e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">PIN Code</label>
                  <input
                    type="text"
                    maxLength={6}
                    value={formData.postalCode}
                    onChange={(e) => updateField('postalCode', e.target.value.replace(/\D/g, ''))}
                    placeholder="560038"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#FF5200]"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Step 3: Vehicle Information */}
        {currentStep === 3 && (
          <div className="space-y-3.5 animate-fadeIn">
            <div>
              <h2 className="text-lg font-extrabold text-white">Vehicle Details</h2>
              <p className="text-xs text-slate-400">Step 3: What vehicle will you use to deliver?</p>
            </div>

            <div className="bg-slate-900 p-5 rounded-3xl border border-slate-800 space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Vehicle Type</label>
                <select
                  value={formData.vehicleType}
                  onChange={(e) => updateField('vehicleType', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                >
                  <option value="MOTORCYCLE">Motorcycle / Bike</option>
                  <option value="SCOOTER">Scooter / Scooty</option>
                  <option value="ELECTRIC_VEHICLE">Electric Two-Wheeler (EV)</option>
                  <option value="BICYCLE">Bicycle</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Vehicle Registration Number</label>
                <input
                  type="text"
                  value={formData.registrationNumber}
                  onChange={(e) => updateField('registrationNumber', e.target.value.toUpperCase())}
                  placeholder="e.g. KA01EQ9812"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono uppercase focus:outline-none focus:border-[#FF5200]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Make & Model</label>
                  <input
                    type="text"
                    value={formData.makeModel}
                    onChange={(e) => updateField('makeModel', e.target.value)}
                    placeholder="Honda Shine"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Color</label>
                  <input
                    type="text"
                    value={formData.color}
                    onChange={(e) => updateField('color', e.target.value)}
                    placeholder="Black"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Driving License Number</label>
                <input
                  type="text"
                  value={formData.drivingLicenseNumber}
                  onChange={(e) => updateField('drivingLicenseNumber', e.target.value.toUpperCase())}
                  placeholder="e.g. KA0120200088992"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono uppercase focus:outline-none focus:border-[#FF5200]"
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 4: Documents Upload Checklist */}
        {currentStep === 4 && (
          <div className="space-y-3.5 animate-fadeIn">
            <div>
              <h2 className="text-lg font-extrabold text-white">Document Compliance</h2>
              <p className="text-xs text-slate-400">Step 4: Verification photos for compliance</p>
            </div>

            <div className="bg-slate-900 p-5 rounded-3xl border border-slate-800 space-y-3">
              {[
                { key: 'hasDrivingLicense', title: 'Driving License', desc: 'Front and back photo' },
                { key: 'hasAadhaarCard', title: 'Aadhaar / National ID', desc: 'Government photo identification' },
                { key: 'hasVehicleRc', title: 'Vehicle RC Book', desc: 'Registration certificate' },
                { key: 'hasProfilePhoto', title: 'Selfie Profile Photo', desc: 'Clear face with no cap/sunglasses' },
              ].map((doc) => (
                <div
                  key={doc.key}
                  className="p-3 bg-slate-950/80 rounded-2xl border border-slate-800 flex items-center justify-between"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-orange-500/10 text-[#FF5200] flex items-center justify-center">
                      <Camera size={15} />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">{doc.title}</h4>
                      <p className="text-[10px] text-slate-400">{doc.desc}</p>
                    </div>
                  </div>

                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                    <CheckCircle2 size={11} />
                    <span>Uploaded</span>
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Step 5: Bank & Payouts */}
        {currentStep === 5 && (
          <div className="space-y-3.5 animate-fadeIn">
            <div>
              <h2 className="text-lg font-extrabold text-white">Bank Account / UPI</h2>
              <p className="text-xs text-slate-400">Step 5: Where should we transfer your weekly earnings?</p>
            </div>

            <div className="bg-slate-900 p-5 rounded-3xl border border-slate-800 space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Account Holder Name</label>
                <input
                  type="text"
                  value={formData.accountHolderName || formData.fullName}
                  onChange={(e) => updateField('accountHolderName', e.target.value)}
                  placeholder="Name as per passbook"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Bank Name</label>
                <input
                  type="text"
                  value={formData.bankName}
                  onChange={(e) => updateField('bankName', e.target.value)}
                  placeholder="e.g. HDFC Bank, SBI, ICICI"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Bank Account Number</label>
                <input
                  type="password"
                  value={formData.accountNumber}
                  onChange={(e) => updateField('accountNumber', e.target.value.replace(/\D/g, ''))}
                  placeholder="Account number"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#FF5200]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Confirm Account Number</label>
                <input
                  type="text"
                  value={formData.confirmAccountNumber}
                  onChange={(e) => updateField('confirmAccountNumber', e.target.value.replace(/\D/g, ''))}
                  placeholder="Re-type account number"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#FF5200]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">IFSC Code</label>
                  <input
                    type="text"
                    maxLength={11}
                    value={formData.ifscCode}
                    onChange={(e) => updateField('ifscCode', e.target.value.toUpperCase())}
                    placeholder="HDFC0001244"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono uppercase focus:outline-none focus:border-[#FF5200]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">UPI ID (Optional)</label>
                  <input
                    type="text"
                    value={formData.upiId}
                    onChange={(e) => updateField('upiId', e.target.value)}
                    placeholder="kiran@okaxis"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Step 6: Review & Legal Declarations */}
        {currentStep === 6 && (
          <div className="space-y-3.5 animate-fadeIn">
            <div>
              <h2 className="text-lg font-extrabold text-white">Review & Consent</h2>
              <p className="text-xs text-slate-400">Step 6: Review declarations before submitting</p>
            </div>

            <div className="bg-slate-900 p-5 rounded-3xl border border-slate-800 space-y-3 text-xs text-slate-300">
              <label className="flex items-start gap-2.5 p-2 bg-slate-950/70 rounded-xl border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.agreedToTerms}
                  onChange={(e) => updateField('agreedToTerms', e.target.checked)}
                  className="mt-0.5 accent-[#FF5200] w-4 h-4"
                />
                <span className="leading-relaxed">
                  I agree to the <strong className="text-white">Delivery Partner Service Agreement</strong> and commercial payout rates.
                </span>
              </label>

              <label className="flex items-start gap-2.5 p-2 bg-slate-950/70 rounded-xl border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.agreedToPrivacy}
                  onChange={(e) => updateField('agreedToPrivacy', e.target.checked)}
                  className="mt-0.5 accent-[#FF5200] w-4 h-4"
                />
                <span className="leading-relaxed">
                  I consent to real-time GPS location sharing while on duty as described in the <strong className="text-white">Privacy Policy</strong>.
                </span>
              </label>

              <label className="flex items-start gap-2.5 p-2 bg-slate-950/70 rounded-xl border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.consentBackgroundCheck}
                  onChange={(e) => updateField('consentBackgroundCheck', e.target.checked)}
                  className="mt-0.5 accent-[#FF5200] w-4 h-4"
                />
                <span className="leading-relaxed">
                  I confirm that all vehicle, driving license, and bank credentials submitted belong to me and are authentic.
                </span>
              </label>
            </div>
          </div>
        )}

        {/* Error Notification */}
        {errorMsg && (
          <div className="p-3 bg-rose-950/80 border border-rose-800 rounded-xl flex items-center gap-2 text-rose-300 text-xs">
            <AlertCircle size={15} className="shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}
      </div>

      {/* Action Footer Button */}
      <div className="pt-2">
        <button
          onClick={handleNextStep}
          disabled={isLoading}
          className="w-full py-3.5 px-4 bg-gradient-to-r from-[#FF5200] to-orange-600 hover:brightness-110 disabled:opacity-50 text-white rounded-2xl font-bold text-xs flex items-center justify-center gap-2 shadow-xl shadow-orange-950/50 transition active:scale-98"
        >
          <span>
            {isLoading
              ? 'Submitting Application...'
              : currentStep === 6
              ? 'SUBMIT REGISTRATION'
              : 'CONTINUE TO NEXT STEP'}
          </span>
          <ArrowRight size={15} />
        </button>
      </div>
    </div>
  );
};
