import React from 'react';
import {
  Bike,
  ShieldCheck,
  Zap,
  IndianRupee,
  Clock,
  Globe2,
  Sparkles,
  ArrowRight,
  CheckCircle2,
} from 'lucide-react';
import { useAuth } from '../../store/authStore';
import { useTheme } from '../../store/themeStore';
import { APP_CONFIG } from '../../constants/config';
import { SUPPORTED_LANGUAGES, SupportedLanguage } from '../../constants/translations';

export const WelcomeScreen: React.FC = () => {
  const { setAuthScreen, login } = useAuth();
  const { language, setLanguage, t } = useTheme();

  const handleInstantDemoLogin = async () => {
    await login({
      email: 'rider@example.com',
      loginMethod: 'EMAIL_PASSWORD',
    });
  };

  return (
    <div className="flex-1 flex flex-col justify-between p-5 bg-slate-950 overflow-y-auto">
      {/* Top Bar with Language Selector */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#FF5200] to-amber-500 flex items-center justify-center text-white font-black text-xs shadow-md">
            FG
          </div>
          <span className="font-extrabold text-white text-sm tracking-tight">{APP_CONFIG.appName}</span>
        </div>

        {/* Quick Language Dropdown */}
        <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 rounded-full px-2.5 py-1 text-xs">
          <Globe2 size={13} className="text-[#FF5200]" />
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value as SupportedLanguage)}
            className="bg-transparent text-slate-200 text-xs font-semibold focus:outline-none cursor-pointer"
          >
            {SUPPORTED_LANGUAGES.map((l) => (
              <option key={l.code} value={l.code} className="bg-slate-900 text-white">
                {l.nativeName}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Hero Visual & Value Proposition */}
      <div className="my-auto py-6 space-y-5 text-center">
        {/* Animated Rider Emblem */}
        <div className="relative w-28 h-28 mx-auto">
          <div className="absolute inset-0 bg-gradient-to-tr from-[#FF5200]/30 to-amber-500/20 rounded-full blur-xl animate-pulse"></div>
          <div className="relative w-full h-full rounded-full bg-slate-900 border-2 border-[#FF5200] flex items-center justify-center text-white shadow-2xl shadow-orange-950/60">
            <Bike size={54} className="text-[#FF5200]" />
          </div>
        </div>

        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold">
            <Sparkles size={12} />
            <span>Join 25,000+ Active Riders in India</span>
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight leading-tight">
            Deliver Food. <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FF5200] to-amber-400">
              Earn on Your Own Schedule.
            </span>
          </h1>
          <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
            Earn up to <strong className="text-white">₹35,000 / month</strong> with daily instant UPI payouts, insurance coverage, and peak hour surge bonuses.
          </p>
        </div>

        {/* Value Highlights Grid */}
        <div className="grid grid-cols-3 gap-2 pt-2 text-left">
          <div className="bg-slate-900/90 p-2.5 rounded-2xl border border-slate-800">
            <IndianRupee size={15} className="text-emerald-400 mb-1" />
            <span className="text-[11px] font-bold text-white block">Daily Payout</span>
            <span className="text-[10px] text-slate-400">Instant UPI transfer</span>
          </div>

          <div className="bg-slate-900/90 p-2.5 rounded-2xl border border-slate-800">
            <Clock size={15} className="text-amber-400 mb-1" />
            <span className="text-[11px] font-bold text-white block">Flexible Shifts</span>
            <span className="text-[10px] text-slate-400">Work when you want</span>
          </div>

          <div className="bg-slate-900/90 p-2.5 rounded-2xl border border-slate-800">
            <ShieldCheck size={15} className="text-sky-400 mb-1" />
            <span className="text-[11px] font-bold text-white block">₹5L Insurance</span>
            <span className="text-[10px] text-slate-400">Accidental medical</span>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="space-y-2.5 pb-2">
        {/* Instant 1-tap evaluator demo button */}
        <button
          onClick={handleInstantDemoLogin}
          className="w-full py-2.5 px-3 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 rounded-xl text-xs font-bold border border-amber-500/30 flex items-center justify-center gap-1.5 transition"
        >
          <Sparkles size={13} />
          <span>Quick 1-Tap Evaluator Sign In (Dhanush Kumar)</span>
        </button>

        {/* Register Button */}
        <button
          onClick={() => setAuthScreen('register')}
          className="w-full py-3.5 px-4 bg-gradient-to-r from-[#FF5200] to-orange-600 hover:brightness-110 text-white rounded-2xl font-bold text-xs flex items-center justify-center gap-2 shadow-xl shadow-orange-950/50 transition active:scale-98"
        >
          <span>APPLY AS DELIVERY PARTNER</span>
          <ArrowRight size={15} />
        </button>

        {/* Existing Partner Login Button */}
        <button
          onClick={() => setAuthScreen('login')}
          className="w-full py-3 px-4 bg-slate-900 hover:bg-slate-850 text-slate-200 rounded-2xl font-semibold text-xs border border-slate-800 transition"
        >
          Already a partner? <strong className="text-[#FF5200] ml-1">Log In</strong>
        </button>
      </div>
    </div>
  );
};
