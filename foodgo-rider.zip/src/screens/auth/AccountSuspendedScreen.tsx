import React, { useState } from 'react';
import { ShieldAlert, AlertTriangle, Phone, RefreshCw, LogOut, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../store/authStore';
import { APP_CONFIG } from '../../constants/config';

export const AccountSuspendedScreen: React.FC = () => {
  const { rider, setAccountStatusOverride, logout } = useAuth();
  const [appealText, setAppealText] = useState('');
  const [isAppealSubmitted, setIsAppealSubmitted] = useState(false);

  const handleRestoreAccount = async () => {
    await setAccountStatusOverride('ACTIVE');
  };

  return (
    <div className="flex-1 flex flex-col justify-between p-5 bg-slate-950 overflow-y-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between pt-1">
        <span className="text-xs font-mono font-bold text-rose-500">ACCOUNT NOTICE</span>
        <button
          onClick={logout}
          className="flex items-center gap-1 text-xs text-slate-400 hover:text-white"
        >
          <LogOut size={13} />
          <span>Sign Out</span>
        </button>
      </div>

      <div className="my-auto py-4 max-w-sm w-full mx-auto space-y-5 text-center">
        {/* Suspended Warning Icon */}
        <div className="w-16 h-16 mx-auto rounded-3xl bg-rose-500/10 border-2 border-rose-500/50 flex items-center justify-center text-rose-500">
          <ShieldAlert size={36} />
        </div>

        <div>
          <h2 className="text-xl font-extrabold text-white tracking-tight">
            Account Temporarily Suspended
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto leading-relaxed">
            Your rider access for <strong className="text-white">{rider?.fullName}</strong> has been flagged due to document renewal or compliance check.
          </p>
        </div>

        {/* Appeal Box */}
        <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 text-left space-y-3 shadow-xl">
          <span className="text-xs font-bold text-slate-300 block">Submit Compliance Appeal</span>
          {isAppealSubmitted ? (
            <div className="p-3 bg-emerald-950/80 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle2 size={16} className="shrink-0" />
              <span>Appeal received. Compliance team will review within 4 hours.</span>
            </div>
          ) : (
            <>
              <textarea
                value={appealText}
                onChange={(e) => setAppealText(e.target.value)}
                placeholder="Explain the circumstance or attach renewal details..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white resize-none h-20 focus:outline-none focus:border-[#FF5200]"
              />
              <button
                onClick={() => setIsAppealSubmitted(true)}
                disabled={!appealText.trim()}
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition"
              >
                Submit Appeal
              </button>
            </>
          )}
        </div>

        {/* Dev Restore Button */}
        <div className="bg-slate-900 border border-slate-800 p-3 rounded-2xl text-left space-y-1.5">
          <span className="text-[10px] font-mono text-amber-400 font-bold uppercase block">
            Dev Quick Restore
          </span>
          <button
            onClick={handleRestoreAccount}
            className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-700 text-emerald-400 text-xs font-bold rounded-xl border border-slate-700 transition"
          >
            Reset Status to ACTIVE (Bypass Suspension)
          </button>
        </div>
      </div>

      <div className="text-center text-xs text-slate-400 pb-2">
        Need immediate help?{' '}
        <a href={`tel:${APP_CONFIG.support.phone}`} className="text-rose-400 font-bold hover:underline">
          Contact Compliance Team
        </a>
      </div>
    </div>
  );
};
