import React from 'react';
import {
  Clock,
  ShieldAlert,
  CheckCircle2,
  FileCheck,
  AlertCircle,
  Sparkles,
  LogOut,
  PhoneCall,
} from 'lucide-react';
import { useAuth } from '../../store/authStore';
import { APP_CONFIG } from '../../constants/config';

export const PendingVerificationScreen: React.FC = () => {
  const { rider, setAccountStatusOverride, logout } = useAuth();

  const handleInstantApprove = async () => {
    await setAccountStatusOverride('ACTIVE');
  };

  return (
    <div className="flex-1 flex flex-col justify-between p-5 bg-slate-950 overflow-y-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between pt-1">
        <span className="text-xs font-mono font-bold text-amber-400">APPLICATION SUBMITTED</span>
        <button
          onClick={logout}
          className="flex items-center gap-1 text-xs text-slate-400 hover:text-white"
        >
          <LogOut size={13} />
          <span>Sign Out</span>
        </button>
      </div>

      <div className="my-auto py-4 max-w-sm w-full mx-auto space-y-5 text-center">
        {/* Verification In Progress Emblem */}
        <div className="relative w-20 h-20 mx-auto">
          <div className="absolute inset-0 bg-amber-500/20 rounded-full blur-lg animate-pulse"></div>
          <div className="relative w-full h-full rounded-full bg-slate-900 border-2 border-amber-500/60 flex items-center justify-center text-amber-400 shadow-xl">
            <Clock size={36} className="animate-spin" style={{ animationDuration: '8s' }} />
          </div>
        </div>

        <div className="space-y-1">
          <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest block">
            REF: {rider?.riderCode || 'APP-2026-9921'}
          </span>
          <h2 className="text-xl font-extrabold text-white tracking-tight">
            Under Document Review
          </h2>
          <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
            Welcome <strong className="text-white">{rider?.fullName || 'Partner'}</strong>! Our verification team is validating your driving license and vehicle registration.
          </p>
        </div>

        {/* Verification Milestones */}
        <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 text-left space-y-3.5 shadow-xl">
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
              <CheckCircle2 size={14} />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">Application Submitted</h4>
              <p className="text-[10px] text-slate-400">All 6 onboarding stages completed</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 mt-0.5 animate-pulse">
              <Clock size={14} />
            </div>
            <div>
              <h4 className="text-xs font-bold text-amber-300">Identity & RC Validation</h4>
              <p className="text-[10px] text-slate-400">Typical turnaround: 12 to 24 hours</p>
            </div>
          </div>

          <div className="flex items-start gap-3 opacity-60">
            <div className="w-6 h-6 rounded-full bg-slate-800 text-slate-500 flex items-center justify-center shrink-0 mt-0.5">
              <ShieldAlert size={14} />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-300">Live Delivery Activation</h4>
              <p className="text-[10px] text-slate-400">Unlocks duty toggle and delivery dispatch</p>
            </div>
          </div>
        </div>

        {/* Instant Dev Simulation Approval Banner */}
        <div className="bg-gradient-to-r from-emerald-950/80 to-slate-900 border border-emerald-500/40 p-4 rounded-2xl text-left space-y-2">
          <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-bold">
            <Sparkles size={14} />
            <span>Developer / Evaluator Quick Action</span>
          </div>
          <p className="text-[11px] text-slate-300">
            Simulate administrative approval to immediately activate this rider profile and test live deliveries.
          </p>
          <button
            onClick={handleInstantApprove}
            className="w-full py-2.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-md transition"
          >
            Simulate Instant Admin Approval → Activate Account
          </button>
        </div>
      </div>

      {/* Support footer */}
      <div className="text-center text-xs text-slate-400 pb-2">
        Questions about your application?{' '}
        <a href={`tel:${APP_CONFIG.support.phone}`} className="text-[#FF5200] font-bold hover:underline">
          Call Partner Helpdesk
        </a>
      </div>
    </div>
  );
};
