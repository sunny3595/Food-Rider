import React, { useState } from 'react';
import { ChevronLeft, Mail, Phone, CheckCircle2, ArrowRight } from 'lucide-react';
import { useAuth } from '../../store/authStore';
import { AuthApi } from '../../api/auth.api';

export const ForgotPasswordScreen: React.FC = () => {
  const { setAuthScreen } = useAuth();
  const [identifier, setIdentifier] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier.trim()) {
      setErrorMsg('Please enter your registered email or phone');
      return;
    }
    setErrorMsg(null);
    setIsProcessing(true);
    try {
      await AuthApi.requestPasswordReset(identifier);
      setIsSubmitted(true);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to submit reset request');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col justify-between p-5 bg-slate-950 overflow-y-auto">
      {/* Top Bar */}
      <div className="flex items-center justify-between pt-1">
        <button
          onClick={() => setAuthScreen('login')}
          className="flex items-center gap-1 text-xs text-slate-400 hover:text-white transition"
        >
          <ChevronLeft size={16} />
          <span>Back to Login</span>
        </button>
        <span className="text-xs font-mono font-bold text-slate-400">PASSWORD RECOVERY</span>
        <div className="w-8" />
      </div>

      <div className="my-auto py-6 max-w-sm w-full mx-auto space-y-5">
        <div>
          <h2 className="text-xl font-extrabold text-white tracking-tight">Forgot Password?</h2>
          <p className="text-xs text-slate-400 mt-1">
            Enter your registered partner email or phone number and we’ll send you password reset instructions.
          </p>
        </div>

        {isSubmitted ? (
          <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl p-6 text-center space-y-4 shadow-xl">
            <div className="w-14 h-14 mx-auto rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <CheckCircle2 size={32} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Reset Link Dispatched</h3>
              <p className="text-xs text-slate-400 mt-1">
                We've sent recovery details to <strong className="text-slate-200">{identifier}</strong>. Check your inbox or SMS.
              </p>
            </div>
            <button
              onClick={() => setAuthScreen('login')}
              className="w-full py-3 bg-[#FF5200] hover:bg-orange-600 text-white rounded-xl text-xs font-bold transition"
            >
              Return to Login
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="bg-slate-900 p-5 rounded-3xl border border-slate-800 space-y-4 shadow-xl">
            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1.5">
                Registered Phone or Email
              </label>
              <input
                type="text"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="e.g. 9876543210 or rider@example.com"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-[#FF5200]"
              />
            </div>

            {errorMsg && (
              <p className="text-xs text-rose-400 font-medium">{errorMsg}</p>
            )}

            <button
              type="submit"
              disabled={isProcessing}
              className="w-full py-3 bg-[#FF5200] hover:bg-orange-600 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-orange-950/40 flex items-center justify-center gap-1.5"
            >
              <span>{isProcessing ? 'Sending Request...' : 'Send Recovery Instructions'}</span>
              <ArrowRight size={14} />
            </button>
          </form>
        )}
      </div>

      <div className="text-center text-xs text-slate-400 pb-2">
        Remembered password?{' '}
        <button
          onClick={() => setAuthScreen('login')}
          className="text-[#FF5200] font-bold hover:underline"
        >
          Sign In
        </button>
      </div>
    </div>
  );
};
