import React, { useState } from 'react';
import {
  Phone,
  Mail,
  Lock,
  ArrowRight,
  ChevronLeft,
  Sparkles,
  AlertCircle,
  Eye,
  EyeOff,
} from 'lucide-react';
import { useAuth } from '../../store/authStore';
import { AuthApi } from '../../api/auth.api';
import { phoneSchema, emailSchema, passwordSchema } from '../../validation/auth.validation';

export const LoginScreen: React.FC = () => {
  const { setAuthScreen, setPhoneForOtp, login, loginWithGoogle, loginWithApple, isLoading, error } = useAuth();
  const [loginMethod, setLoginMethod] = useState<'PHONE' | 'EMAIL'>('PHONE');
  const [phone, setPhone] = useState('9876543210');
  const [email, setEmail] = useState('rider@example.com');
  const [password, setPassword] = useState('SecurePass123!');
  const [showPassword, setShowPassword] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);
  const [isSendingOtp, setIsSendingOtp] = useState(false);

  const handleSendPhoneOtp = async () => {
    setLocalError(null);
    const parsed = phoneSchema.safeParse(phone);
    if (!parsed.success) {
      const issue = (parsed.error as any).issues?.[0]?.message || (parsed.error as any).errors?.[0]?.message;
      setLocalError(issue || 'Invalid phone number');
      return;
    }

    setIsSendingOtp(true);
    try {
      await AuthApi.requestOtp(phone);
      setPhoneForOtp(phone);
      setAuthScreen('verify-phone');
    } catch (err: any) {
      setLocalError(err.message || 'Failed to send OTP code');
    } finally {
      setIsSendingOtp(false);
    }
  };

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);

    const emailCheck = emailSchema.safeParse(email);
    if (!emailCheck.success) {
      const issue = (emailCheck.error as any).issues?.[0]?.message || (emailCheck.error as any).errors?.[0]?.message;
      setLocalError(issue || 'Invalid email');
      return;
    }

    if (!password) {
      setLocalError('Please enter your password');
      return;
    }

    try {
      await login({
        email,
        password,
        loginMethod: 'EMAIL_PASSWORD',
      });
    } catch (err: any) {
      setLocalError(err.message || 'Login failed. Check your credentials.');
    }
  };

  return (
    <div className="flex-1 flex flex-col justify-between p-5 bg-slate-950 overflow-y-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between pt-1">
        <button
          onClick={() => setAuthScreen('welcome')}
          className="flex items-center gap-1 text-xs text-slate-400 hover:text-white transition"
        >
          <ChevronLeft size={16} />
          <span>Back</span>
        </button>

        <span className="text-xs font-mono font-bold text-slate-400">PARTNER LOGIN</span>
        <div className="w-8" />
      </div>

      <div className="my-auto py-4 max-w-sm w-full mx-auto space-y-5">
        {/* Title */}
        <div>
          <h2 className="text-xl font-extrabold text-white tracking-tight">Partner Sign In</h2>
          <p className="text-xs text-slate-400 mt-1">
            Access your active shift, track today's earnings, and accept deliveries.
          </p>
        </div>

        {/* 1-Tap Demo Quick Fill */}
        <button
          onClick={() => {
            setEmail('rider@example.com');
            setPassword('SecurePass123!');
            setPhone('9876543210');
            login({ email: 'rider@example.com', password: 'SecurePass123!', loginMethod: 'EMAIL_PASSWORD' });
          }}
          className="w-full py-2.5 px-3 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 rounded-xl text-xs font-bold border border-amber-500/30 flex items-center justify-center gap-1.5 transition"
        >
          <Sparkles size={14} />
          <span>Quick 1-Tap Sign In (Demo Rider Dhanush)</span>
        </button>

        {/* Method Toggle */}
        <div className="flex bg-slate-900 p-1 rounded-2xl border border-slate-800 text-xs">
          <button
            onClick={() => {
              setLoginMethod('PHONE');
              setLocalError(null);
            }}
            className={`flex-1 py-2 rounded-xl font-bold transition ${
              loginMethod === 'PHONE' ? 'bg-[#FF5200] text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            Phone & OTP
          </button>
          <button
            onClick={() => {
              setLoginMethod('EMAIL');
              setLocalError(null);
            }}
            className={`flex-1 py-2 rounded-xl font-bold transition ${
              loginMethod === 'EMAIL' ? 'bg-[#FF5200] text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            Email & Password
          </button>
        </div>

        {/* Form Container */}
        <div className="bg-slate-900 p-5 rounded-3xl border border-slate-800 space-y-4 shadow-xl">
          {loginMethod === 'PHONE' ? (
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1.5">
                  Mobile Number (India)
                </label>
                <div className="flex gap-2">
                  <span className="px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-slate-400 text-xs font-mono font-bold flex items-center">
                    +91
                  </span>
                  <input
                    type="tel"
                    maxLength={10}
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                    placeholder="9876543210"
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-sm text-white font-mono font-semibold focus:outline-none focus:border-[#FF5200]"
                  />
                </div>
                <span className="text-[10px] text-slate-400 mt-1 block">
                  We'll send a 4-digit verification code. (Demo OTP is 1234)
                </span>
              </div>

              <button
                onClick={handleSendPhoneOtp}
                disabled={isSendingOtp || phone.length < 10}
                className="w-full py-3 bg-[#FF5200] hover:bg-orange-600 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-orange-950/40 flex items-center justify-center gap-1.5"
              >
                <span>{isSendingOtp ? 'Sending OTP Code...' : 'Get OTP Code'}</span>
                <ArrowRight size={14} />
              </button>
            </div>
          ) : (
            <form onSubmit={handleEmailLogin} className="space-y-3.5">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Email Address</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="rider@example.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-300">Password</label>
                  <button
                    type="button"
                    onClick={() => setAuthScreen('forgot-password')}
                    className="text-[11px] text-orange-400 hover:text-orange-300 font-medium"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 pr-9 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 bg-[#FF5200] hover:bg-orange-600 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-orange-950/40"
              >
                {isLoading ? 'Signing In...' : 'Sign In'}
              </button>
            </form>
          )}

          {/* Error Message Alert */}
          {(localError || error) && (
            <div className="p-2.5 bg-rose-950/80 border border-rose-800/80 rounded-xl flex items-center gap-2 text-rose-300 text-xs">
              <AlertCircle size={14} className="shrink-0" />
              <span>{localError || error}</span>
            </div>
          )}

          {/* Social Logins Divider */}
          <div className="relative py-1 text-center">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-800"></div>
            </div>
            <span className="relative bg-slate-900 px-3 text-[10px] text-slate-400 font-bold uppercase">
              Or Social Auth
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={loginWithGoogle}
              className="py-2.5 px-3 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-xl text-xs font-semibold text-slate-200 flex items-center justify-center gap-2 transition"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Google</span>
            </button>

            <button
              type="button"
              onClick={loginWithApple}
              className="py-2.5 px-3 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-xl text-xs font-semibold text-slate-200 flex items-center justify-center gap-2 transition"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.84c.67-.82 1.13-1.96 1-3.1-.98.04-2.16.65-2.85 1.47-.61.71-1.14 1.87-1 2.99 1.1.09 2.21-.55 2.85-1.36z" />
              </svg>
              <span>Apple</span>
            </button>
          </div>
        </div>

        {/* Link to Registration */}
        <div className="text-center pt-2">
          <p className="text-xs text-slate-400">
            Don't have a partner account?{' '}
            <button
              onClick={() => setAuthScreen('register')}
              className="text-[#FF5200] font-bold hover:underline"
            >
              Apply to Register
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};
