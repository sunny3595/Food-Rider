import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, KeyRound, RotateCw, CheckCircle2, AlertCircle } from 'lucide-react';
import { useAuth } from '../../store/authStore';
import { AuthApi } from '../../api/auth.api';

export const VerifyOtpScreen: React.FC = () => {
  const { phoneForOtpVerification, setAuthScreen, verifyOtp, isLoading, error } = useAuth();
  const [digits, setDigits] = useState(['', '', '', '']);
  const [countdown, setCountdown] = useState(30);
  const [canResend, setCanResend] = useState(false);
  const [resendStatus, setResendStatus] = useState<string | null>(null);
  const [localError, setLocalError] = useState<string | null>(null);

  const inputRefs = [
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
  ];

  useEffect(() => {
    inputRefs[0].current?.focus();
  }, []);

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setCanResend(true);
    }
  }, [countdown]);

  const handleDigitChange = (index: number, val: string) => {
    const clean = val.replace(/\D/g, '').slice(-1);
    const newDigits = [...digits];
    newDigits[index] = clean;
    setDigits(newDigits);
    setLocalError(null);

    // Auto-advance
    if (clean && index < 3) {
      inputRefs[index + 1].current?.focus();
    }

    // Auto-submit if all 4 entered
    if (clean && index === 3) {
      const fullOtp = newDigits.join('');
      if (fullOtp.length === 4) {
        submitOtp(fullOtp);
      }
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !digits[index] && index > 0) {
      inputRefs[index - 1].current?.focus();
    }
  };

  const submitOtp = async (otpValue: string) => {
    try {
      await verifyOtp(phoneForOtpVerification || '9876543210', otpValue);
    } catch (err: any) {
      setLocalError(err.message || 'Incorrect verification OTP');
    }
  };

  const handleResend = async () => {
    if (!canResend) return;
    try {
      await AuthApi.requestOtp(phoneForOtpVerification || '9876543210');
      setCountdown(30);
      setCanResend(false);
      setResendStatus('A fresh OTP code was sent to your phone (1234)');
      setTimeout(() => setResendStatus(null), 3000);
    } catch {
      setLocalError('Failed to resend OTP. Please wait.');
    }
  };

  const fullCode = digits.join('');

  return (
    <div className="flex-1 flex flex-col justify-between p-5 bg-slate-950 overflow-y-auto">
      {/* Top Bar */}
      <div className="flex items-center justify-between pt-1">
        <button
          onClick={() => setAuthScreen('login')}
          className="flex items-center gap-1 text-xs text-slate-400 hover:text-white transition"
        >
          <ChevronLeft size={16} />
          <span>Change Number</span>
        </button>

        <span className="text-xs font-mono font-bold text-slate-400">PHONE VERIFICATION</span>
        <div className="w-8" />
      </div>

      <div className="my-auto py-6 max-w-sm w-full mx-auto space-y-6 text-center">
        {/* Key Round Icon */}
        <div className="w-16 h-16 mx-auto rounded-3xl bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-[#FF5200]">
          <KeyRound size={32} />
        </div>

        <div>
          <h2 className="text-xl font-extrabold text-white tracking-tight">Enter Verification Code</h2>
          <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
            We sent a 4-digit SMS verification code to <br />
            <strong className="text-white font-mono">+91 {phoneForOtpVerification || '98765 43210'}</strong>
          </p>
        </div>

        {/* 4 Discrete Digit Input Boxes */}
        <div className="bg-slate-900 p-6 rounded-3xl border border-slate-800 space-y-5 shadow-xl">
          <div className="flex justify-center gap-3">
            {[0, 1, 2, 3].map((idx) => (
              <input
                key={idx}
                ref={inputRefs[idx]}
                type="text"
                inputMode="numeric"
                maxLength={1}
                value={digits[idx]}
                onChange={(e) => handleDigitChange(idx, e.target.value)}
                onKeyDown={(e) => handleKeyDown(idx, e)}
                className="w-14 h-16 bg-slate-950 border-2 border-slate-800 focus:border-[#FF5200] rounded-2xl text-center text-2xl font-black font-mono text-white focus:outline-none transition shadow-inner"
              />
            ))}
          </div>

          <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800 text-[11px] text-slate-400 flex items-center justify-center gap-1.5">
            <span>Demo Auto-Fill:</span>
            <button
              onClick={() => {
                setDigits(['1', '2', '3', '4']);
                submitOtp('1234');
              }}
              className="text-[#FF5200] font-bold underline ml-1 hover:text-orange-400"
            >
              Fill '1234'
            </button>
          </div>

          {/* Action button */}
          <button
            onClick={() => submitOtp(fullCode)}
            disabled={isLoading || fullCode.length !== 4}
            className="w-full py-3.5 bg-[#FF5200] hover:bg-orange-600 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-orange-950/40"
          >
            {isLoading ? 'Verifying OTP...' : 'Verify & Continue'}
          </button>

          {(localError || error) && (
            <div className="p-2.5 bg-rose-950/80 border border-rose-800 rounded-xl text-rose-300 text-xs flex items-center gap-2 text-left">
              <AlertCircle size={14} className="shrink-0" />
              <span>{localError || error}</span>
            </div>
          )}

          {resendStatus && (
            <p className="text-xs text-emerald-400 font-medium">{resendStatus}</p>
          )}

          {/* Resend Timer */}
          <div className="pt-1 text-xs text-slate-400">
            {canResend ? (
              <button
                onClick={handleResend}
                className="text-[#FF5200] font-bold hover:underline inline-flex items-center gap-1"
              >
                <RotateCw size={12} />
                <span>Resend OTP Code</span>
              </button>
            ) : (
              <span>Resend OTP code in <strong className="text-white font-mono">{countdown}s</strong></span>
            )}
          </div>
        </div>
      </div>

      <div className="text-center text-xs text-slate-400 pb-2">
        Having trouble receiving SMS? <span className="text-slate-300 underline cursor-pointer">Support</span>
      </div>
    </div>
  );
};
