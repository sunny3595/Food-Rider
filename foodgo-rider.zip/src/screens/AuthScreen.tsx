import React from 'react';
import { useAuth } from '../store/authStore';
import { WelcomeScreen } from './auth/WelcomeScreen';
import { LoginScreen } from './auth/LoginScreen';
import { VerifyOtpScreen } from './auth/VerifyOtpScreen';
import { ForgotPasswordScreen } from './auth/ForgotPasswordScreen';
import { RegistrationWizardScreen } from './auth/RegistrationWizardScreen';

export const AuthScreen: React.FC = () => {
  const { currentAuthScreen } = useAuth();

  switch (currentAuthScreen) {
    case 'welcome':
      return <WelcomeScreen />;
    case 'login':
      return <LoginScreen />;
    case 'verify-phone':
      return <VerifyOtpScreen />;
    case 'forgot-password':
      return <ForgotPasswordScreen />;
    case 'register':
      return <RegistrationWizardScreen />;
    default:
      return <WelcomeScreen />;
  }
};
