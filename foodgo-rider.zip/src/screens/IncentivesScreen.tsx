import React, { useState } from 'react';
import {
  Flame,
  Target,
  Trophy,
  Clock,
  CheckCircle,
  ChevronRight,
  Zap,
  Award,
  Crown,
  Calendar,
  Sparkles,
} from 'lucide-react';
import { formatCurrency } from '../utils/formatters';
import { useIncentives } from '../store/incentivesStore';
import { DailyMilestoneCard } from '../components/incentives/DailyMilestoneCard';
import { PeakSurgeTimelineCard } from '../components/incentives/PeakSurgeTimelineCard';
import { RiderTierCard } from '../components/incentives/RiderTierCard';
import { HubLeaderboardCard } from '../components/incentives/HubLeaderboardCard';
import { BadgesGridModal } from '../components/incentives/BadgesGridModal';

export const IncentivesScreen: React.FC = () => {
  const { weekendMarathon, monthlyMilestone } = useIncentives();
  const [isBadgesOpen, setIsBadgesOpen] = useState(false);

  return (
    <div className="flex-1 flex flex-col bg-slate-950 overflow-y-auto pb-10">
      {/* Top Header */}
      <div className="px-5 pt-4 pb-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
        <div>
          <span className="text-[10px] text-orange-400 font-bold uppercase tracking-wider block">
            Bonus & Rewards
          </span>
          <h1 className="text-base font-extrabold text-white">Incentives & Gamification</h1>
        </div>

        <button
          onClick={() => setIsBadgesOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/10 text-amber-300 border border-amber-500/20 rounded-xl text-xs font-bold hover:bg-amber-500/20 transition"
        >
          <Award size={14} />
          <span>Badges (5/7)</span>
        </button>
      </div>

      <div className="p-4 space-y-4">
        {/* Partner Club Tier Showcase */}
        <RiderTierCard />

        {/* Daily Milestone Target Challenge */}
        <DailyMilestoneCard />

        {/* Peak Hours & Surge Windows */}
        <PeakSurgeTimelineCard />

        {/* Weekend Marathon Challenge */}
        <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-3 shadow-lg">
          <div className="flex items-center justify-between pb-1 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
                <Calendar size={16} />
              </div>
              <div>
                <h3 className="text-xs font-bold text-white">Weekend 40-Orders Marathon</h3>
                <span className="text-[10px] text-slate-400">Active Fri 06:00 AM - Sun 11:59 PM</span>
              </div>
            </div>

            <span className="text-xs font-mono font-bold text-emerald-400">
              +{formatCurrency(weekendMarathon.rewardAmount)}
            </span>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-300">
                Completed: {weekendMarathon.current} / {weekendMarathon.target} Trips
              </span>
              <span className="text-purple-400 font-bold">
                {Math.round((weekendMarathon.current / weekendMarathon.target) * 100)}%
              </span>
            </div>
            <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-purple-500 to-indigo-400 rounded-full"
                style={{
                  width: `${(weekendMarathon.current / weekendMarathon.target) * 100}%`,
                }}
              />
            </div>
            <p className="text-[10px] text-slate-400">
              Complete {weekendMarathon.target - weekendMarathon.current} more deliveries this weekend to unlock ₹1,200 direct cash.
            </p>
          </div>
        </div>

        {/* Monthly 300-Orders Milestone */}
        <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-3 shadow-lg">
          <div className="flex items-center justify-between pb-1 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <Sparkles size={16} />
              </div>
              <div>
                <h3 className="text-xs font-bold text-white">Monthly Star Partner Bonus</h3>
                <span className="text-[10px] text-slate-400">Target: 300 Orders in October</span>
              </div>
            </div>

            <span className="text-xs font-mono font-bold text-emerald-400">
              +{formatCurrency(monthlyMilestone.rewardAmount)}
            </span>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-300">
                Progress: {monthlyMilestone.current} / {monthlyMilestone.target} Orders
              </span>
              <span className="text-emerald-400 font-bold">
                {Math.round((monthlyMilestone.current / monthlyMilestone.target) * 100)}%
              </span>
            </div>
            <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full"
                style={{
                  width: `${(monthlyMilestone.current / monthlyMilestone.target) * 100}%`,
                }}
              />
            </div>
            <p className="text-[10px] text-slate-400">
              52 more deliveries before month end to claim ₹5,000 partner reward.
            </p>
          </div>
        </div>

        {/* Hub Weekly Leaderboard */}
        <HubLeaderboardCard />
      </div>

      {/* Badges Modal */}
      {isBadgesOpen && <BadgesGridModal onClose={() => setIsBadgesOpen(false)} />}
    </div>
  );
};
