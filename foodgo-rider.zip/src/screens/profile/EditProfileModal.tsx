import React, { useState } from 'react';
import { X, Check, Camera, User, Phone, Mail, MapPin, CheckCircle2 } from 'lucide-react';
import { useRider } from '../../store/riderStore';

interface EditProfileModalProps {
  onClose: () => void;
}

export const EditProfileModal: React.FC<EditProfileModalProps> = ({ onClose }) => {
  const { profile } = useRider();
  const [fullName, setFullName] = useState(profile.fullName);
  const [phone, setPhone] = useState(profile.phone);
  const [email, setEmail] = useState(profile.email);
  const [street, setStreet] = useState(profile.address?.street || '12th Main Rd, HAL 2nd Stage');
  const [city, setCity] = useState(profile.address?.city || 'Bengaluru');
  const [avatarUrl, setAvatarUrl] = useState(profile.avatarUrl);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const avatarPresets = [
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=250&q=80',
    'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=250&q=80',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=250&q=80',
  ];

  const handleSave = () => {
    profile.fullName = fullName;
    profile.email = email;
    profile.phone = phone;
    if (profile.address) {
      profile.address.street = street;
      profile.address.city = city;
    }
    if (avatarUrl) {
      profile.avatarUrl = avatarUrl;
    }

    setSavedSuccess(true);
    setTimeout(() => {
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm max-h-[90vh] bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-bold text-white">Edit Partner Profile</h3>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-4 overflow-y-auto space-y-4">
          {/* Avatar Selector */}
          <div className="text-center space-y-2">
            <img
              src={avatarUrl}
              alt="Avatar"
              className="w-20 h-20 rounded-full mx-auto object-cover border-2 border-[#FF5200] shadow-md"
            />
            <span className="text-[11px] text-slate-400 block font-medium">Choose Profile Avatar</span>
            <div className="flex justify-center gap-2">
              {avatarPresets.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => setAvatarUrl(preset)}
                  className={`w-10 h-10 rounded-full overflow-hidden border-2 transition ${
                    avatarUrl === preset ? 'border-[#FF5200] scale-110' : 'border-slate-800 opacity-60'
                  }`}
                >
                  <img src={preset} alt={`Preset ${idx}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3 bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800">
            <div>
              <label className="text-[11px] font-bold text-slate-400 block mb-1">Full Name</label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-400 block mb-1">Phone Number</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#FF5200]"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-400 block mb-1">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-400 block mb-1">Operating Street Address</label>
              <input
                type="text"
                value={street}
                onChange={(e) => setStreet(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-400 block mb-1">City</label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
              />
            </div>
          </div>

          {savedSuccess && (
            <div className="p-3 bg-emerald-950/80 border border-emerald-500/40 rounded-xl flex items-center justify-center gap-2 text-emerald-300 text-xs font-bold">
              <CheckCircle2 size={16} />
              <span>Profile Details Updated Successfully</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex gap-2">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex-1 py-2.5 bg-[#FF5200] hover:bg-orange-600 text-white rounded-xl text-xs font-bold transition shadow-md shadow-orange-950/40"
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};
