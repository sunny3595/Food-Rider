import React, { useState } from 'react';
import {
  X,
  FileCheck2,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Upload,
  Camera,
  ChevronRight,
  Eye,
} from 'lucide-react';
import { MOCK_DOCUMENTS } from '../../api/mockData';
import { RiderDocument } from '../../types/rider.types';

interface DocumentManagementModalProps {
  onClose: () => void;
}

export const DocumentManagementModal: React.FC<DocumentManagementModalProps> = ({ onClose }) => {
  const [documents, setDocuments] = useState<RiderDocument[]>(MOCK_DOCUMENTS);
  const [selectedDoc, setSelectedDoc] = useState<RiderDocument | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const handleUploadNewFile = () => {
    if (!selectedDoc) return;
    setIsUploading(true);
    setUploadProgress(15);

    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsUploading(false);
          // Mark doc as PENDING review
          setDocuments((prevDocs) =>
            prevDocs.map((d) =>
              d.id === selectedDoc.id
                ? {
                    ...d,
                    status: 'PENDING',
                    uploadedAt: new Date().toISOString().split('T')[0],
                  }
                : d
            )
          );
          setSelectedDoc(null);
          return 100;
        }
        return prev + 25;
      });
    }, 200);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm max-h-[90vh] bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileCheck2 size={18} className="text-emerald-400" />
            <h3 className="text-sm font-bold text-white">Compliance Documents</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* List of Documents */}
        <div className="p-4 overflow-y-auto space-y-3">
          <div className="bg-emerald-950/40 border border-emerald-500/30 p-3 rounded-2xl flex items-center gap-2.5">
            <CheckCircle2 size={18} className="text-emerald-400 shrink-0" />
            <p className="text-[11px] text-emerald-200">
              All 5 required documents are verified and compliant with local motor vehicle guidelines.
            </p>
          </div>

          <div className="space-y-2.5">
            {documents.map((doc) => (
              <div
                key={doc.id}
                onClick={() => setSelectedDoc(doc)}
                className="p-3 bg-slate-950/80 hover:bg-slate-950 rounded-2xl border border-slate-800 cursor-pointer transition flex items-center justify-between group"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs font-bold text-white group-hover:text-[#FF5200] transition">
                      {doc.title}
                    </h4>
                    <span
                      className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase ${
                        doc.status === 'VERIFIED'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : doc.status === 'PENDING'
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                      }`}
                    >
                      {doc.status}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                    {doc.documentNumber}
                    {doc.expiryDate && ` • Expires ${doc.expiryDate}`}
                  </p>
                </div>

                <div className="flex items-center gap-1 text-slate-400 group-hover:text-white">
                  <span className="text-[10px] font-medium">Re-upload</span>
                  <ChevronRight size={14} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Document Detail / Re-Upload Drawer Modal */}
        {selectedDoc && (
          <div className="fixed inset-0 bg-black/85 backdrop-blur-xs z-60 flex items-end sm:items-center justify-center p-3 animate-fadeIn">
            <div className="w-full max-w-xs bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white">{selectedDoc.title}</h4>
                <button
                  onClick={() => setSelectedDoc(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 text-xs text-slate-300 space-y-1 font-mono">
                <p>Status: <span className="text-emerald-400 font-bold">{selectedDoc.status}</span></p>
                <p>Number: <span className="text-white">{selectedDoc.documentNumber}</span></p>
                {selectedDoc.expiryDate && <p>Expires: <span className="text-white">{selectedDoc.expiryDate}</span></p>}
              </div>

              {isUploading ? (
                <div className="space-y-2 py-2">
                  <div className="flex justify-between text-xs text-slate-300">
                    <span>Uploading scan...</span>
                    <span className="font-mono text-orange-400">{uploadProgress}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#FF5200] transition-all duration-200"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <button
                    onClick={handleUploadNewFile}
                    className="w-full py-3 bg-[#FF5200] hover:bg-orange-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-md"
                  >
                    <Upload size={14} />
                    <span>Upload New Photo / PDF Scan</span>
                  </button>

                  <button
                    onClick={() => setSelectedDoc(null)}
                    className="w-full py-2.5 text-xs text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800">
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
