import React from 'react';
import { X, Star, Award, TrendingUp, CheckCircle, Flame, Shield, ThumbsUp } from 'lucide-react';
import { useRider } from '../../store/riderStore';

interface PerformanceRatingModalProps {
  onClose: () => void;
}

export const PerformanceRatingModal: React.FC<PerformanceRatingModalProps> = ({ onClose }) => {
  const { profile } = useRider();
  const perf = profile.performance;

  const ratingBars = [
    { stars: '5 Star', pct: perf.ratingDistribution.fiveStar, count: 1048 },
    { stars: '4 Star', pct: perf.ratingDistribution.fourStar, count: 150 },
    { stars: '3 Star', pct: perf.ratingDistribution.threeStar, count: 37 },
    { stars: '2 Star', pct: perf.ratingDistribution.twoStar, count: 12 },
    { stars: '1 Star', pct: perf.ratingDistribution.oneStar, count: 1 },
  ];

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm max-h-[90vh] bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award size={18} className="text-amber-400" />
            <h3 className="text-sm font-bold text-white">Partner Performance & Rating</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 overflow-y-auto space-y-4">
          {/* Rating Hero Card */}
          <div className="bg-gradient-to-br from-amber-950/40 via-slate-950 to-slate-950 p-5 rounded-3xl border border-amber-500/30 text-center space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold">
              <Star size={13} fill="currentColor" />
              <span>PLATINUM RIDER TIER</span>
            </div>

            <div className="flex items-center justify-center gap-2">
              <span className="text-4xl font-black text-white font-mono tracking-tight">
                {perf.averageRating}
              </span>
              <div className="flex text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={16} fill="currentColor" />
                ))}
              </div>
            </div>

            <p className="text-xs text-slate-400">
              Based on customer ratings across <strong className="text-white">{perf.totalDeliveriesCompleted}</strong> completed deliveries
            </p>
          </div>

          {/* Star Distribution Bars */}
          <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-2">
            <span className="text-xs font-bold text-white uppercase tracking-wider block">
              Customer Rating Distribution
            </span>

            <div className="space-y-1.5 pt-1">
              {ratingBars.map((bar) => (
                <div key={bar.stars} className="flex items-center gap-2 text-xs">
                  <span className="w-12 text-slate-400 text-[11px] font-medium">{bar.stars}</span>
                  <div className="flex-1 bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-amber-400 rounded-full"
                      style={{ width: `${bar.pct}%` }}
                    />
                  </div>
                  <span className="w-8 text-right font-mono text-slate-300 text-[11px] font-bold">
                    {bar.pct}%
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Operational Efficiency Metrics Grid */}
          <div className="grid grid-cols-2 gap-2.5">
            <div className="bg-slate-950/80 p-3 rounded-2xl border border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">Acceptance Rate</span>
              <span className="text-lg font-black text-white font-mono">{perf.acceptanceRate}%</span>
              <span className="text-[10px] text-emerald-400 block font-medium">Top 5% of fleet</span>
            </div>

            <div className="bg-slate-950/80 p-3 rounded-2xl border border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">Completion Rate</span>
              <span className="text-lg font-black text-emerald-400 font-mono">{perf.completionRate}%</span>
              <span className="text-[10px] text-emerald-400 block font-medium">Near zero cancellations</span>
            </div>

            <div className="bg-slate-950/80 p-3 rounded-2xl border border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">On-Time Arrival</span>
              <span className="text-lg font-black text-white font-mono">{perf.onTimeRate}%</span>
              <span className="text-[10px] text-slate-400 block">Avg delay &lt; 2 mins</span>
            </div>

            <div className="bg-slate-950/80 p-3 rounded-2xl border border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">Total Deliveries</span>
              <span className="text-lg font-black text-orange-400 font-mono">{perf.totalDeliveriesCompleted}</span>
              <span className="text-[10px] text-slate-400 block">Lifetime orders</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800">
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
