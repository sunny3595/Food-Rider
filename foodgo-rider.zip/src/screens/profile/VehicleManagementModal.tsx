import React, { useState } from 'react';
import { X, Bike, ShieldCheck, Calendar, FileText, CheckCircle2 } from 'lucide-react';
import { useRider } from '../../store/riderStore';
import { VehicleType } from '../../types/rider.types';

interface VehicleManagementModalProps {
  onClose: () => void;
}

export const VehicleManagementModal: React.FC<VehicleManagementModalProps> = ({ onClose }) => {
  const { profile } = useRider();
  const [vehicleType, setVehicleType] = useState<VehicleType>(profile.vehicle.type);
  const [regNumber, setRegNumber] = useState(profile.vehicle.registrationNumber);
  const [makeModel, setMakeModel] = useState(profile.vehicle.makeModel);
  const [color, setColor] = useState(profile.vehicle.color);
  const [updatedSuccess, setUpdatedSuccess] = useState(false);

  const handleSave = () => {
    profile.vehicle.type = vehicleType;
    profile.vehicle.registrationNumber = regNumber;
    profile.vehicle.makeModel = makeModel;
    profile.vehicle.color = color;
    setUpdatedSuccess(true);
    setTimeout(() => {
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm max-h-[90vh] bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bike size={18} className="text-[#FF5200]" />
            <h3 className="text-sm font-bold text-white">Vehicle Management</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 overflow-y-auto space-y-4">
          {/* Active Vehicle Card */}
          <div className="bg-gradient-to-br from-slate-950 via-slate-950 to-orange-950/20 p-4 rounded-2xl border border-slate-800 space-y-2">
            <span className="text-[10px] font-bold text-orange-400 uppercase tracking-wider block">
              Active Registered Vehicle
            </span>
            <div className="flex items-baseline justify-between">
              <h4 className="text-base font-black text-white">{profile.vehicle.makeModel}</h4>
              <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                {profile.vehicle.registrationNumber}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Type: {profile.vehicle.type} • Color: {profile.vehicle.color}
            </p>
          </div>

          {/* Compliance & Expiry Tracker */}
          <div className="space-y-2 bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800">
            <span className="text-xs font-bold text-white uppercase tracking-wider block">
              Document Validity & Compliance
            </span>

            <div className="flex items-center justify-between text-xs py-1.5 border-b border-slate-800/80">
              <div className="flex items-center gap-2">
                <ShieldCheck size={14} className="text-emerald-400" />
                <span className="text-slate-300">Vehicle Insurance</span>
              </div>
              <span className="text-emerald-400 font-mono text-[11px] font-bold">Valid till Aug 2027</span>
            </div>

            <div className="flex items-center justify-between text-xs py-1.5 border-b border-slate-800/80">
              <div className="flex items-center gap-2">
                <FileText size={14} className="text-emerald-400" />
                <span className="text-slate-300">Registration Smart Card (RC)</span>
              </div>
              <span className="text-emerald-400 font-mono text-[11px] font-bold">Verified (Lifetime)</span>
            </div>

            <div className="flex items-center justify-between text-xs py-1.5">
              <div className="flex items-center gap-2">
                <Calendar size={14} className="text-emerald-400" />
                <span className="text-slate-300">Emission / PUC Status</span>
              </div>
              <span className="text-emerald-400 font-mono text-[11px] font-bold">Active</span>
            </div>
          </div>

          {/* Edit Form */}
          <div className="space-y-3 bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
              Update Vehicle Information
            </span>

            <div>
              <label className="text-[11px] font-bold text-slate-400 block mb-1">Vehicle Type</label>
              <select
                value={vehicleType}
                onChange={(e) => setVehicleType(e.target.value as VehicleType)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
              >
                <option value="MOTORCYCLE">Motorcycle / Petrol Bike</option>
                <option value="SCOOTER">Scooter / Scooty</option>
                <option value="ELECTRIC_VEHICLE">Electric Two-Wheeler (EV)</option>
                <option value="BICYCLE">Bicycle (Eco Delivery)</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-400 block mb-1">Registration Plate Number</label>
              <input
                type="text"
                value={regNumber}
                onChange={(e) => setRegNumber(e.target.value.toUpperCase())}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono uppercase focus:outline-none focus:border-[#FF5200]"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] font-bold text-slate-400 block mb-1">Make & Model</label>
                <input
                  type="text"
                  value={makeModel}
                  onChange={(e) => setMakeModel(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-400 block mb-1">Color</label>
                <input
                  type="text"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                />
              </div>
            </div>
          </div>

          {updatedSuccess && (
            <div className="p-3 bg-emerald-950/80 border border-emerald-500/40 rounded-xl flex items-center justify-center gap-2 text-emerald-300 text-xs font-bold">
              <CheckCircle2 size={16} />
              <span>Vehicle Details Updated</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex gap-2">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex-1 py-2.5 bg-[#FF5200] hover:bg-orange-600 text-white rounded-xl text-xs font-bold transition shadow-md shadow-orange-950/40"
          >
            Save Vehicle
          </button>
        </div>
      </div>
    </div>
  );
};
