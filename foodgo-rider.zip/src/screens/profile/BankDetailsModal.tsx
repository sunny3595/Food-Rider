import React, { useState } from 'react';
import { X, Building, ShieldCheck, CheckCircle2, AlertCircle } from 'lucide-react';
import { useRider } from '../../store/riderStore';
import { ifscSchema } from '../../validation/auth.validation';

interface BankDetailsModalProps {
  onClose: () => void;
}

export const BankDetailsModal: React.FC<BankDetailsModalProps> = ({ onClose }) => {
  const { profile } = useRider();
  const [bankName, setBankName] = useState(profile.bankAccount?.bankName || 'HDFC Bank Ltd');
  const [accountHolder, setAccountHolder] = useState(profile.bankAccount?.accountHolderName || profile.fullName);
  const [accNum, setAccNum] = useState('');
  const [confirmAccNum, setConfirmAccNum] = useState('');
  const [ifsc, setIfsc] = useState(profile.bankAccount?.ifscCode || 'HDFC0001244');
  const [upi, setUpi] = useState(profile.bankAccount?.upiId || 'dhanush@okaxis');
  const [isEditing, setIsEditing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleUpdate = () => {
    setErrorMsg(null);
    if (!accNum || accNum.length < 9) {
      setErrorMsg('Please enter a valid bank account number');
      return;
    }
    if (accNum !== confirmAccNum) {
      setErrorMsg('Account numbers do not match');
      return;
    }
    const ifscCheck = ifscSchema.safeParse(ifsc);
    if (!ifscCheck.success) {
      setErrorMsg('Invalid IFSC code format (e.g. HDFC0001244)');
      return;
    }

    if (profile.bankAccount) {
      profile.bankAccount.bankName = bankName;
      profile.bankAccount.accountHolderName = accountHolder;
      profile.bankAccount.accountNumberMasked = `••••••••${accNum.slice(-4)}`;
      profile.bankAccount.ifscCode = ifsc.toUpperCase();
      profile.bankAccount.upiId = upi;
    }

    setSuccessMsg('Bank account details updated successfully');
    setTimeout(() => {
      setIsEditing(false);
      setSuccessMsg(null);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm max-h-[90vh] bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building size={18} className="text-emerald-400" />
            <h3 className="text-sm font-bold text-white">Bank Account & UPI</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 overflow-y-auto space-y-4">
          {/* Current Verified Bank Card */}
          <div className="bg-gradient-to-br from-slate-950 via-slate-950 to-emerald-950/20 p-4 rounded-2xl border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
                Primary Payout Method
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                <ShieldCheck size={11} />
                <span>Verified</span>
              </span>
            </div>

            <div>
              <h4 className="text-base font-bold text-white">{profile.bankAccount?.bankName}</h4>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                A/C: {profile.bankAccount?.accountNumberMasked}
              </p>
              <p className="text-xs text-slate-400 font-mono">
                IFSC: {profile.bankAccount?.ifscCode}
              </p>
              {profile.bankAccount?.upiId && (
                <p className="text-xs text-slate-400 font-mono mt-0.5">
                  UPI: {profile.bankAccount.upiId}
                </p>
              )}
            </div>
          </div>

          {!isEditing ? (
            <button
              onClick={() => setIsEditing(true)}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold border border-slate-700 transition"
            >
              Change Bank Account Details
            </button>
          ) : (
            <div className="space-y-3 bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800 animate-fadeIn">
              <span className="text-xs font-bold text-white uppercase tracking-wider block">
                Update Bank Account
              </span>

              <div>
                <label className="text-[11px] font-bold text-slate-400 block mb-1">Bank Name</label>
                <input
                  type="text"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-400 block mb-1">New Account Number</label>
                <input
                  type="password"
                  value={accNum}
                  onChange={(e) => setAccNum(e.target.value.replace(/\D/g, ''))}
                  placeholder="Enter full account number"
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#FF5200]"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-400 block mb-1">Confirm Account Number</label>
                <input
                  type="text"
                  value={confirmAccNum}
                  onChange={(e) => setConfirmAccNum(e.target.value.replace(/\D/g, ''))}
                  placeholder="Re-enter account number"
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#FF5200]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-400 block mb-1">IFSC Code</label>
                  <input
                    type="text"
                    maxLength={11}
                    value={ifsc}
                    onChange={(e) => setIfsc(e.target.value.toUpperCase())}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono uppercase focus:outline-none focus:border-[#FF5200]"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-400 block mb-1">UPI ID</label>
                  <input
                    type="text"
                    value={upi}
                    onChange={(e) => setUpi(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF5200]"
                  />
                </div>
              </div>

              {errorMsg && (
                <div className="p-2 bg-rose-950/80 border border-rose-800 rounded-xl text-rose-300 text-xs flex items-center gap-1.5">
                  <AlertCircle size={14} className="shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {successMsg && (
                <div className="p-2 bg-emerald-950/80 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="shrink-0" />
                  <span>{successMsg}</span>
                </div>
              )}

              <div className="flex gap-2 pt-1">
                <button
                  onClick={() => setIsEditing(false)}
                  className="flex-1 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  onClick={handleUpdate}
                  className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow"
                >
                  Save Account
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800">
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
