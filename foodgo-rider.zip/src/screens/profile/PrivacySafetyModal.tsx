import React, { useState } from 'react';
import {
  X,
  Shield,
  MapPin,
  Lock,
  Trash2,
  AlertTriangle,
  ExternalLink,
  CheckCircle2,
} from 'lucide-react';
import { APP_CONFIG } from '../../constants/config';
import { useAuth } from '../../store/authStore';

interface PrivacySafetyModalProps {
  onClose: () => void;
}

export const PrivacySafetyModal: React.FC<PrivacySafetyModalProps> = ({ onClose }) => {
  const { logout } = useAuth();
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteReason, setDeleteReason] = useState('Found full-time employment');
  const [confirmDeleteText, setConfirmDeleteText] = useState('');

  const handleDeleteAccount = async () => {
    if (confirmDeleteText !== 'DELETE') return;
    await logout();
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fadeIn">
      <div className="w-full max-w-sm max-h-[90vh] bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield size={18} className="text-sky-400" />
            <h3 className="text-sm font-bold text-white">Privacy & Legal Disclosures</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 overflow-y-auto space-y-4">
          {/* Location Privacy Guarantee Card */}
          <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-2.5">
            <div className="flex items-center gap-2 text-sky-400 text-xs font-bold uppercase tracking-wider">
              <MapPin size={15} />
              <span>Location Privacy Architecture</span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              We respect your personal privacy. GPS tracking operates strictly under these rules:
            </p>

            <ul className="space-y-1.5 text-xs text-slate-400">
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-400 font-bold">•</span>
                <span><strong className="text-white">When tracking runs:</strong> Only while your duty toggle is ONLINE and actively delivering.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-400 font-bold">•</span>
                <span><strong className="text-white">When tracking stops:</strong> Immediately when you switch to OFFLINE or complete an order.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-400 font-bold">•</span>
                <span><strong className="text-white">Customer visibility:</strong> Customers only see your approximate location while you are en route with their order.</span>
              </li>
            </ul>
          </div>

          {/* Legal Documents Links */}
          <div className="bg-slate-950/80 p-3 rounded-2xl border border-slate-800 space-y-2">
            <a
              href={APP_CONFIG.support.termsUrl}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-between text-xs text-slate-300 hover:text-white p-2 hover:bg-slate-900 rounded-xl transition"
            >
              <span>Partner Terms of Service</span>
              <ExternalLink size={13} className="text-slate-400" />
            </a>

            <a
              href={APP_CONFIG.support.privacyUrl}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-between text-xs text-slate-300 hover:text-white p-2 hover:bg-slate-900 rounded-xl transition"
            >
              <span>Rider Privacy Policy</span>
              <ExternalLink size={13} className="text-slate-400" />
            </a>
          </div>

          {/* Danger Zone: Account Deletion */}
          <div className="bg-rose-950/20 border border-rose-900/40 p-3.5 rounded-2xl space-y-2">
            <span className="text-xs font-bold text-rose-400 uppercase tracking-wider block">
              Danger Zone
            </span>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Permanently delete your rider profile and forfeit remaining unwithdrawn earnings.
            </p>
            <button
              onClick={() => setIsDeleteModalOpen(true)}
              className="w-full py-2 bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-800 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition"
            >
              <Trash2 size={13} />
              <span>Request Account Deletion</span>
            </button>
          </div>
        </div>

        {/* Delete Confirmation Modal */}
        {isDeleteModalOpen && (
          <div className="fixed inset-0 bg-black/90 backdrop-blur-xs z-60 flex items-center justify-center p-3 animate-fadeIn">
            <div className="w-full max-w-xs bg-slate-900 border border-rose-500/50 rounded-3xl p-5 shadow-2xl space-y-3.5 text-center">
              <div className="w-12 h-12 rounded-full bg-rose-500/10 text-rose-500 mx-auto flex items-center justify-center">
                <AlertTriangle size={24} />
              </div>
              <h4 className="text-sm font-bold text-white">Delete Partner Account?</h4>
              <p className="text-xs text-slate-400">
                This action is permanent and cannot be undone. Type <strong className="text-rose-400 font-mono">DELETE</strong> below to confirm.
              </p>

              <input
                type="text"
                value={confirmDeleteText}
                onChange={(e) => setConfirmDeleteText(e.target.value)}
                placeholder="Type DELETE"
                className="w-full bg-slate-950 border border-rose-800 rounded-xl p-2 text-center text-xs font-mono font-bold text-white focus:outline-none"
              />

              <div className="flex gap-2 pt-1">
                <button
                  onClick={() => setIsDeleteModalOpen(false)}
                  className="flex-1 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  onClick={handleDeleteAccount}
                  disabled={confirmDeleteText !== 'DELETE'}
                  className="flex-1 py-2 bg-rose-600 disabled:opacity-40 hover:bg-rose-500 text-white rounded-xl text-xs font-bold shadow"
                >
                  Confirm Delete
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800">
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
