import React, { useState } from 'react';
import {
  Store,
  User,
  Navigation,
  Phone,
  MessageSquare,
  CheckCircle,
  AlertTriangle,
  KeyRound,
  ShieldCheck,
  IndianRupee,
  MapPin,
  ExternalLink,
  ChevronLeft,
  Banknote,
  Camera,
  Layers,
  Sparkles,
  ShieldAlert,
} from 'lucide-react';
import { useDelivery } from '../store/deliveryStore';
import { formatCurrency, formatDistance } from '../utils/formatters';
import { ActiveDeliveryMap } from '../components/delivery/ActiveDeliveryMap';
import { ItemChecklistModal } from '../components/delivery/ItemChecklistModal';
import { CodChangeCalculatorModal } from '../components/delivery/CodChangeCalculatorModal';
import { CustomerUnreachableModal } from '../components/delivery/CustomerUnreachableModal';
import { RestaurantWaitTimerCard } from '../components/delivery/RestaurantWaitTimerCard';
import { ReportDelayModal } from '../components/delivery/ReportDelayModal';
import { ProofOfDeliveryModal } from '../components/delivery/ProofOfDeliveryModal';
import { EmergencySosModal } from '../components/safety/EmergencySosModal';
import { OrderCompletionSummaryModal } from './delivery/OrderCompletionSummaryModal';

interface DeliveriesScreenProps {
  onBackToHome: () => void;
  onOpenChat: () => void;
}

export const DeliveriesScreen: React.FC<DeliveriesScreenProps> = ({ onBackToHome, onOpenChat }) => {
  const {
    activeDelivery,
    advanceDeliveryStatus,
    verifyOtpAndComplete,
    collectCodPayment,
    clearActiveDelivery,
    isProcessing,
    error,
  } = useDelivery();

  const [otpInput, setOtpInput] = useState('');
  const [otpError, setOtpError] = useState<string | null>(null);

  // Modals state
  const [isChecklistOpen, setIsChecklistOpen] = useState(false);
  const [isCodModalOpen, setIsCodModalOpen] = useState(false);
  const [isUnreachableOpen, setIsUnreachableOpen] = useState(false);
  const [isDelayModalOpen, setIsDelayModalOpen] = useState(false);
  const [isProofModalOpen, setIsProofModalOpen] = useState(false);
  const [isSummaryOpen, setIsSummaryOpen] = useState(false);
  const [isSosOpen, setIsSosOpen] = useState(false);

  if (!activeDelivery) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-6 text-center bg-slate-950">
        <div className="w-16 h-16 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500 mb-4">
          <Navigation size={28} />
        </div>
        <h3 className="text-base font-bold text-white mb-1">No Active Delivery</h3>
        <p className="text-xs text-slate-400 mb-5 max-w-xs">
          You do not have any delivery order in progress right now. Return to Home to receive requests.
        </p>
        <button
          onClick={onBackToHome}
          className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition"
        >
          Back to Dashboard
        </button>
      </div>
    );
  }

  const isDelivered = activeDelivery.status === 'DELIVERED';
  const isCod = activeDelivery.paymentMethod === 'CASH_ON_DELIVERY';
  const isCodCollected = activeDelivery.financials.isCashCollected;

  const handleVerifyOtp = async () => {
    if (otpInput.length !== 4) {
      setOtpError('Please enter a 4-digit customer delivery OTP');
      return;
    }
    setOtpError(null);
    try {
      await verifyOtpAndComplete(otpInput);
      setOtpInput('');
      setIsSummaryOpen(true);
    } catch (err: any) {
      setOtpError(err.message || 'Verification failed');
    }
  };

  const handleOpenMaps = (lat: number, lng: number) => {
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, '_blank');
  };

  const handleCall = (phone: string) => {
    window.location.href = `tel:${phone}`;
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 overflow-y-auto pb-10">
      {/* Top Header */}
      <div className="sticky top-0 bg-slate-900/90 backdrop-blur px-4 py-3 border-b border-slate-800 flex items-center justify-between z-20">
        <button
          onClick={onBackToHome}
          className="flex items-center gap-1 text-xs text-slate-300 hover:text-white"
        >
          <ChevronLeft size={16} />
          <span>Back</span>
        </button>

        <div className="text-center">
          <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-mono">
            {activeDelivery.status.replace(/_/g, ' ')}
          </span>
          <span className="text-xs font-bold text-white font-mono">
            {activeDelivery.orderNumber}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-emerald-400 font-mono">
            {formatCurrency(activeDelivery.financials.totalEarnings)}
          </span>
          <button
            onClick={() => setIsSosOpen(true)}
            className="w-7 h-7 rounded-full bg-rose-950/80 text-rose-400 border border-rose-800/60 flex items-center justify-center hover:bg-rose-900 transition"
            title="Emergency SOS"
          >
            <ShieldAlert size={14} />
          </button>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Real-time Map Visualizer */}
        <ActiveDeliveryMap />

        {/* Step Progression Status Bar */}
        <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-3 shadow-lg">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-white uppercase tracking-wider">Current Stage</span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#FF5200]/20 text-orange-400 border border-orange-500/30 font-mono">
              {activeDelivery.status}
            </span>
          </div>

          {/* If at restaurant: Show Kitchen Wait Timer Card */}
          {activeDelivery.status === 'ARRIVED_AT_RESTAURANT' && (
            <RestaurantWaitTimerCard
              restaurantName={activeDelivery.restaurant.name}
              isOrderReady={activeDelivery.restaurant.isOrderReady}
            />
          )}

          {/* Action Trigger for Next Stage */}
          <div className="pt-1">
            {activeDelivery.status === 'ASSIGNED' && (
              <button
                onClick={() => advanceDeliveryStatus('GOING_TO_RESTAURANT')}
                disabled={isProcessing}
                className="w-full py-3 bg-[#FF5200] hover:bg-orange-600 text-white rounded-2xl text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-orange-950/50"
              >
                <Navigation size={14} />
                <span>START TRIP TO RESTAURANT</span>
              </button>
            )}

            {activeDelivery.status === 'GOING_TO_RESTAURANT' && (
              <div className="space-y-2">
                <button
                  onClick={() => advanceDeliveryStatus('ARRIVED_AT_RESTAURANT')}
                  disabled={isProcessing}
                  className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/50"
                >
                  <MapPin size={15} />
                  <span>ARRIVED AT RESTAURANT (STORE COUNTER)</span>
                </button>

                <button
                  onClick={() => setIsDelayModalOpen(true)}
                  className="w-full py-2 text-xs text-amber-400 hover:text-amber-300 font-semibold"
                >
                  Report Traffic / Weather Delay
                </button>
              </div>
            )}

            {activeDelivery.status === 'ARRIVED_AT_RESTAURANT' && (
              <button
                onClick={() => setIsChecklistOpen(true)}
                className="w-full py-3.5 bg-gradient-to-r from-[#FF5200] to-orange-600 hover:brightness-110 text-white rounded-2xl text-xs font-bold flex items-center justify-center gap-2 shadow-xl shadow-orange-950/50"
              >
                <Store size={15} />
                <span>VERIFY ITEMS & COLLECT ORDER (PK-82)</span>
              </button>
            )}

            {(activeDelivery.status === 'ORDER_PICKED_UP' || activeDelivery.status === 'GOING_TO_CUSTOMER') && (
              <div className="space-y-2">
                <button
                  onClick={() => advanceDeliveryStatus('ARRIVED_AT_CUSTOMER')}
                  disabled={isProcessing}
                  className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl text-xs font-bold flex items-center justify-center gap-2 shadow-xl shadow-emerald-950/50"
                >
                  <MapPin size={15} />
                  <span>ARRIVED AT CUSTOMER DOORSTEP</span>
                </button>

                <button
                  onClick={() => setIsDelayModalOpen(true)}
                  className="w-full py-2 text-xs text-amber-400 hover:text-amber-300 font-semibold"
                >
                  Report Traffic / Weather Delay
                </button>
              </div>
            )}

            {activeDelivery.status === 'ARRIVED_AT_CUSTOMER' && (
              <div className="space-y-2.5">
                {/* Contactless Photo Proof Option */}
                <button
                  onClick={() => setIsProofModalOpen(true)}
                  className="w-full py-3 bg-sky-600 hover:bg-sky-500 text-white rounded-2xl text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-sky-950/50"
                >
                  <Camera size={15} />
                  <span>CAPTURE CONTACTLESS PHOTO PROOF</span>
                </button>

                {/* Customer Delivery OTP Form */}
                <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      <KeyRound size={13} className="text-amber-400" />
                      <span>Customer 4-Digit Delivery OTP</span>
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">Ask Customer</span>
                  </div>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      maxLength={4}
                      value={otpInput}
                      onChange={(e) => setOtpInput(e.target.value.replace(/\D/g, ''))}
                      placeholder="Hint: 4829"
                      className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-center font-mono font-bold tracking-widest text-white focus:outline-none focus:border-[#FF5200]"
                    />

                    <button
                      onClick={handleVerifyOtp}
                      disabled={otpInput.length !== 4 || isProcessing}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white rounded-xl text-xs font-bold transition shadow"
                    >
                      Verify OTP
                    </button>
                  </div>

                  {otpError && (
                    <p className="text-[11px] text-rose-400 font-semibold">{otpError}</p>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Restaurant Card */}
        <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-3 shadow-lg">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Store size={16} className="text-[#FF5200]" />
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Restaurant Pickup
              </span>
            </div>
            <span className="text-xs font-mono font-bold text-orange-400">
              {activeDelivery.pickupCode || 'PK-82'}
            </span>
          </div>

          <div>
            <h4 className="text-sm font-bold text-white">{activeDelivery.restaurant.name}</h4>
            <p className="text-xs text-slate-400 mt-0.5">{activeDelivery.restaurant.location.address}</p>
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={() =>
                handleOpenMaps(
                  activeDelivery.restaurant.location.latitude,
                  activeDelivery.restaurant.location.longitude
                )
              }
              className="flex-1 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition border border-slate-700"
            >
              <Navigation size={13} className="text-[#FF5200]" />
              <span>Navigate</span>
            </button>

            <button
              onClick={() => handleCall(activeDelivery.restaurant.phone)}
              className="p-2 bg-slate-800 hover:bg-slate-750 text-emerald-400 rounded-xl transition border border-slate-700"
              title="Call Restaurant"
            >
              <Phone size={15} />
            </button>

            <button
              onClick={onOpenChat}
              className="p-2 bg-slate-800 hover:bg-slate-750 text-sky-400 rounded-xl transition border border-slate-700"
              title="Chat"
            >
              <MessageSquare size={15} />
            </button>
          </div>
        </div>

        {/* Customer Delivery Card */}
        <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-3 shadow-lg">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <User size={16} className="text-emerald-400" />
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Customer Dropoff
              </span>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-400">
              {activeDelivery.customer.name}
            </span>
          </div>

          <div>
            <p className="text-xs text-slate-300 font-medium">{activeDelivery.customer.location.address}</p>
            {activeDelivery.customer.deliveryNotes && (
              <div className="mt-2 p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-amber-300 italic">
                Note: "{activeDelivery.customer.deliveryNotes}"
              </div>
            )}
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={() =>
                handleOpenMaps(
                  activeDelivery.customer.location.latitude,
                  activeDelivery.customer.location.longitude
                )
              }
              className="flex-1 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition border border-slate-700"
            >
              <Navigation size={13} className="text-emerald-400" />
              <span>Navigate</span>
            </button>

            <button
              onClick={() => handleCall(activeDelivery.customer.phone)}
              className="p-2 bg-slate-800 hover:bg-slate-750 text-emerald-400 rounded-xl transition border border-slate-700"
              title="Call Customer (Masked)"
            >
              <Phone size={15} />
            </button>

            <button
              onClick={onOpenChat}
              className="p-2 bg-slate-800 hover:bg-slate-750 text-sky-400 rounded-xl transition border border-slate-700"
              title="Chat with Customer"
            >
              <MessageSquare size={15} />
            </button>
          </div>
        </div>

        {/* Order Items Preview */}
        <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-2.5 shadow-lg">
          <div className="flex items-center justify-between pb-1 border-b border-slate-800">
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              Order Items ({activeDelivery.items.length})
            </span>
            <span className="text-[10px] text-slate-400">Total: {formatCurrency(activeDelivery.financials.customerOrderTotal)}</span>
          </div>

          <div className="space-y-1 text-xs">
            {activeDelivery.items.map((it) => (
              <div key={it.id} className="flex justify-between py-1 border-b border-slate-800/60 last:border-0 text-slate-300">
                <span className="truncate">{it.name}</span>
                <span className="font-mono font-bold text-amber-400 ml-2">x{it.quantity}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Cash on Delivery (COD) Card if applicable */}
        {isCod && (
          <div className="bg-amber-950/40 p-4 rounded-3xl border border-amber-500/40 space-y-3 shadow-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Banknote size={18} className="text-amber-400" />
                <div>
                  <h4 className="text-xs font-bold text-white">Cash on Delivery (COD)</h4>
                  <span className="text-[10px] text-amber-300/80">Collect exact cash from customer</span>
                </div>
              </div>

              <span className="text-base font-black text-amber-400 font-mono">
                {formatCurrency(activeDelivery.financials.customerOrderTotal)}
              </span>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setIsCodModalOpen(true)}
                className="flex-1 py-2 bg-slate-900 hover:bg-slate-850 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700"
              >
                Change Calculator
              </button>

              <button
                onClick={collectCodPayment}
                disabled={isCodCollected}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  isCodCollected
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                    : 'bg-amber-600 hover:bg-amber-500 text-white shadow'
                }`}
              >
                {isCodCollected ? <CheckCircle size={14} /> : <Banknote size={14} />}
                <span>{isCodCollected ? 'Cash Collected ✓' : 'Mark Collected'}</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      {isChecklistOpen && (
        <ItemChecklistModal
          orderNumber={activeDelivery.orderNumber}
          restaurantName={activeDelivery.restaurant.name}
          items={activeDelivery.items}
          pickupCode={activeDelivery.pickupCode}
          onConfirmPickup={() => {
            setIsChecklistOpen(false);
            advanceDeliveryStatus('ORDER_PICKED_UP');
          }}
          onClose={() => setIsChecklistOpen(false)}
        />
      )}

      {isCodModalOpen && (
        <CodChangeCalculatorModal
          orderTotal={activeDelivery.financials.customerOrderTotal}
          onConfirmCollection={() => {
            setIsCodModalOpen(false);
            collectCodPayment();
          }}
          onClose={() => setIsCodModalOpen(false)}
        />
      )}

      {isUnreachableOpen && (
        <CustomerUnreachableModal
          customerName={activeDelivery.customer.name}
          customerPhone={activeDelivery.customer.phone}
          onLeaveInSafePlace={() => {
            setIsUnreachableOpen(false);
            setIsProofModalOpen(true);
          }}
          onReturnToRestaurant={() => {
            setIsUnreachableOpen(false);
            onBackToHome();
          }}
          onClose={() => setIsUnreachableOpen(false)}
        />
      )}

      {isDelayModalOpen && (
        <ReportDelayModal
          onDelaySubmitted={() => {}}
          onClose={() => setIsDelayModalOpen(false)}
        />
      )}

      {isProofModalOpen && (
        <ProofOfDeliveryModal
          orderNumber={activeDelivery.orderNumber}
          customerName={activeDelivery.customer.name}
          onPhotoVerified={() => {
            setIsProofModalOpen(false);
            advanceDeliveryStatus();
          }}
          onClose={() => setIsProofModalOpen(false)}
        />
      )}

      {/* Completion Summary Celebration Modal */}
      {isSummaryOpen && (
        <OrderCompletionSummaryModal
          order={activeDelivery}
          onFinishAndFindNext={() => {
            setIsSummaryOpen(false);
            clearActiveDelivery();
            onBackToHome();
          }}
        />
      )}

      {/* Emergency Safety SOS Modal */}
      {isSosOpen && <EmergencySosModal onClose={() => setIsSosOpen(false)} />}
    </div>
  );
};
