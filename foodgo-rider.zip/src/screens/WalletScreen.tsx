import React, { useState } from 'react';
import {
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  Building,
  CheckCircle2,
  Clock,
  AlertCircle,
  IndianRupee,
  ChevronLeft,
  ShieldCheck,
  Send,
  Filter,
  PlusCircle,
} from 'lucide-react';
import { formatCurrency, formatDate } from '../utils/formatters';
import { useWallet } from '../store/walletStore';
import { LedgerTransaction } from '../types/wallet.types';
import { WithdrawModal } from '../components/wallet/WithdrawModal';
import { CodSettlementModal } from '../components/wallet/CodSettlementModal';
import { TransactionDetailModal } from '../components/wallet/TransactionDetailModal';

interface WalletScreenProps {
  onBack: () => void;
}

export const WalletScreen: React.FC<WalletScreenProps> = ({ onBack }) => {
  const { availableBalance, floatingCash, transactions } = useWallet();
  const [filterType, setFilterType] = useState<'ALL' | 'CREDIT' | 'DEBIT'>('ALL');
  const [isWithdrawOpen, setIsWithdrawOpen] = useState(false);
  const [isCodOpen, setIsCodOpen] = useState(false);
  const [selectedTx, setSelectedTx] = useState<LedgerTransaction | null>(null);

  const filteredTransactions = transactions.filter((tx) => {
    if (filterType === 'ALL') return true;
    return tx.type === filterType;
  });

  return (
    <div className="flex-1 flex flex-col bg-slate-950 overflow-y-auto pb-10">
      {/* Top Header */}
      <div className="sticky top-0 bg-slate-900/90 backdrop-blur px-4 py-3 border-b border-slate-800 flex items-center justify-between z-20">
        <button
          onClick={onBack}
          className="flex items-center gap-1 text-xs text-slate-300 hover:text-white"
        >
          <ChevronLeft size={16} />
          <span>Back</span>
        </button>

        <h1 className="text-sm font-bold text-white">Rider Wallet & Payouts</h1>
        <div className="w-8" />
      </div>

      <div className="p-4 space-y-4">
        {/* Available Balance Hero Card */}
        <div className="bg-gradient-to-br from-emerald-950/60 via-slate-900 to-slate-900 p-5 rounded-3xl border border-emerald-500/30 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-emerald-400 font-medium block">
              Available for Instant Payout
            </span>
            <span className="text-[10px] font-bold text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
              Min ₹100 • Max ₹10,000/day
            </span>
          </div>

          <div className="text-3xl font-black text-white tracking-tight font-mono">
            {formatCurrency(availableBalance)}
          </div>

          <div className="pt-2">
            <button
              onClick={() => setIsWithdrawOpen(true)}
              className="w-full py-3.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/40 transition active:scale-98"
            >
              <ArrowUpRight size={16} />
              <span>WITHDRAW TO BANK / UPI (INSTANT)</span>
            </button>
          </div>
        </div>

        {/* Floating Cash on Delivery (COD) Card */}
        <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-3 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <IndianRupee size={15} className="text-amber-400" />
              <span>Floating Cash in Hand</span>
            </span>
            <span className="text-xs font-mono font-bold text-amber-400">
              {formatCurrency(floatingCash.currentCashInHand)}
            </span>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            Customer cash collected on deliveries. Deposit via UPI to maintain your cash limit capacity.
          </p>

          {/* Progress bar */}
          <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
            <div
              className="h-full bg-amber-400 transition-all duration-300"
              style={{
                width: `${(floatingCash.currentCashInHand / floatingCash.maxLimit) * 100}%`,
              }}
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Collected: {formatCurrency(floatingCash.currentCashInHand)}</span>
            <span>Max Cap: {formatCurrency(floatingCash.maxLimit)}</span>
          </div>

          <button
            onClick={() => setIsCodOpen(true)}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-750 text-amber-300 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border border-slate-700 transition"
          >
            <IndianRupee size={13} />
            <span>Deposit Cash via UPI</span>
          </button>
        </div>

        {/* Linked Bank Account Card */}
        <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              Primary Payout Account
            </span>
            <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 text-[10px] font-bold border border-emerald-500/20 flex items-center gap-1">
              <ShieldCheck size={11} />
              <span>Active</span>
            </span>
          </div>

          <div className="flex items-center gap-3 p-3 bg-slate-950/70 rounded-xl border border-slate-800/80">
            <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-slate-300">
              <Building size={18} />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">HDFC Bank Ltd</h4>
              <p className="text-[11px] text-slate-400 font-mono">
                A/C: ••••••••4821 • IFSC: HDFC0001244
              </p>
              <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                UPI: dhanush@okaxis
              </p>
            </div>
          </div>
        </div>

        {/* Daily Ledger Transactions History */}
        <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-3">
          <div className="flex items-center justify-between pb-1 border-b border-slate-800">
            <span className="text-xs font-bold text-white uppercase tracking-wider block">
              Wallet Ledger ({filteredTransactions.length})
            </span>

            {/* Filter pills */}
            <div className="flex gap-1 text-[10px] font-bold">
              {(['ALL', 'CREDIT', 'DEBIT'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setFilterType(mode)}
                  className={`px-2 py-0.5 rounded-lg transition ${
                    filterType === mode
                      ? 'bg-[#FF5200] text-white shadow'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {mode === 'ALL' ? 'All' : mode === 'CREDIT' ? 'Credits (+)' : 'Debits (-)'}
                </button>
              ))}
            </div>
          </div>

          {/* Transaction items */}
          <div className="space-y-2">
            {filteredTransactions.map((tx) => {
              const isCredit = tx.type === 'CREDIT';

              return (
                <div
                  key={tx.id}
                  onClick={() => setSelectedTx(tx)}
                  className="p-3 bg-slate-950/70 hover:bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between cursor-pointer transition group"
                >
                  <div className="flex items-start gap-2.5">
                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                        isCredit
                          ? 'bg-emerald-500/10 text-emerald-400'
                          : 'bg-rose-500/10 text-rose-400'
                      }`}
                    >
                      {isCredit ? <ArrowDownLeft size={16} /> : <ArrowUpRight size={16} />}
                    </div>

                    <div>
                      <h4 className="text-xs font-bold text-white group-hover:text-orange-400 transition truncate max-w-[160px]">
                        {tx.title}
                      </h4>
                      <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                        {tx.timestamp} {tx.orderNumber && `• ${tx.orderNumber}`}
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span
                      className={`text-xs font-black font-mono block ${
                        isCredit ? 'text-emerald-400' : 'text-white'
                      }`}
                    >
                      {isCredit ? '+' : '-'}
                      {formatCurrency(tx.amount)}
                    </span>
                    <span className="text-[9px] font-semibold text-slate-500 uppercase">
                      {tx.category.replace(/_/g, ' ')}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Withdraw Modal */}
      {isWithdrawOpen && <WithdrawModal onClose={() => setIsWithdrawOpen(false)} />}

      {/* Floating COD Settlement Modal */}
      {isCodOpen && <CodSettlementModal onClose={() => setIsCodOpen(false)} />}

      {/* Transaction Details Modal */}
      {selectedTx && (
        <TransactionDetailModal
          transaction={selectedTx}
          onClose={() => setSelectedTx(null)}
        />
      )}
    </div>
  );
};
