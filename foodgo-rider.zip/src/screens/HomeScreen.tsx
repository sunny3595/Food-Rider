import React from 'react';
import {
  IndianRupee,
  Navigation,
  Star,
  Award,
  TrendingUp,
  Flame,
  CheckCircle,
  AlertCircle,
  Clock,
  ArrowRight,
  Zap,
  Battery,
  Shield,
  Layers,
} from 'lucide-react';
import { useRider } from '../store/riderStore';
import { useDelivery } from '../store/deliveryStore';
import { useTheme } from '../store/themeStore';
import { useDuty } from '../store/dutyStore';
import { formatCurrency } from '../utils/formatters';
import { HeaderBar } from '../components/common/HeaderBar';
import { ActiveDeliveryCard } from '../components/delivery/ActiveDeliveryCard';
import { ShiftDurationBanner } from '../components/home/ShiftDurationBanner';
import { HotspotDemandCard } from '../components/home/HotspotDemandCard';
import { LocationPermissionModal } from '../components/home/LocationPermissionModal';
import { GoOfflineConfirmationModal } from '../components/home/GoOfflineConfirmationModal';
import { NotificationsDrawer } from '../components/home/NotificationsDrawer';
import { StationaryCheckModal } from '../components/safety/StationaryCheckModal';
import { EmergencySosModal } from '../components/safety/EmergencySosModal';
import { TabKey } from '../components/layout/BottomNavigation';

interface HomeScreenProps {
  onNavigateTab: (tab: TabKey) => void;
  onOpenOrderDetails: () => void;
  onOpenChat: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onNavigateTab,
  onOpenOrderDetails,
  onOpenChat,
}) => {
  const { profile, dutyStatus } = useRider();
  const { activeDelivery, triggerIncomingRequest } = useDelivery();
  const { handleDutyToggleRequest, setNotificationsDrawerOpen } = useDuty();
  const { t } = useTheme();

  const isOnline = dutyStatus === 'ONLINE';

  return (
    <div className="flex-1 flex flex-col bg-slate-950 pb-8">
      {/* Top Header with Online/Offline Switch & Notifications */}
      <HeaderBar onOpenNotifications={() => setNotificationsDrawerOpen(true)} />

      <div className="p-4 space-y-4">
        {/* Live Shift Duration Ribbon & Device Battery */}
        <ShiftDurationBanner />

        {/* Welcome Greeting & Summary Widget */}
        <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-slate-850 p-4 rounded-3xl border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <div>
              <span className="text-xs text-slate-400 font-medium">
                {t('goodMorning', 'Good Morning')},
              </span>
              <h1 className="text-lg font-extrabold text-white tracking-tight">
                {profile.fullName} 👋
              </h1>
            </div>

            {/* Shift Duty Status Pill */}
            <div
              className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 ${
                isOnline
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-slate-500'
                }`}
              />
              <span>{isOnline ? t('online', 'ONLINE') : t('offline', 'OFFLINE')}</span>
            </div>
          </div>

          {/* Today's Earnings Snapshot */}
          <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800/80">
            <div>
              <span className="text-[11px] text-slate-400 block">{t('todaysEarnings', "Today's Earnings")}</span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-2xl font-extrabold text-white tracking-tight">
                  {formatCurrency(1420)}
                </span>
                <span className="text-[10px] text-emerald-400 font-semibold">+18%</span>
              </div>
            </div>

            <div>
              <span className="text-[11px] text-slate-400 block">{t('todaysDeliveries', "Today's Deliveries")}</span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-2xl font-extrabold text-white tracking-tight">11</span>
                <span className="text-[10px] text-slate-400">orders</span>
              </div>
            </div>
          </div>

          {/* Performance Pill Indicators */}
          <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-800/80 text-center">
            <div className="bg-slate-950/60 p-2 rounded-xl border border-slate-800/60">
              <span className="text-[10px] text-slate-400 block">{t('acceptanceRate', 'Acceptance')}</span>
              <span className="text-xs font-bold text-white font-mono">
                {profile.performance.acceptanceRate}%
              </span>
            </div>

            <div className="bg-slate-950/60 p-2 rounded-xl border border-slate-800/60">
              <span className="text-[10px] text-slate-400 block">{t('completionRate', 'Completion')}</span>
              <span className="text-xs font-bold text-emerald-400 font-mono">
                {profile.performance.completionRate}%
              </span>
            </div>

            <div className="bg-slate-950/60 p-2 rounded-xl border border-slate-800/60">
              <span className="text-[10px] text-slate-400 block">{t('rating', 'Rating')}</span>
              <span className="text-xs font-bold text-amber-400 font-mono">
                ★ {profile.performance.averageRating}
              </span>
            </div>
          </div>
        </div>

        {/* Active Delivery Highlight Card */}
        {activeDelivery ? (
          <ActiveDeliveryCard
            onOpenDetails={onOpenOrderDetails}
            onOpenChat={onOpenChat}
          />
        ) : isOnline ? (
          /* Online & Live Searching Radar Card */
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-center shadow-xl relative overflow-hidden">
            {/* Animated Radar Ripples */}
            <div className="relative w-20 h-20 mx-auto mb-4 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full bg-[#FF5200]/20 animate-ping" style={{ animationDuration: '3s' }} />
              <div className="absolute inset-2 rounded-full bg-[#FF5200]/30 animate-pulse" />
              <div className="relative w-12 h-12 rounded-full bg-slate-950 border-2 border-[#FF5200] flex items-center justify-center text-[#FF5200] shadow-lg">
                <Navigation size={22} className="animate-spin" style={{ animationDuration: '6s' }} />
              </div>
            </div>

            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold mb-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Scanning High-Demand Radius (5 km)</span>
            </span>

            <h3 className="text-sm font-bold text-white mb-1">Searching for nearby orders...</h3>
            <p className="text-xs text-slate-400 mb-4 max-w-xs mx-auto leading-relaxed">
              You are prioritized for incoming restaurant orders in Indiranagar. Keep the app open.
            </p>

            <button
              onClick={() => triggerIncomingRequest()}
              className="px-4 py-2.5 bg-gradient-to-r from-[#FF5200] to-orange-600 hover:brightness-110 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-orange-950/50"
            >
              Simulate Instant Order Dispatch (₹98)
            </button>
          </div>
        ) : (
          /* Offline Prompt Card */
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-center shadow-xl space-y-3">
            <div className="w-14 h-14 mx-auto rounded-full bg-slate-800 border-2 border-slate-700 flex items-center justify-center text-slate-400">
              <Clock size={26} />
            </div>

            <div>
              <h3 className="text-base font-bold text-white">{t('offline', 'OFFLINE')}</h3>
              <p className="text-xs text-slate-400 max-w-xs mx-auto mt-1">
                {t('youAreOfflineMsg', 'Go online to start receiving delivery requests nearby in high surge zones')}
              </p>
            </div>

            <button
              onClick={() => handleDutyToggleRequest()}
              className="w-full py-3.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl text-xs font-bold shadow-xl shadow-emerald-950/40 transition active:scale-98"
            >
              {t('online', 'GO ONLINE')}
            </button>
          </div>
        )}

        {/* Live Demand Heatmap & Hotspot Zones */}
        <HotspotDemandCard />

        {/* Quick Access Tiles */}
        <div className="grid grid-cols-2 gap-3">
          {/* Incentives Tile */}
          <button
            onClick={() => onNavigateTab('incentives')}
            className="p-3.5 bg-slate-900 hover:bg-slate-850 rounded-2xl border border-slate-800 text-left transition flex flex-col justify-between group"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-xl bg-orange-500/20 text-[#FF5200] flex items-center justify-center">
                <Flame size={16} />
              </div>
              <span className="text-[10px] font-bold bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded">
                Active
              </span>
            </div>
            <div>
              <span className="text-xs font-bold text-white block group-hover:text-[#FF5200] transition">
                Dinner Peak Rush
              </span>
              <span className="text-[11px] text-slate-400">Earn extra ₹150 tonight</span>
            </div>
          </button>

          {/* Wallet Tile */}
          <button
            onClick={() => onNavigateTab('earnings')}
            className="p-3.5 bg-slate-900 hover:bg-slate-850 rounded-2xl border border-slate-800 text-left transition flex flex-col justify-between group"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <IndianRupee size={16} />
              </div>
              <span className="text-[10px] font-bold text-slate-400 font-mono">HDFC Bank</span>
            </div>
            <div>
              <span className="text-xs font-bold text-white block group-hover:text-emerald-400 transition">
                Wallet Balance
              </span>
              <span className="text-[11px] font-extrabold text-emerald-400">
                {formatCurrency(4280)}
              </span>
            </div>
          </button>
        </div>
      </div>

      {/* Location Permission Modal */}
      <LocationPermissionModal />

      {/* Go Offline Confirmation Modal */}
      <GoOfflineConfirmationModal />

      {/* Notifications Drawer */}
      <NotificationsDrawer onSelectNotification={(link) => {
        if (link?.includes('delivery')) onNavigateTab('deliveries');
      }} />

      {/* Safety Ride Check Modal */}
      <StationaryCheckModal
        onOpenSos={() => {}}
        onOpenSupport={onOpenChat}
      />
    </div>
  );
};
