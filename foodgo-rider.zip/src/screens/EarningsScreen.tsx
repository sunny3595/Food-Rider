import React, { useState } from 'react';
import {
  IndianRupee,
  TrendingUp,
  Calendar,
  ChevronRight,
  ArrowUpRight,
  Download,
  Wallet,
  Clock,
  Sparkles,
  FileText,
  Navigation,
  CheckCircle2,
  X,
} from 'lucide-react';
import { formatCurrency, formatDistance } from '../utils/formatters';
import { MOCK_EARNINGS_DASHBOARD } from '../api/mockData';
import { EarningsBreakdownChart } from '../components/wallet/EarningsBreakdownChart';

interface EarningsScreenProps {
  onOpenWallet: () => void;
}

interface CompletedTripItem {
  orderNumber: string;
  restaurant: string;
  customer: string;
  time: string;
  earnings: number;
  basePay: number;
  distPay: number;
  surgePay: number;
  tip: number;
  distanceKm: number;
}

const TODAY_TRIPS: CompletedTripItem[] = [
  {
    orderNumber: '#FG-10245',
    restaurant: 'Burger King',
    customer: 'Aarav Sharma',
    time: '02:45 PM',
    earnings: 98,
    basePay: 40,
    distPay: 28,
    surgePay: 15,
    tip: 15,
    distanceKm: 4.8,
  },
  {
    orderNumber: '#FG-10238',
    restaurant: 'Meghana Foods Biryani',
    customer: 'Priya Nair',
    time: '01:10 PM',
    earnings: 165,
    basePay: 45,
    distPay: 40,
    surgePay: 30,
    tip: 50,
    distanceKm: 6.2,
  },
  {
    orderNumber: '#FG-10231',
    restaurant: 'Truffles Burgers',
    customer: 'Karthik Raja',
    time: '12:20 PM',
    earnings: 122,
    basePay: 40,
    distPay: 32,
    surgePay: 25,
    tip: 25,
    distanceKm: 5.1,
  },
  {
    orderNumber: '#FG-10224',
    restaurant: 'Chai Point',
    customer: 'Vikram Joshi',
    time: '11:05 AM',
    earnings: 75,
    basePay: 35,
    distPay: 20,
    surgePay: 10,
    tip: 10,
    distanceKm: 2.8,
  },
];

export const EarningsScreen: React.FC<EarningsScreenProps> = ({ onOpenWallet }) => {
  const data = MOCK_EARNINGS_DASHBOARD;
  const [selectedPeriod, setSelectedPeriod] = useState<'TODAY' | 'WEEK' | 'MONTH'>('TODAY');
  const [selectedTrip, setSelectedTrip] = useState<CompletedTripItem | null>(null);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const todayBreakdown = data.today.breakdown;

  const handleDownloadInvoice = () => {
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 2500);
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 overflow-y-auto pb-10">
      {/* Top Header */}
      <div className="px-5 pt-4 pb-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
        <div>
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
            Partner Financials
          </span>
          <h1 className="text-base font-extrabold text-white">Earnings & Daily Ledger</h1>
        </div>

        <button
          onClick={onOpenWallet}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 rounded-xl text-xs font-bold hover:bg-emerald-600/30 transition shadow-sm"
        >
          <Wallet size={13} />
          <span>My Wallet (₹4,280)</span>
        </button>
      </div>

      <div className="p-4 space-y-4">
        {/* Period Selector Tabs */}
        <div className="flex bg-slate-900 p-1 rounded-2xl border border-slate-800 text-xs">
          <button
            onClick={() => setSelectedPeriod('TODAY')}
            className={`flex-1 py-1.5 rounded-xl font-bold transition ${
              selectedPeriod === 'TODAY'
                ? 'bg-[#FF5200] text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Today
          </button>
          <button
            onClick={() => setSelectedPeriod('WEEK')}
            className={`flex-1 py-1.5 rounded-xl font-bold transition ${
              selectedPeriod === 'WEEK'
                ? 'bg-[#FF5200] text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            This Week
          </button>
          <button
            onClick={() => setSelectedPeriod('MONTH')}
            className={`flex-1 py-1.5 rounded-xl font-bold transition ${
              selectedPeriod === 'MONTH'
                ? 'bg-[#FF5200] text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            This Month
          </button>
        </div>

        {/* Hero Revenue Card */}
        <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-orange-950/30 p-5 rounded-3xl border border-slate-800 shadow-xl relative overflow-hidden">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-xs text-slate-400 font-medium">
                {selectedPeriod === 'TODAY'
                  ? 'Total Earned Today'
                  : selectedPeriod === 'WEEK'
                  ? 'Total This Week'
                  : 'Total This Month'}
              </span>
              <div className="text-3xl font-black text-white mt-1 tracking-tight font-mono">
                {formatCurrency(
                  selectedPeriod === 'TODAY'
                    ? data.today.totalEarnings
                    : selectedPeriod === 'WEEK'
                    ? data.thisWeekTotal
                    : data.thisMonthTotal
                )}
              </div>
            </div>

            <div className="w-10 h-10 rounded-2xl bg-orange-500/20 text-[#FF5200] flex items-center justify-center">
              <TrendingUp size={20} />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 mt-4 pt-4 border-t border-slate-800 text-xs text-center">
            <div className="bg-slate-950/60 p-2 rounded-xl">
              <span className="text-slate-400 block text-[10px]">Deliveries</span>
              <span className="font-bold text-white text-xs font-mono">
                {selectedPeriod === 'TODAY' ? data.today.orderCount : '78'}
              </span>
            </div>
            <div className="bg-slate-950/60 p-2 rounded-xl">
              <span className="text-slate-400 block text-[10px]">Hours Online</span>
              <span className="font-bold text-white text-xs font-mono">
                {selectedPeriod === 'TODAY' ? `${data.today.onlineHours} hrs` : '42 hrs'}
              </span>
            </div>
            <div className="bg-slate-950/60 p-2 rounded-xl">
              <span className="text-slate-400 block text-[10px]">Distance</span>
              <span className="font-bold text-white text-xs font-mono">46.8 km</span>
            </div>
          </div>
        </div>

        {/* Hourly Shift Chart */}
        <EarningsBreakdownChart />

        {/* Detailed Itemized Earnings Breakdown */}
        <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              Earnings Itemization
            </span>
            <span className="text-[10px] text-emerald-400 font-bold">100% Direct to Rider</span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between py-1">
              <span className="text-slate-400">Base Order Pay</span>
              <span className="font-mono font-semibold text-slate-200">
                {formatCurrency(todayBreakdown.basePay)}
              </span>
            </div>

            <div className="flex items-center justify-between py-1">
              <span className="text-slate-400">Distance Travel Pay</span>
              <span className="font-mono font-semibold text-slate-200">
                {formatCurrency(todayBreakdown.distancePay)}
              </span>
            </div>

            <div className="flex items-center justify-between py-1">
              <span className="text-slate-400">Peak Hour Surge Rush</span>
              <span className="font-mono font-semibold text-amber-400">
                +{formatCurrency(todayBreakdown.peakBonus)}
              </span>
            </div>

            <div className="flex items-center justify-between py-1">
              <span className="text-slate-400">Customer Direct Tips</span>
              <span className="font-mono font-semibold text-emerald-400">
                +{formatCurrency(todayBreakdown.tips)}
              </span>
            </div>

            <div className="flex items-center justify-between py-1">
              <span className="text-slate-400">Milestone Target Bonuses</span>
              <span className="font-mono font-semibold text-orange-400">
                +{formatCurrency(todayBreakdown.incentiveBonus)}
              </span>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800 font-bold text-sm">
              <span className="text-white">Net Daily Total</span>
              <span className="text-emerald-400 font-mono">
                {formatCurrency(data.today.totalEarnings)}
              </span>
            </div>
          </div>
        </div>

        {/* Delivery-by-Delivery Shift Ledger */}
        <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white uppercase tracking-wider block">
              Today's Completed Trips (11)
            </span>
            <button
              onClick={handleDownloadInvoice}
              className="text-[10px] text-sky-400 hover:text-white flex items-center gap-1 font-semibold"
            >
              <Download size={11} />
              <span>{downloadSuccess ? 'Downloaded!' : 'Export Shift PDF'}</span>
            </button>
          </div>

          <div className="space-y-2">
            {TODAY_TRIPS.map((trip) => (
              <div
                key={trip.orderNumber}
                onClick={() => setSelectedTrip(trip)}
                className="p-3 bg-slate-950/70 hover:bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between cursor-pointer transition group"
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-white group-hover:text-orange-400 transition">
                      {trip.restaurant}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono font-semibold">
                      ({trip.orderNumber})
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400">
                    To {trip.customer} • {trip.time} ({formatDistance(trip.distanceKm)})
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-black text-emerald-400 font-mono">
                    {formatCurrency(trip.earnings)}
                  </span>
                  <ChevronRight size={14} className="text-slate-500 group-hover:text-white" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Individual Trip Itemized Modal */}
      {selectedTrip && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-3 animate-fadeIn">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl p-5 shadow-2xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div>
                <span className="text-[10px] text-slate-400 font-mono block">TRIP RECEIPT</span>
                <h4 className="text-sm font-bold text-white font-mono">{selectedTrip.orderNumber}</h4>
              </div>
              <button
                onClick={() => setSelectedTrip(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-1.5 text-xs text-slate-300 font-mono bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
              <div className="flex justify-between">
                <span className="text-slate-400">Restaurant:</span>
                <span className="text-white font-bold">{selectedTrip.restaurant}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Customer:</span>
                <span>{selectedTrip.customer}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Distance Travelled:</span>
                <span>{formatDistance(selectedTrip.distanceKm)}</span>
              </div>
              <div className="border-t border-slate-800 pt-1.5 flex justify-between">
                <span className="text-slate-400">Base Pay:</span>
                <span>{formatCurrency(selectedTrip.basePay)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Distance Pay:</span>
                <span>{formatCurrency(selectedTrip.distPay)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Surge Bonus:</span>
                <span className="text-amber-400">+{formatCurrency(selectedTrip.surgePay)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Direct Tip:</span>
                <span className="text-emerald-400">+{formatCurrency(selectedTrip.tip)}</span>
              </div>
              <div className="border-t border-slate-800 pt-1.5 flex justify-between font-bold text-sm">
                <span className="text-white">Trip Total:</span>
                <span className="text-emerald-400">{formatCurrency(selectedTrip.earnings)}</span>
              </div>
            </div>

            <button
              onClick={() => setSelectedTrip(null)}
              className="w-full py-2.5 bg-slate-800 text-slate-300 rounded-xl text-xs font-bold"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
