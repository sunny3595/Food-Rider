import React, { useState } from 'react';
import {
  ChevronLeft,
  Navigation,
  Sliders,
  Bell,
  Smartphone,
  ShieldCheck,
  Globe,
  BatteryCharging,
  Trash2,
  LogOut,
  MapPin,
  CheckCircle2,
  Volume2,
  ExternalLink,
  ChevronRight,
  Sparkles,
  Moon,
  Sun,
  Laptop,
} from 'lucide-react';
import { useSettings } from '../store/settingsStore';
import { useAuth } from '../store/authStore';
import { useTheme } from '../store/themeStore';
import {
  DefaultMapApp,
  AlertSoundType,
  SupportedLanguage,
  AppTheme,
} from '../types/settings.types';

interface SettingsScreenProps {
  onBack: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({ onBack }) => {
  const { settings, updateSettings, clearAppCache } = useSettings();
  const { theme, setTheme, language, setLanguage, t } = useTheme();
  const { logout } = useAuth();
  const [cacheCleared, setCacheCleared] = useState(false);
  const [activeZone, setActiveZone] = useState('Indiranagar & Koramangala Hub');

  const handleClearCache = () => {
    clearAppCache();
    setCacheCleared(true);
    setTimeout(() => setCacheCleared(false), 2000);
  };

  const handleLanguageChange = (newLang: SupportedLanguage) => {
    updateSettings({ system: { ...settings.system, language: newLang } });
    setLanguage(newLang);
  };

  const handleThemeChange = (newTheme: 'dark' | 'light' | 'system') => {
    updateSettings({ system: { ...settings.system, theme: newTheme.toUpperCase() as AppTheme } });
    setTheme(newTheme);
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 overflow-y-auto pb-12">
      {/* Top Header */}
      <div className="sticky top-0 bg-slate-900/90 backdrop-blur px-4 py-3 border-b border-slate-800 flex items-center justify-between z-20">
        <button
          onClick={onBack}
          className="flex items-center gap-1 text-xs text-slate-300 hover:text-white"
        >
          <ChevronLeft size={16} />
          <span>Back</span>
        </button>

        <h1 className="text-sm font-bold text-white">App Settings & Preferences</h1>
        <div className="w-8" />
      </div>

      <div className="p-4 space-y-4">
        {/* Navigation Section */}
        <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-3 shadow-lg">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
            <Navigation size={16} className="text-sky-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              GPS Navigation & Routing
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-slate-300 block mb-1 font-semibold">Default Maps App</label>
              <select
                value={settings.navigation.defaultApp}
                onChange={(e) =>
                  updateSettings({
                    navigation: {
                      ...settings.navigation,
                      defaultApp: e.target.value as DefaultMapApp,
                    },
                  })
                }
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-medium focus:outline-none focus:border-sky-500"
              >
                <option value="GOOGLE_MAPS">Google Maps (Recommended)</option>
                <option value="APPLE_MAPS">Apple Maps</option>
                <option value="WAZE">Waze Navigation</option>
                <option value="IN_APP_MAP">In-App Live Map</option>
              </select>
            </div>

            <div className="flex items-center justify-between py-1">
              <div>
                <span className="text-slate-200 font-semibold block">Turn-by-Turn Voice Guidance</span>
                <span className="text-[10px] text-slate-400">Speak directions through headset</span>
              </div>
              <input
                type="checkbox"
                checked={settings.navigation.voiceGuidance}
                onChange={(e) =>
                  updateSettings({
                    navigation: { ...settings.navigation, voiceGuidance: e.target.checked },
                  })
                }
                className="w-4 h-4 accent-[#FF5200] rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between py-1 border-t border-slate-800/80">
              <span className="text-slate-200">Avoid Toll Roads</span>
              <input
                type="checkbox"
                checked={settings.navigation.avoidTolls}
                onChange={(e) =>
                  updateSettings({
                    navigation: { ...settings.navigation, avoidTolls: e.target.checked },
                  })
                }
                className="w-4 h-4 accent-[#FF5200] rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Order Fulfillment Preferences */}
        <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-3 shadow-lg">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
            <Sliders size={16} className="text-[#FF5200]" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Dispatch & Order Preferences
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <div className="flex justify-between text-slate-300 font-semibold mb-1">
                <span>Maximum Delivery Radius</span>
                <span className="text-orange-400 font-mono font-bold">
                  {settings.orders.maxDeliveryDistanceKm} km
                </span>
              </div>
              <input
                type="range"
                min="3"
                max="15"
                step="1"
                value={settings.orders.maxDeliveryDistanceKm}
                onChange={(e) =>
                  updateSettings({
                    orders: { ...settings.orders, maxDeliveryDistanceKm: Number(e.target.value) },
                  })
                }
                className="w-full accent-[#FF5200] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>3 km</span>
                <span>15 km</span>
              </div>
            </div>

            <div className="flex items-center justify-between py-1 border-t border-slate-800/80">
              <div>
                <span className="text-slate-200 font-semibold block">Accept Cash on Delivery (COD)</span>
                <span className="text-[10px] text-slate-400">Receive cash-in-hand deliveries</span>
              </div>
              <input
                type="checkbox"
                checked={settings.orders.allowCashOnDelivery}
                onChange={(e) =>
                  updateSettings({
                    orders: { ...settings.orders, allowCashOnDelivery: e.target.checked },
                  })
                }
                className="w-4 h-4 accent-[#FF5200] rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between py-1 border-t border-slate-800/80">
              <div>
                <span className="text-slate-200 font-semibold block">Allow Stacked Batch Orders</span>
                <span className="text-[10px] text-slate-400">Receive +1 bundled orders along your route</span>
              </div>
              <input
                type="checkbox"
                checked={settings.orders.allowStackedDeliveries}
                onChange={(e) =>
                  updateSettings({
                    orders: { ...settings.orders, allowStackedDeliveries: e.target.checked },
                  })
                }
                className="w-4 h-4 accent-[#FF5200] rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Notifications & Audio Sounds */}
        <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-3 shadow-lg">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
            <Bell size={16} className="text-amber-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Alert Sounds & Vibration
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-slate-300 block mb-1 font-semibold">Incoming Order Chime</label>
              <select
                value={settings.notifications.sound}
                onChange={(e) =>
                  updateSettings({
                    notifications: {
                      ...settings.notifications,
                      sound: e.target.value as AlertSoundType,
                    },
                  })
                }
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-medium focus:outline-none focus:border-amber-500"
              >
                <option value="RADAR_CHIME">FoodGo Radar Chime (Default)</option>
                <option value="LOUD_SIREN">Loud Siren (Heavy Traffic Mode)</option>
                <option value="CLASSIC_BELL">Classic Restaurant Bell</option>
                <option value="SUBTLE_PULSE">Subtle Haptic Pulse</option>
              </select>
            </div>

            <div className="flex items-center justify-between py-1">
              <div>
                <span className="text-slate-200 font-semibold block">Max Volume Override</span>
                <span className="text-[10px] text-slate-400">Play order sound even if phone is on silent</span>
              </div>
              <input
                type="checkbox"
                checked={settings.notifications.maxVolumeOverride}
                onChange={(e) =>
                  updateSettings({
                    notifications: {
                      ...settings.notifications,
                      maxVolumeOverride: e.target.checked,
                    },
                  })
                }
                className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between py-1 border-t border-slate-800/80">
              <div>
                <span className="text-slate-200 font-semibold block">Screen Flash On Incoming Order</span>
                <span className="text-[10px] text-slate-400">High-visibility night alert</span>
              </div>
              <input
                type="checkbox"
                checked={settings.notifications.screenFlashOnOrder}
                onChange={(e) =>
                  updateSettings({
                    notifications: {
                      ...settings.notifications,
                      screenFlashOnOrder: e.target.checked,
                    },
                  })
                }
                className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* System & Languages */}
        <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-3 shadow-lg">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
            <Globe size={16} className="text-purple-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Language & System
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            {/* Theme Selector (Requirement 5) */}
            <div>
              <label className="text-slate-300 block mb-1.5 font-semibold">
                App Display Theme
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => handleThemeChange('dark')}
                  className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 transition ${
                    theme === 'dark'
                      ? 'bg-slate-950 border-purple-500 text-white shadow-md font-bold'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Moon size={15} className="text-indigo-400" />
                  <span className="text-[10px]">Dark</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleThemeChange('light')}
                  className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 transition ${
                    theme === 'light'
                      ? 'bg-slate-950 border-purple-500 text-white shadow-md font-bold'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Sun size={15} className="text-amber-400" />
                  <span className="text-[10px]">Light</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleThemeChange('system')}
                  className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 transition ${
                    theme === 'system'
                      ? 'bg-slate-950 border-purple-500 text-white shadow-md font-bold'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Smartphone size={15} className="text-emerald-400" />
                  <span className="text-[10px]">System OS</span>
                </button>
              </div>
              <p className="text-[10px] text-slate-400 mt-1">
                System mode automatically matches your device's light or dark mode.
              </p>
            </div>

            {/* Language Selector */}
            <div>
              <label className="text-slate-300 block mb-1 font-semibold">Language / భాష / भाषा / ಭಾಷೆ</label>
              <select
                value={language}
                onChange={(e) => handleLanguageChange(e.target.value as SupportedLanguage)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-medium focus:outline-none focus:border-purple-500"
              >
                <option value="en">English (English)</option>
                <option value="te">తెలుగు (Telugu)</option>
                <option value="hi">हिन्दी (Hindi)</option>
                <option value="kn">ಕನ್ನಡ (Kannada)</option>
                <option value="ta">தமிழ் (Tamil)</option>
                <option value="ml">മലയാളം (Malayalam)</option>
              </select>
            </div>

            <div className="flex items-center justify-between py-1">
              <div>
                <span className="text-slate-200 font-semibold block">Ultra Battery Saver Mode</span>
                <span className="text-[10px] text-slate-400">Minimizes screen GPU and GPS poll rate</span>
              </div>
              <input
                type="checkbox"
                checked={settings.system.batterySaverMode}
                onChange={(e) =>
                  updateSettings({
                    system: { ...settings.system, batterySaverMode: e.target.checked },
                  })
                }
                className="w-4 h-4 accent-purple-500 rounded cursor-pointer"
              />
            </div>

            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
              <div>
                <span className="text-slate-200 block font-semibold">Offline Map Tiles</span>
                <span className="text-[10px] text-emerald-400 font-mono">Bengaluru Central Cached (48 MB)</span>
              </div>
              <button
                onClick={handleClearCache}
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-lg text-[10px] font-bold border border-slate-700"
              >
                {cacheCleared ? 'Cleared!' : 'Clear Cache'}
              </button>
            </div>
          </div>
        </div>

        {/* Operating Hub Selection */}
        <div className="bg-slate-900 p-4 rounded-3xl border border-slate-800 space-y-2">
          <span className="text-xs font-bold text-white uppercase tracking-wider block">
            Assigned Delivery Hub
          </span>
          <div className="flex items-center justify-between p-3 bg-slate-950 rounded-2xl border border-slate-800 text-xs">
            <div className="flex items-center gap-2">
              <MapPin size={16} className="text-[#FF5200]" />
              <span className="text-white font-bold">{activeZone}</span>
            </div>
            <button
              onClick={() => setActiveZone('Koramangala & HSR Hub')}
              className="text-[10px] text-orange-400 underline font-semibold"
            >
              Change Hub
            </button>
          </div>
        </div>

        {/* Legal & Version Info */}
        <div className="p-4 bg-slate-950/70 rounded-3xl border border-slate-800 text-center space-y-1.5 text-xs text-slate-400">
          <p className="font-semibold text-slate-300">FoodGo Rider Partner App v2.4.0 (Build 842)</p>
          <p className="text-[10px] font-mono">FSSAI License: 11220334001928 • ISO 27001 Certified</p>
          <div className="flex justify-center gap-3 text-[10px] text-slate-400 pt-1">
            <span className="hover:underline cursor-pointer">Terms of Service</span>
            <span>•</span>
            <span className="hover:underline cursor-pointer">Privacy Policy</span>
            <span>•</span>
            <span className="hover:underline cursor-pointer">Partner Agreement</span>
          </div>
        </div>

        {/* Account Actions */}
        <div className="pt-2 space-y-2">
          <button
            onClick={logout}
            className="w-full py-3.5 bg-slate-800 hover:bg-slate-750 text-rose-400 rounded-2xl text-xs font-bold transition flex items-center justify-center gap-2 border border-slate-700"
          >
            <LogOut size={15} />
            <span>LOG OUT OF PARTNER ACCOUNT</span>
          </button>
        </div>
      </div>
    </div>
  );
};
