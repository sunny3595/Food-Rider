import { APP_CONFIG } from '../constants/config';
import { PayoutTransaction } from '../types/earnings.types';
import { generateIdempotencyKey } from '../utils/idempotency';
import { apiClient } from './client';
import { MOCK_EARNINGS_DASHBOARD } from './mockData';

export const WalletApi = {
  async getWalletSummary() {
    if (APP_CONFIG.features.enableDevMocks) {
      return MOCK_EARNINGS_DASHBOARD.wallet;
    }
    return apiClient.get('/wallet/summary');
  },

  async requestPayout(amount: number, payoutMethod: 'BANK_TRANSFER' | 'UPI_INSTANT'): Promise<PayoutTransaction> {
    const key = generateIdempotencyKey('payout_request');
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 600));
      return {
        id: `payout_${Date.now()}`,
        referenceId: `PO-${Date.now()}`,
        amount,
        status: 'PROCESSING',
        destinationAccountMasked: 'HDFC ••••4892',
        payoutMethod,
        requestedAt: new Date().toISOString(),
      };
    }
    return apiClient.post<PayoutTransaction>(
      '/wallet/payout',
      { amount, payoutMethod },
      { idempotencyKey: key }
    );
  },
};
