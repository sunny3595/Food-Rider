import { APP_CONFIG } from '../constants/config';
import { AuthTokens, LoginCredentials, RegistrationPayload } from '../types/api.types';
import { RiderAccountStatus, RiderProfile } from '../types/rider.types';
import { apiClient } from './client';
import { MOCK_RIDER_PROFILE } from './mockData';
import { SecureStorage } from '../utils/storage';

export const AuthApi = {
  async login(credentials: LoginCredentials): Promise<{ tokens: AuthTokens; rider: RiderProfile }> {
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 500));
      const mockTokens: AuthTokens = {
        accessToken: `mock_jwt_access_${Date.now()}`,
        refreshToken: `mock_jwt_refresh_${Date.now()}`,
        expiresIn: 86400,
        tokenType: 'Bearer',
      };
      await SecureStorage.setItem('access_token', mockTokens.accessToken);
      await SecureStorage.setItem('refresh_token', mockTokens.refreshToken);
      await SecureStorage.setItem('rider_id', MOCK_RIDER_PROFILE.id);
      return { tokens: mockTokens, rider: MOCK_RIDER_PROFILE };
    }

    const result = await apiClient.post<{ tokens: AuthTokens; rider: RiderProfile }>('/auth/login', credentials, {
      skipAuth: true,
    });
    await SecureStorage.setItem('access_token', result.tokens.accessToken);
    await SecureStorage.setItem('refresh_token', result.tokens.refreshToken);
    await SecureStorage.setItem('rider_id', result.rider.id);
    return result;
  },

  async loginWithGoogle(): Promise<{ tokens: AuthTokens; rider: RiderProfile }> {
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 600));
      const mockTokens: AuthTokens = {
        accessToken: `google_oauth_token_${Date.now()}`,
        refreshToken: `google_refresh_${Date.now()}`,
        expiresIn: 86400,
        tokenType: 'Bearer',
      };
      await SecureStorage.setItem('access_token', mockTokens.accessToken);
      await SecureStorage.setItem('refresh_token', mockTokens.refreshToken);
      return { tokens: mockTokens, rider: MOCK_RIDER_PROFILE };
    }
    return apiClient.post('/auth/google', {}, { skipAuth: true });
  },

  async loginWithApple(): Promise<{ tokens: AuthTokens; rider: RiderProfile }> {
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 600));
      const mockTokens: AuthTokens = {
        accessToken: `apple_oauth_token_${Date.now()}`,
        refreshToken: `apple_refresh_${Date.now()}`,
        expiresIn: 86400,
        tokenType: 'Bearer',
      };
      await SecureStorage.setItem('access_token', mockTokens.accessToken);
      await SecureStorage.setItem('refresh_token', mockTokens.refreshToken);
      return { tokens: mockTokens, rider: MOCK_RIDER_PROFILE };
    }
    return apiClient.post('/auth/apple', {}, { skipAuth: true });
  },

  async requestOtp(phone: string): Promise<{ requestId: string; message: string }> {
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 400));
      return { requestId: `req_otp_${Date.now()}`, message: 'OTP sent successfully. Demo Code: 1234' };
    }
    return apiClient.post('/auth/otp/send', { phone }, { skipAuth: true });
  },

  async verifyOtp(phone: string, otp: string): Promise<{ tokens: AuthTokens; rider: RiderProfile }> {
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 500));
      if (otp !== '1234' && otp.length !== 4) {
        throw new Error('Invalid verification OTP code. Use 1234 for demo.');
      }
      const mockTokens: AuthTokens = {
        accessToken: `mock_jwt_access_${Date.now()}`,
        refreshToken: `mock_jwt_refresh_${Date.now()}`,
        expiresIn: 86400,
        tokenType: 'Bearer',
      };
      await SecureStorage.setItem('access_token', mockTokens.accessToken);
      await SecureStorage.setItem('refresh_token', mockTokens.refreshToken);
      return { tokens: mockTokens, rider: MOCK_RIDER_PROFILE };
    }

    const result = await apiClient.post<{ tokens: AuthTokens; rider: RiderProfile }>('/auth/otp/verify', { phone, otp }, {
      skipAuth: true,
    });
    await SecureStorage.setItem('access_token', result.tokens.accessToken);
    return result;
  },

  async registerRider(data: any): Promise<{ rider: RiderProfile; tokens: AuthTokens }> {
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 900));
      const registeredRider: RiderProfile = {
        ...MOCK_RIDER_PROFILE,
        id: `rdr_${Date.now()}`,
        riderCode: `FG-${Math.floor(1000 + Math.random() * 9000)}`,
        fullName: data.fullName || 'Registered Partner',
        email: data.email || 'new-rider@example.com',
        phone: data.phone || '+91 98765 00000',
        accountStatus: 'PENDING_VERIFICATION',
        dutyStatus: 'OFFLINE',
        isDocumentsVerified: false,
        vehicle: {
          type: data.vehicleType || 'MOTORCYCLE',
          registrationNumber: data.registrationNumber || 'KA-01-XX-0000',
          makeModel: data.makeModel || 'Two Wheeler',
          color: data.color || 'Black',
        },
        bankAccount: {
          accountHolderName: data.accountHolderName || data.fullName,
          bankName: data.bankName || 'State Bank of India',
          accountNumberMasked: `••••••••${(data.accountNumber || '12345678').slice(-4)}`,
          ifscCode: data.ifscCode || 'SBIN0001234',
          upiId: data.upiId,
          isVerified: false,
        },
      };
      const mockTokens: AuthTokens = {
        accessToken: `mock_jwt_access_${Date.now()}`,
        refreshToken: `mock_jwt_refresh_${Date.now()}`,
        expiresIn: 86400,
        tokenType: 'Bearer',
      };
      await SecureStorage.setItem('access_token', mockTokens.accessToken);
      await SecureStorage.setItem('refresh_token', mockTokens.refreshToken);
      return { rider: registeredRider, tokens: mockTokens };
    }

    return apiClient.post('/auth/register', data, { skipAuth: true });
  },

  async requestPasswordReset(identifier: string): Promise<{ success: boolean; message: string }> {
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 500));
      return {
        success: true,
        message: `Password reset instructions sent to ${identifier}. Follow link or enter temporary code.`,
      };
    }
    return apiClient.post('/auth/forgot-password', { identifier }, { skipAuth: true });
  },

  async resetPassword(token: string, newPass: string): Promise<{ success: boolean }> {
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 500));
      return { success: true };
    }
    return apiClient.post('/auth/reset-password', { token, newPass }, { skipAuth: true });
  },

  async logout(): Promise<void> {
    try {
      if (!APP_CONFIG.features.enableDevMocks) {
        await apiClient.post('/auth/logout');
      }
    } catch (e) {
      console.warn('Backend logout call failed', e);
    } finally {
      await SecureStorage.clearTokens();
    }
  },

  async getCurrentSession(): Promise<RiderProfile | null> {
    const token = await SecureStorage.getItem('access_token');
    if (!token) return null;

    if (APP_CONFIG.features.enableDevMocks) {
      // Check if dev saved a customized status override in storage
      const savedStatus = (await SecureStorage.getItem('dev_override_status')) as RiderAccountStatus;
      if (savedStatus) {
        return {
          ...MOCK_RIDER_PROFILE,
          accountStatus: savedStatus,
          isDocumentsVerified: savedStatus === 'ACTIVE',
        };
      }
      return MOCK_RIDER_PROFILE;
    }

    try {
      return await apiClient.get<RiderProfile>('/rider/me');
    } catch {
      return null;
    }
  },
};
