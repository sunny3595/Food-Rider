import { APP_CONFIG } from '../constants/config';
import { ApiResponse } from '../types/api.types';
import { SecureStorage } from '../utils/storage';

export class ApiError extends Error {
  public code: string;
  public status: number;
  public details?: Record<string, string[]>;

  constructor(message: string, code = 'API_ERROR', status = 500, details?: Record<string, string[]>) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

interface RequestOptions extends RequestInit {
  idempotencyKey?: string;
  skipAuth?: boolean;
}

class ApiClient {
  private baseUrl: string;

  constructor() {
    this.baseUrl = APP_CONFIG.apiBaseUrl;
  }

  private async getAuthHeaders(skipAuth = false): Promise<Record<string, string>> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'X-App-Name': APP_CONFIG.appName,
      'X-App-Version': APP_CONFIG.version,
      'X-Client-Platform': 'mobile-rider',
    };

    if (!skipAuth) {
      const token = await SecureStorage.getItem('access_token');
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
    }

    return headers;
  }

  public async request<T>(endpoint: string, options: RequestOptions = {}): Promise<T> {
    const headers = await this.getAuthHeaders(options.skipAuth);

    if (options.idempotencyKey) {
      headers['X-Idempotency-Key'] = options.idempotencyKey;
    }

    const mergedHeaders = {
      ...headers,
      ...(options.headers as Record<string, string> || {}),
    };

    const url = endpoint.startsWith('http') ? endpoint : `${this.baseUrl}${endpoint}`;

    try {
      const response = await fetch(url, {
        ...options,
        headers: mergedHeaders,
      });

      if (!response.ok) {
        let errorData: any = {};
        try {
          errorData = await response.json();
        } catch {
          errorData = { message: response.statusText || 'Network request failed' };
        }

        const message = errorData?.error?.message || errorData?.message || 'Server error occurred';
        const code = errorData?.error?.code || `HTTP_${response.status}`;

        throw new ApiError(message, code, response.status, errorData?.error?.details);
      }

      const jsonResult = (await response.json()) as ApiResponse<T>;
      return jsonResult.data;
    } catch (err: any) {
      if (err instanceof ApiError) {
        throw err;
      }
      throw new ApiError(
        err.message || 'Unable to communicate with the server. Please check your network.',
        'NETWORK_ERROR',
        0
      );
    }
  }

  public get<T>(endpoint: string, options?: RequestOptions): Promise<T> {
    return this.request<T>(endpoint, { ...options, method: 'GET' });
  }

  public post<T>(endpoint: string, body?: unknown, options?: RequestOptions): Promise<T> {
    return this.request<T>(endpoint, {
      ...options,
      method: 'POST',
      body: body ? JSON.stringify(body) : undefined,
    });
  }

  public put<T>(endpoint: string, body?: unknown, options?: RequestOptions): Promise<T> {
    return this.request<T>(endpoint, {
      ...options,
      method: 'PUT',
      body: body ? JSON.stringify(body) : undefined,
    });
  }

  public patch<T>(endpoint: string, body?: unknown, options?: RequestOptions): Promise<T> {
    return this.request<T>(endpoint, {
      ...options,
      method: 'PATCH',
      body: body ? JSON.stringify(body) : undefined,
    });
  }

  public delete<T>(endpoint: string, options?: RequestOptions): Promise<T> {
    return this.request<T>(endpoint, { ...options, method: 'DELETE' });
  }
}

export const apiClient = new ApiClient();
