import { APP_CONFIG } from '../constants/config';
import { RiderDocument } from '../types/rider.types';
import { ChatMessage, InAppNotification } from '../types/socket.types';
import { apiClient } from './client';
import { MOCK_CHAT_MESSAGES, MOCK_DOCUMENTS, MOCK_NOTIFICATIONS } from './mockData';

export const DocumentsApi = {
  async getDocuments(): Promise<RiderDocument[]> {
    if (APP_CONFIG.features.enableDevMocks) {
      return MOCK_DOCUMENTS;
    }
    return apiClient.get<RiderDocument[]>('/documents');
  },

  async uploadDocument(documentId: string, _file: File | Blob): Promise<RiderDocument> {
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 800));
      return {
        ...MOCK_DOCUMENTS[0],
        id: documentId,
        status: 'PENDING',
        uploadedAt: new Date().toISOString().split('T')[0],
      };
    }
    return apiClient.post<RiderDocument>(`/documents/${documentId}/upload`);
  },
};

export const ChatApi = {
  async getMessages(conversationId: string): Promise<ChatMessage[]> {
    if (APP_CONFIG.features.enableDevMocks) {
      return MOCK_CHAT_MESSAGES.filter((m) => m.conversationId === conversationId);
    }
    return apiClient.get<ChatMessage[]>(`/chat/${conversationId}/messages`);
  },

  async sendMessage(conversationId: string, text: string): Promise<ChatMessage> {
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 200));
      const msg: ChatMessage = {
        id: `msg_${Date.now()}`,
        conversationId,
        senderRole: 'RIDER',
        senderName: 'You',
        text,
        timestamp: new Date().toISOString(),
        isRead: true,
      };
      return msg;
    }
    return apiClient.post<ChatMessage>(`/chat/${conversationId}/send`, { text });
  },
};

export const NotificationsApi = {
  async getNotifications(): Promise<InAppNotification[]> {
    if (APP_CONFIG.features.enableDevMocks) {
      return MOCK_NOTIFICATIONS;
    }
    return apiClient.get<InAppNotification[]>('/notifications');
  },

  async markAsRead(id: string): Promise<void> {
    if (APP_CONFIG.features.enableDevMocks) {
      return;
    }
    await apiClient.patch(`/notifications/${id}/read`);
  },
};

export const SupportApi = {
  async triggerSos(location: { latitude: number; longitude: number }): Promise<{ sosId: string; dispatched: boolean }> {
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 400));
      return { sosId: `sos_${Date.now()}`, dispatched: true };
    }
    return apiClient.post('/support/sos', { location });
  },
};
