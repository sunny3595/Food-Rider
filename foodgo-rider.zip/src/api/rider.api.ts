import { APP_CONFIG } from '../constants/config';
import { RiderDutyStatus, RiderLocation, RiderPerformance, RiderProfile } from '../types/rider.types';
import { apiClient } from './client';
import { MOCK_RIDER_PROFILE } from './mockData';

export const RiderApi = {
  async getProfile(): Promise<RiderProfile> {
    if (APP_CONFIG.features.enableDevMocks) {
      return MOCK_RIDER_PROFILE;
    }
    return apiClient.get<RiderProfile>('/rider/me');
  },

  async updateDutyStatus(status: RiderDutyStatus): Promise<{ dutyStatus: RiderDutyStatus }> {
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 400));
      return { dutyStatus: status };
    }
    return apiClient.patch<{ dutyStatus: RiderDutyStatus }>('/rider/duty-status', { status });
  },

  async sendLocationPing(location: RiderLocation): Promise<{ received: boolean }> {
    if (APP_CONFIG.features.enableDevMocks) {
      return { received: true };
    }
    return apiClient.post<{ received: boolean }>('/rider/location', location);
  },

  async getPerformance(): Promise<RiderPerformance> {
    if (APP_CONFIG.features.enableDevMocks) {
      return MOCK_RIDER_PROFILE.performance;
    }
    return apiClient.get<RiderPerformance>('/rider/performance');
  },
};
