import { APP_CONFIG } from '../constants/config';
import { EarningsDashboardData } from '../types/earnings.types';
import { apiClient } from './client';
import { MOCK_EARNINGS_DASHBOARD } from './mockData';

export const EarningsApi = {
  async getDashboardData(): Promise<EarningsDashboardData> {
    if (APP_CONFIG.features.enableDevMocks) {
      return MOCK_EARNINGS_DASHBOARD;
    }
    return apiClient.get<EarningsDashboardData>('/earnings/dashboard');
  },
};

export { WalletApi } from './wallet.api';
