import { APP_CONFIG } from '../constants/config';
import { DeliveryOrder, DeliveryRequest, DeliveryStatus } from '../types/delivery.types';
import { generateIdempotencyKey } from '../utils/idempotency';
import { apiClient } from './client';
import { MOCK_ACTIVE_DELIVERY, MOCK_DELIVERY_REQUEST } from './mockData';

export const DeliveryApi = {
  async getAvailableRequests(): Promise<DeliveryRequest[]> {
    if (APP_CONFIG.features.enableDevMocks) {
      return [MOCK_DELIVERY_REQUEST];
    }
    return apiClient.get<DeliveryRequest[]>('/deliveries/available');
  },

  async getActiveDelivery(): Promise<DeliveryOrder | null> {
    if (APP_CONFIG.features.enableDevMocks) {
      return MOCK_ACTIVE_DELIVERY;
    }
    return apiClient.get<DeliveryOrder | null>('/deliveries/active');
  },

  async acceptRequest(requestId: string): Promise<DeliveryOrder> {
    const key = generateIdempotencyKey('accept', requestId);
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 600));
      return {
        ...MOCK_ACTIVE_DELIVERY,
        id: requestId,
        status: 'ASSIGNED',
        assignedAt: new Date().toISOString(),
      };
    }
    return apiClient.post<DeliveryOrder>(
      `/deliveries/${requestId}/accept`,
      {},
      { idempotencyKey: key }
    );
  },

  async rejectRequest(requestId: string, reason?: string): Promise<{ success: boolean }> {
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 300));
      return { success: true };
    }
    return apiClient.post<{ success: boolean }>(`/deliveries/${requestId}/reject`, { reason });
  },

  async updateDeliveryStatus(
    deliveryId: string,
    newStatus: DeliveryStatus,
    extraData?: {
      location?: { latitude: number; longitude: number };
      otp?: string;
      pickupCode?: string;
      photoProofUrl?: string;
    }
  ): Promise<DeliveryOrder> {
    const key = generateIdempotencyKey(`status_${newStatus}`, deliveryId);

    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 500));
      return {
        ...MOCK_ACTIVE_DELIVERY,
        id: deliveryId,
        status: newStatus,
        arrivedRestaurantAt:
          newStatus === 'ARRIVED_AT_RESTAURANT' ? new Date().toISOString() : MOCK_ACTIVE_DELIVERY.arrivedRestaurantAt,
        pickedUpAt: newStatus === 'ORDER_PICKED_UP' ? new Date().toISOString() : MOCK_ACTIVE_DELIVERY.pickedUpAt,
        arrivedCustomerAt:
          newStatus === 'ARRIVED_AT_CUSTOMER' ? new Date().toISOString() : MOCK_ACTIVE_DELIVERY.arrivedCustomerAt,
        deliveredAt: newStatus === 'DELIVERED' ? new Date().toISOString() : undefined,
      };
    }

    return apiClient.patch<DeliveryOrder>(
      `/deliveries/${deliveryId}/status`,
      { status: newStatus, ...extraData },
      { idempotencyKey: key }
    );
  },

  async verifyPickup(deliveryId: string, pickupCode: string): Promise<DeliveryOrder> {
    const key = generateIdempotencyKey('pickup_verify', deliveryId);
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 500));
      return {
        ...MOCK_ACTIVE_DELIVERY,
        id: deliveryId,
        status: 'ORDER_PICKED_UP',
        pickedUpAt: new Date().toISOString(),
      };
    }
    return apiClient.post<DeliveryOrder>(
      `/deliveries/${deliveryId}/verify-pickup`,
      { pickupCode },
      { idempotencyKey: key }
    );
  },

  async verifyDeliveryOtp(deliveryId: string, otp: string): Promise<DeliveryOrder> {
    const key = generateIdempotencyKey('delivery_verify_otp', deliveryId);
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 600));
      if (otp !== '4829' && otp !== '1234') {
        throw new Error('Invalid Customer OTP. Use 4829 for demo verification.');
      }
      return {
        ...MOCK_ACTIVE_DELIVERY,
        id: deliveryId,
        status: 'DELIVERED',
        deliveredAt: new Date().toISOString(),
      };
    }
    return apiClient.post<DeliveryOrder>(
      `/deliveries/${deliveryId}/verify-otp`,
      { otp },
      { idempotencyKey: key }
    );
  },

  async confirmCashCollected(deliveryId: string, amount: number): Promise<{ success: boolean; amount: number }> {
    const key = generateIdempotencyKey('cash_collected', deliveryId);
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 400));
      return { success: true, amount };
    }
    return apiClient.post<{ success: boolean; amount: number }>(
      `/deliveries/${deliveryId}/collect-cash`,
      { amount },
      { idempotencyKey: key }
    );
  },

  async reportDeliveryIssue(deliveryId: string, issueType: string, description: string): Promise<{ ticketId: string }> {
    if (APP_CONFIG.features.enableDevMocks) {
      await new Promise((r) => setTimeout(r, 400));
      return { ticketId: `tkt_${Date.now()}` };
    }
    return apiClient.post<{ ticketId: string }>(`/deliveries/${deliveryId}/report-issue`, { issueType, description });
  },

  async getDeliveryHistory(range = 'THIS_WEEK'): Promise<DeliveryOrder[]> {
    if (APP_CONFIG.features.enableDevMocks) {
      return [
        {
          ...MOCK_ACTIVE_DELIVERY,
          id: 'del_past_9901',
          orderNumber: 'FG-09901',
          status: 'DELIVERED',
          deliveredAt: new Date(Date.now() - 3600000 * 3).toISOString(),
        },
        {
          ...MOCK_ACTIVE_DELIVERY,
          id: 'del_past_9902',
          orderNumber: 'FG-09902',
          status: 'DELIVERED',
          deliveredAt: new Date(Date.now() - 3600000 * 5).toISOString(),
        },
      ];
    }
    return apiClient.get<DeliveryOrder[]>(`/deliveries/history?range=${range}`);
  },
};
